<?php

namespace app\controllers;

use Yii;
use app\models\Test;
use app\models\SearchTest;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use yii\data\ActiveDataProvider;


/**
 * TestController implements the CRUD actions for Test model.
 */
class TestController extends Controller
{
    /**
     * {@inheritdoc}
     */
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['POST'],
                ],
            ],
        ];
    }

    /**
     * Lists all Test models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new SearchTest();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Displays a single Test model.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionView($id)
    {
        return $this->render('view', [
            'model' => $this->findModel($id),
        ]);
    }

    /**
     * Creates a new Test model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate()
    {
        $model = new Test();

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['view', 'id' => $model->id]);
        }

        return $this->render('create', [
            'model' => $model,
        ]);
    }

    /**
     * Updates an existing Test model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionUpdate($id)
    {
        $model = $this->findModel($id);

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['view', 'id' => $model->id]);
        }

        return $this->render('update', [
            'model' => $model,
        ]);
    }

    /**
     * Deletes an existing Test model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionDelete($id)
    {
        $this->findModel($id)->delete();

        return $this->redirect(['index']);
    }

    public function actionReport()
    {
        if(!Yii::$app->user->isGuest){
            $usn = null;
            $searchModel = new SearchTest();
            $query = Test::find();
            $dataProvider = new ActiveDataProvider([
                'query' => $query,
                'sort' => [
                    'defaultOrder' => [
                        'test_date' => SORT_ASC,
                    ]
                ],
            ]);
            $start_date = date('Y-m-1');
            $end_date = date('Y-m-t');
            if(Yii::$app->request->get('start_date') && Yii::$app->request->get('end_date')){
                $start_date = Yii::$app->request->get('start_date');
                $end_date = Yii::$app->request->get('end_date');
                $usn = Yii::$app->request->get('usn');
            }
            $query->andFilterWhere(['between', 'test_date', $start_date, $end_date]);
            $query->andFilterWhere(['usn' => $usn]);
            return $this->render('report', [
                'searchModel' => $searchModel,
                'dataProvider' => $dataProvider,
                'start_date' => $start_date,
                'end_date' => $end_date,
                'usn' => $usn
            ]);
        }else{
            throw new \yii\web\ForbiddenHttpException;
        } 
    }


    public function actionStudentrep()
    {
        if(!Yii::$app->user->isGuest){
            $usn = '2GI22MC011';
            $searchModel = new SearchTest();
            $query = Test::find();
            $dataProvider = new ActiveDataProvider([
                'query' => $query,
                'sort' => [
                    'defaultOrder' => [
                        'test_date' => SORT_ASC,
                    ]
                ],
            ]);
            $start_date = date('Y-m-1');
            $end_date = date('Y-m-t');
            if(Yii::$app->request->get('start_date') && Yii::$app->request->get('end_date')){
                $start_date = Yii::$app->request->get('start_date');
                $end_date = Yii::$app->request->get('end_date');
                $usn = Yii::$app->request->get('usn');
            }
            $query->andFilterWhere(['between', 'test_date', $start_date, $end_date]);
            $query->andFilterWhere(['usn' => $usn]);
            return $this->render('report', [
                'searchModel' => $searchModel,
                'dataProvider' => $dataProvider,
                'start_date' => $start_date,
                'end_date' => $end_date,
                'usn' => $usn
            ]);
        }else{
            throw new \yii\web\ForbiddenHttpException;
        } 
    }

    /**
     * Finds the Test model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return Test the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = Test::findOne($id)) !== null) {
            return $model;
        }

        throw new NotFoundHttpException('The requested page does not exist.');
    }
}
