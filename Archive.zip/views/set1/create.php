<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model app\models\Set2 */

$this->title = 'MOCK TESTS Set 1';
?>
<div class="set1-create">

   <center> <h3 style="align:center;"><?= Html::encode($this->title) ?></h3></center>

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
