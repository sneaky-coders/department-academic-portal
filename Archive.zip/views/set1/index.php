<?php

use yii\grid\GridView;
use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Custom GridView Page';
$this->params['breadcrumbs'][] = $this->title;
?>

<div class="site-index">
    <h1><?= Html::encode($this->title) ?></h1>

    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'tableOptions' => ['class' => 'table table-responsive table-striped custom-grid'],
        'columns' => [
            'id',
            [
                'label' => 'Student Name',
                'attribute' => 'user_id',
                'value' => function ($model) {
                    return $model->user->username; // Assuming 'user' is the relation to the users table
                },
            ],
            'usn',
            'category',
            'q1',
            'q2',
            'q3',
            'q4',
            'q5',
            'q6',
            'q7',
            'q8',
            'q9',
            'q10',
            'q11',
            'q12',
            'q13',
            'q14',
            'q15',
            'q16',
            'q17',
            'q18',
            'q19',
            'q20',
            'q21',
            'q22',
            'q23',
            'q24',
            'q25',
            'total',
            // Add more columns as needed
            [
                'class' => 'yii\grid\ActionColumn',
                'template' => '{view} {update} {delete}',
            ],
        ],
    ]); ?>
</div>

<style>
    /* Custom CSS for the GridView */
    .custom-grid {
        /* Add your custom styles for the table here */
    }

    .custom-grid th {
        /* Add your custom styles for the table headers here */
    }

    .custom-grid td {
        /* Add your custom styles for the table cells here */
    }

    .custom-grid .action-column {
        /* Add your custom styles for the action column (if present) here */
    }
</style>