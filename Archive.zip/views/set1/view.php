<?php

use app\models\DepartureDetailCoTraveller;
use yii\data\ActiveDataProvider;
use yii\grid\GridView;
use yii\helpers\Html;
use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model app\models\DepartureDetail */

$this->title = "Mock Test";
$this->params['breadcrumbs'][] = ['label' => 'Mock Test', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
\yii\web\YiiAsset::register($this);



?>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<div class="departure-detail-view">
    <div class="row">
        <div class="col-md-6">
            <h1><?= Html::encode($this->title) ?></h1>
        </div>
        <div class="col-md-6 text-right">

        </div>
    </div>
    <br>
    <?= DetailView::widget([
        'model' => $model,
        'attributes' => [
            // 'departure_detail_id',
            // 'rsvp_id',
            // 'name',
            // 'age',
            // 'gender',
            // 'mode_of_travel',
            'user_id',
            [
                'label' => "Student Name",
                'attribute' => 'student_name',
                'value' => Yii::$app->user->identity->username
            ],
            'usn',
            [
                'label' => "Test Category",
                'attribute' => 'student_name',
                'value' => $model->category
            ],

            'total'
        ],
    ]) ?>
    <br>

    <h2><u>Your Scores</u></h2>
    <div class="row">
        <div class="col-md-12">
            <div class="table table-reponsive">
                <table class="table table-bordered table-striped">
                    <thead>
                        <?php


                        if ($model->q1 == 'd') {
                            $scoreq1 = 1;
                        } else {
                            $scoreq1 = 0;
                        }

                        if ($model->q2 == 'd') {
                            $scoreq2 = 1;
                        } else {
                            $scoreq2 = 0;
                        }

                        if ($model->q3 == 'c') {
                            $scoreq3 = 1;
                        } else {
                            $scoreq3 = 0;
                        }

                        if ($model->q4 == 'd') {
                            $scoreq4 = 1;
                        } else {
                            $scoreq4 = 0;
                        }

                        if ($model->q5 == 'a') {
                            $scoreq5 = 1;
                        } else {
                            $scoreq5 = 0;
                        }

                        if ($model->q6 == 'a') {
                            $scoreq6 = 1;
                        } else {
                            $scoreq6 = 0;
                        }

                        if ($model->q7 == 'b') {
                            $scoreq7 = 1;
                        } else {
                            $scoreq7 = 0;
                        }

                        if ($model->q8 == 'a') {
                            $scoreq8 = 1;
                        } else {
                            $scoreq8 = 0;
                        }

                        if ($model->q9 == 'a') {
                            $scoreq9 = 1;
                        } else {
                            $scoreq9 = 0;
                        }

                        if ($model->q10 == 'd') {
                            $scoreq10 = 1;
                        } else {
                            $scoreq10 = 0;
                        }

                        if ($model->q11 == 'c') {
                            $scoreq11 = 1;
                        } else {
                            $scoreq11 = 0;
                        }

                        if ($model->q12 == 'a') {
                            $scoreq12 = 1;
                        } else {
                            $scoreq12 = 0;
                        }

                        if ($model->q13 == 'd') {
                            $scoreq13 = 1;
                        } else {
                            $scoreq13 = 0;
                        }

                        if ($model->q14 == 'b') {
                            $scoreq14 = 1;
                        } else {
                            $scoreq14 = 0;
                        }

                        if ($model->q15 == 'd') {
                            $scoreq15 = 1;
                        } else {
                            $scoreq15 = 0;
                        }

                        if ($model->q16 == 'a') {
                            $scoreq16 = 1;
                        } else {
                            $scoreq16 = 0;
                        }

                        if ($model->q17 == 'c') {
                            $scoreq17 = 1;
                        } else {
                            $scoreq17 = 0;
                        }

                        if ($model->q18 == 'a') {
                            $scoreq18 = 1;
                        } else {
                            $scoreq18 = 0;
                        }

                        if ($model->q19 == 'b') {
                            $scoreq19 = 1;
                        } else {
                            $scoreq19 = 0;
                        }

                        if ($model->q20 == 'd') {
                            $scoreq20 = 1;
                        } else {
                            $scoreq20 = 0;
                        }

                        if ($model->q21 == 'c') {
                            $scoreq21 = 1;
                        } else {
                            $scoreq21 = 0;
                        }

                        if ($model->q22 == 'c') {
                            $scoreq22 = 1;
                        } else {
                            $scoreq22 = 0;
                        }

                        if ($model->q23 == 'a') {
                            $scoreq23 = 1;
                        } else {
                            $scoreq23 = 0;
                        }

                        if ($model->q24 == 'd') {
                            $scoreq24 = 1;
                        } else {
                            $scoreq24 = 0;
                        }

                        if ($model->q25 == 'b') {
                            $scoreq25 = 1;
                        } else {
                            $scoreq25 = 0;
                        }


                        ?>
                        <tr>
                            <th>#</th>
                            <th>Q1</th>
                            <th>Q2</th>
                            <th>Q3</th>
                            <th>Q4</th>
                            <th>Q5</th>
                            <th>Q6</th>
                            <th>Q7</th>
                            <th>Q8</th>
                            <th>Q9</th>
                            <th>Q10</th>

                        </tr>
                    </thead>
                    <tbody>

                        <tr>
                            <td><?php echo 1 ?></td>
                            <?php

                            if ($scoreq1 == 1) {
                                echo '  <td class="success">1</td>';
                            } else {
                                echo '  <td class="danger">0</td>';
                            }

                            ?>

                            <?php

                            if ($scoreq2 == 1) {
                                echo '  <td class="success">1</td>';
                            } else {
                                echo '  <td class="danger">0</td>';
                            }

                            ?>

                            <?php

                            if ($scoreq3 == 1) {
                                echo '  <td class="success">1</td>';
                            } else {
                                echo '  <td class="danger">0</td>';
                            }

                            ?>
                            <?php

                            if ($scoreq4 == 1) {
                                echo '  <td class="success">1</td>';
                            } else {
                                echo '  <td class="danger">0</td>';
                            }

                            ?>

                            <?php

                            if ($scoreq5 == 1) {
                                echo '  <td class="success">1</td>';
                            } else {
                                echo '  <td class="danger">0</td>';
                            }

                            ?>

                            <?php

                            if ($scoreq6 == 1) {
                                echo '  <td class="success">1</td>';
                            } else {
                                echo '  <td class="danger">0</td>';
                            }

                            ?>

                            <?php

                            if ($scoreq7 == 1) {
                                echo '  <td class="success">1</td>';
                            } else {
                                echo '  <td class="danger">0</td>';
                            }

                            ?>

                            <?php

                            if ($scoreq8 == 1) {
                                echo '  <td class="success">1</td>';
                            } else {
                                echo '  <td class="danger">0</td>';
                            }

                            ?>

                            <?php

                            if ($scoreq9 == 1) {
                                echo '  <td class="success">1</td>';
                            } else {
                                echo '  <td class="danger">0</td>';
                            }

                            ?>

                            <?php

                            if ($scoreq10 == 1) {
                                echo '  <td class="success">1</td>';
                            } else {
                                echo '  <td class="danger">0</td>';
                            }

                            ?>



                        </tr>
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Q11</th>
                                <th>Q12</th>
                                <th>Q13</th>
                                <th>Q14</th>
                                <th>Q15</th>
                                <th>Q16</th>
                                <th>Q17</th>
                                <th>Q18</th>
                                <th>Q19</th>
                                <th>Q20</th>

                            </tr>
                        </thead>

                        <tr>

                            <td><?php echo 2 ?></td>
                            <?php

                            if ($scoreq11 == 1) {
                                echo '  <td class="success">1</td>';
                            } else {
                                echo '  <td class="danger">0</td>';
                            }

                            ?>

                            <?php

                            if ($scoreq12 == 1) {
                                echo '  <td class="success">1</td>';
                            } else {
                                echo '  <td class="danger">0</td>';
                            }

                            ?>

                            <?php

                            if ($scoreq13 == 1) {
                                echo '  <td class="success">1</td>';
                            } else {
                                echo '  <td class="danger">0</td>';
                            }

                            ?>

                            <?php

                            if ($scoreq14 == 1) {
                                echo '  <td class="success">1</td>';
                            } else {
                                echo '  <td class="danger">0</td>';
                            }

                            ?>

                            <?php

                            if ($scoreq15 == 1) {
                                echo '  <td class="success">1</td>';
                            } else {
                                echo '  <td class="danger">0</td>';
                            }

                            ?>

                            <?php

                            if ($scoreq16 == 1) {
                                echo '  <td class="success">1</td>';
                            } else {
                                echo '  <td class="danger">0</td>';
                            }

                            ?>

                            <?php

                            if ($scoreq17 == 1) {
                                echo '  <td class="success">1</td>';
                            } else {
                                echo '  <td class="danger">0</td>';
                            }

                            ?>

                            <?php

                            if ($scoreq18 == 1) {
                                echo '  <td class="success">1</td>';
                            } else {
                                echo '  <td class="danger">0</td>';
                            }

                            ?>

                            <?php

                            if ($scoreq19 == 1) {
                                echo '  <td class="success">1</td>';
                            } else {
                                echo '  <td class="danger">0</td>';
                            }

                            ?>

                            <?php

                            if ($scoreq20 == 1) {
                                echo '  <td class="success">1</td>';
                            } else {
                                echo '  <td class="danger">0</td>';
                            }

                            ?>

                        </tr>

                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Q21</th>
                                <th></th>
                                <th>Q22</th>
                                <th></th>
                                <th>Q23</th>
                                <th></th>
                                <th>Q24</th>
                                <th></th>
                                <th>Q25</th>
                                <th></th>


                            </tr>
                        </thead>

                        <tr>

                            <td><?php echo 3 ?></td>
                            <?php

                            if ($scoreq21 == 1) {
                                echo '  <td class="success">1</td>';
                            } else {
                                echo '  <td class="danger">0</td>';
                            }

                            ?>
                            <td><?php echo ""; ?></td>
                            <?php

                            if ($scoreq22 == 1) {
                                echo '  <td class="success">1</td>';
                            } else {
                                echo '  <td class="danger">0</td>';
                            }

                            ?>
                            <td><?php echo ""; ?></td>

                            <?php

                            if ($scoreq23 == 1) {
                                echo '  <td class="success">1</td>';
                            } else {
                                echo '  <td class="danger">0</td>';
                            }

                            ?>
                            <td><?php echo ""; ?></td>
                            <?php

                            if ($scoreq24 == 1) {
                                echo '  <td class="success">1</td>';
                            } else {
                                echo '  <td class="danger">0</td>';
                            }

                            ?>
                            <td><?php echo ""; ?></td>
                            <?php

                            if ($scoreq25 == 1) {
                                echo '  <td class="success">1</td>';
                            } else {
                                echo '  <td class="danger">0</td>';
                            }

                            ?>

                        </tr>

                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <br>







    <br>

    <h2><u>Correct Answers</u></h2>
    <div class="row">
        <div class="col-md-12">
            <div class="table-reponsive">
                <table class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Q1</th>
                            <th>Q2</th>
                            <th>Q3</th>
                            <th>Q4</th>
                            <th>Q5</th>
                            <th>Q6</th>
                            <th>Q7</th>
                            <th>Q8</th>
                            <th>Q9</th>
                            <th>Q10</th>


                        </tr>
                    </thead>
                    <tbody>

                        <tr>
                            <td><?php echo 1 ?></td>
                            <td> <?php echo '5 3 1 2 4'; ?></td>
                            <td><?php echo 'All the above'; ?></td>
                            <td> <?php echo 'Both (A) and (B)'; ?></td>
                            <td><?php echo 'All of the above'; ?></td>
                            <td><?php echo 'Calculates the number of edges in an undirected graph'; ?></td>
                            <td><?php echo 'push_back()'; ?></td>
                            <td> <?php echo 'Underflow'; ?></td>
                            <td> <?php echo 'Stack'; ?></td>
                            <td><?php echo 'Pointers'; ?></td>
                            <td><?php echo 'All of the above'; ?></td>


                        </tr>
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Q11</th>
                                <th>Q12</th>
                                <th>Q13</th>
                                <th>Q14</th>
                                <th>Q15</th>
                                <th>Q16</th>
                                <th>Q17</th>
                                <th>Q18</th>
                                <th>Q19</th>
                                <th>Q20</th>

                            </tr>
                        </thead>

                        <tr>

                            <td><?php echo 2 ?></td>
                            <td> <?php echo 'both A and B'; ?></td>
                            <td><?php echo '["Monday","Tuesday"]'; ?></td>
                            <td> <?php echo '[1,2,1,2,1,2]'; ?></td>
                            <td> <?php echo 'Object'; ?></td>
                            <td><?php echo 'Structured Query Language'; ?></td>
                            <td><?php echo 'Numeric'; ?></td>
                            <td><?php echo 'Both A and B'; ?></td>
                            <td> <?php echo 'DAY'; ?></td>
                            <td><?php echo 'Self-Join'; ?></td>
                            <td><?php echo 'extends'; ?></td>

                        </tr>

                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Q21</th>
                                <th></th>
                                <th>Q22</th>
                                <th></th>
                                <th>Q23</th>
                                <th></th>
                                <th>Q24</th>
                                <th></th>
                                <th>Q25</th>
                                <th></th>


                            </tr>
                        </thead>

                        <tr>

                            <td><?php echo 3 ?></td>
                            <td> <?php echo 'class B extends A {}'; ?></td>
                            <td><?php echo ''; ?></td>
                            <td> <?php echo 'Container that stores the elements of similar types'; ?></td>
                            <td> <?php echo ''; ?></td>
                            <td><?php echo 'Garbage Value'; ?></td>
                            <td><?php echo ''; ?></td>
                            <td><?php echo 'Asynchronous data transfer'; ?></td>
                            <td> <?php echo ''; ?></td>
                            <td><?php echo '7'; ?></td>
                            <td><?php echo ''; ?></td>

                        </tr>

                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <br>
</div>