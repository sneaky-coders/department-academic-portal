<?php
use yii\helpers\Html;
use yii\widgets\ActiveForm;
?>






<div class="container">
  
    <div class="content">
        <?php $form = ActiveForm::begin(); ?>
        <div class="user-details">
            <div  class="col-md-8">
            <div class="input-box">
                <span class="details"></span>
                <?php

$id= yii::$app->user->identity->user_id;


echo $form->field($model, 'user_id')

  ->hiddenInput(['value' => $id])

  ->label(false);


?> 
<div>
<?= $form->field($model, 'picture')->fileInput()->label('Upload Profile Picture') ?>
</div>


        <?= $form->field($model, 'xcgpa')->textInput()->label('Xth CGPA') ?>
            </div>
            </div>
         <div  class="col-md-8">
         <div class="input-box">
                <span class="details"></span>
                <?= $form->field($model, 'xiicgpa')->textInput()->label('XII CGPA') ?>
            </div>

            <div class="input-box">
                <span class="details"></span>
                <?= $form->field($model, 'sem1cgpa')->textInput()->label('SEMESTER 1 CGPA') ?>
            </div>

            <div class="input-box">
                <span class="details"></span>
                <?= $form->field($model, 'sem2cgpa')->textInput()->label('SEMESTER 2 CGPA') ?>
            </div>

            <div class="input-box">
                <span class="details"></span>
                <?= $form->field($model, 'sem3cgpa')->textInput()->label('SEMESTER 3 CGPA') ?>
            </div>

            <div class="input-box">
                <span class="details"></span>
                <?= $form->field($model, 'sem4cgpa')->textInput()->label('SEMESTER 4 CGPA') ?>
            </div>
         </div>
        </div>

        <div class="button">
            
            <?= Html::submitButton('Save', ['class' => 'button']) ?>
        </div>
        <?php ActiveForm::end(); ?>
    </div>
</div>
</div>


