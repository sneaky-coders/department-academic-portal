<!-- views/faculty/locate.php -->
<?php
use yii\helpers\Html;

$this->title = 'Locate Faculty';

if (isset($faculty->building)) {
    $building = $faculty->building;
    $buildingName = Html::encode($building->name);
    $room = Html::encode($building->room);
    $latitude = Html::encode($building->latitude);
    $longitude = Html::encode($building->longitude);

    echo "<h1>Location of Faculty: {$faculty->name}</h1>";
    echo "<p>Faculty Member is located in Building: {$buildingName}</p>";
    echo "<p>Faculty Member is located in Room No: {$room}</p>";
    echo "<p>Coordinates: Latitude {$latitude}, Longitude {$longitude}</p>";
} else {
    echo "<p>Faculty Member's location is not available.</p>";
}
