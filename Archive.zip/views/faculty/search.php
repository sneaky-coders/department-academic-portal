<!-- views/faculty/search.php -->
<?php
use yii\helpers\Html;
use yii\widgets\ActiveForm;

$this->title = 'Search Faculty';

$form = ActiveForm::begin([
    'action' => ['faculty/search'],
    'method' => 'get',
]);
?>

<div class="form-group">
    <?= $form->field($searchModel, 'query')->textInput(['placeholder' => 'Search faculty by name'])->label(false) ?>
</div>

<div class="form-group">
    <?= Html::submitButton('Search', ['class' => 'btn btn-primary']) ?>
</div>

<?php ActiveForm::end(); ?>
