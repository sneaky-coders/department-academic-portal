<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use app\models\Mentor;
use yii\helpers\ArrayHelper;
use kartik\select2\Select2;

/* @var $this yii\web\View */
/* @var $model app\models\Passedout */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="passedout-form">

    <div class="col-md-6">

        <?php $form = ActiveForm::begin(); ?>

        <?= $form->field($model, 'name')->textInput(['maxlength' => true]) ?>

        <?= $form->field($model, 'batch')->dropDownList(['prompt' => 'Select Batch', 1 => '2020', 2 => '2021', 3 => '2022', 4 => '2023']); ?>

        <?= $form->field($model, 'companyname')->textInput(['maxlength' => true]) ?>

        <?= $form->field($model, 'offerletter')->fileInput() ?>


        <?= $form->field($model, 'companyid')->textInput() ?>



        <?php $client = Mentor::find()->all();

        $data = ArrayHelper::map($client, 'id', 'name');

        ?>
        <?= $form->field($model, 'mentor_id')->label("Mentor")->widget(Select2::classname(), [
            'data' => $data,
            'language' => 'en',
            'options' => ['placeholder' => 'Search Mentor'],
            'pluginOptions' => [
                'allowClear' => true
            ],
        ]); ?>


        <div class="form-group">
            <?= Html::submitButton('Save', ['class' => 'btn btn-success']) ?>
        </div>

        <?php ActiveForm::end(); ?>

    </div>



</div>