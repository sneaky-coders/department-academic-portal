<!-- views/attendance/index.php -->
<?php
use yii\helpers\Html;
use yii\widgets\ActiveForm;

$this->title = 'Attendance Records';
?>

<h1>Attendance Records</h1>

<?php $form = ActiveForm::begin(); ?>

<table class="table">
    <thead>
        <tr>
            <th>User</th>
            <?php foreach ($subjects as $subject): ?>
                <th><?= $subject['subject'] ?></th>
            <?php endforeach; ?>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($users as $user): ?>
            <tr>
                <td><?= $user->username ?></td>
                <?php foreach ($subjects as $subject): ?>
                    <td>
                        <?= $form->field(new SubjectAttendance(), "[$user->id][$subject[subject]]attended")->checkbox([
                            'value' => 1,
                            'label' => false,
                        ])->label(false) ?>
                    </td>
                <?php endforeach; ?>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<div class="form-group">
    <?= Html::submitButton('Submit', ['class' => 'btn btn-primary']) ?>
</div>

<?php ActiveForm::end(); ?>
