<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\helpers\ArrayHelper;
use app\models\Questions;

/* @var $this yii\web\View */
/* @var $model app\models\Set2 */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="set2-form">

    <?php $form = ActiveForm::begin(); ?>







<p id="demo" style="float:right;font-size:15px">Ends In</p>

    <?php
  

$id= yii::$app->user->identity->user_id;


echo $form->field($model, 'user_id')

  ->hiddenInput(['value' => $id])

  ->label(false);
  


?>








    <div class="col-md-6">

    <?php
  

$usn= yii::$app->user->identity->usn;


echo $form->field($model, 'usn')

  ->hiddenInput(['value' => $usn])

  ->label(false);
  


?>



    <?= $form->field($model, 'total')->hiddenInput()->label(false) ?>

<?= $form->field($model, 'q1')->textInput(['maxlength' => true,'class' => 'q1'])->label($model->q1)->radioList([
  'a' => 'EFMAK',
  'b' => 'EFAMK',
  'c' => 'EFMIJ',
  'd' => 'EFMIK',
],['onClick' => 'getValue($(this).val());'])?> 

<?= $form->field($model, 'q2')->textInput(['maxlength' => true])->label("Q2. If AIRLINE is written as ENILRIA7, then RAILWAY will be written as -")->radioList([
   'a' => 'YAWLIAR7',
   'b' => 'YAWLIAR8',
   'c' => 'YAWILAR7',
   'd' => 'YAWILAR8',
],['onClick' => 'getValue($(this).val());'])?> 

<?= $form->field($model, 'q3')->textInput(['maxlength' => true])->label("Q3. If CAT is coded as PATC, JOY is coded as POYJ; similarly the word WING will be coded as -")->radioList([
   'a' => 'PIGNW',
   'b' => 'PINGW',
   'c' => 'PGNIW',
   'd' => 'PIWGN',
],['onClick' => 'getValue($(this).val());'])?> 

<?= $form->field($model, 'q4')->textInput(['maxlength' => true])->label("Q4. Which number should come next in the series 1, 2, 3, 10, ___")->radioList([
  'a' => '79',
  'b' => '99',
  'c' => '89',
  'd' => '98',
],['onClick' => 'getValue($(this).val());'])?> 

<?= $form->field($model, 'q5')->textInput(['maxlength' => true])->label("Q5. 	Which number is wrong in the series 2, 6, 15, 31, 56, 93?")->radioList([
   'a' => '6',
   'b' => '31',
   'c' => '56',
   'd' => '93',
],['onClick' => 'getValue($(this).val());'])?> 

<?= $form->field($model, 'q6')->textInput(['maxlength' => true])->label("Q6. The number comes next in the series 12, 36, 109, 329, ... -")->radioList([
   'a' => '900',
   'b' => '990',
   'c' => ' 890',
   'd' => 'None of Above',
],['onClick' => 'getValue($(this).val());'])?> 


<?= $form->field($model, 'q7')->textInput(['maxlength' => true])->label("Q7. 	The number comes after the series 8, 28, 116, 584, ...... -")->radioList([
   'a' => '3504',
   'b' => '3507',
   'c' => '3508',
   'd' => '3509',
],['onClick' => 'getValue($(this).val());'])?> 

<?= $form->field($model, 'q8')->textInput(['maxlength' => true])->label("Q8. 	What will be the next number in the series 13, 17, 19, 23, 29, ....")->radioList([
   'a' => '31',
   'b' => '33',
   'c' => '35',
   'd' => '37',
],['onClick' => 'getValue($(this).val());'])?> 

<?= $form->field($model, 'q9')->textInput(['maxlength' => true])->label("Q9. 	What will be the missing number in the series 196, 169, 144, __, 100, 81?")->radioList([
   'a' => ' 121',
   'b' => '120',
   'c' => '119',
   'd' => '118',
],['onClick' => 'getValue($(this).val());'])?> 

<?= $form->field($model, 'q10')->textInput(['maxlength' => true])->label("Q10. 	Which number comes next in the series 1536, 384, 96, ___?")->radioList([
    'a' => '23',
    'b' => '24',
    'c' => '28',
    'd' => '18',
],['onClick' => 'getValue($(this).val());'])?> 

<?= $form->field($model, 'q11')->textInput(['maxlength' => true])->label("Q11.  	If PINK is coded as 1691411, then RED will be coded as -")->radioList([
   'a' => '1963',
   'b' => '1854',
   'c' => '1853',
   'd' => '1954',
],['onClick' => 'getValue($(this).val());'])?> 


<?= $form->field($model, 'q12')->textInput(['maxlength' => true])->label("Q12. 	Which of the following is the odd one from the given alternatives?")->radioList([
  'a' => 'Driving',
  'b' => 'Diving',
  'c' => 'Swimming',
  'd' => 'Sailing',
],['onClick' => 'getValue($(this).val());'])?> 


    </div>

    <div class="col-md-6">


    <?= $form->field($model, 'q13')->textInput(['maxlength' => true])->label("Q13. 	Which of the following is the odd number from the given alternatives?")->radioList([
 'a' => '1090',
 'b' => '962',
 'c' => '626',
 'd' => '841',

],['onClick' => 'getValue($(this).val());'])?> 

<?= $form->field($model, 'q14')->textInput(['maxlength' => true])->label("Q14.  	Marathon is to race as hibernation is to -")->radioList([
  'a' => 'Winter',
  'b' => 'Summer',
  'c' => 'Sleep',
  'd' => ' Bear',
],['onClick' => 'getValue($(this).val());'])?> 

<?= $form->field($model, 'q15')->textInput(['maxlength' => true])->label("Q15. 	Hypsiphobia: Height :: Hylophobia: ?")->radioList([
 'a' => 'Forests',
 'b' => 'Animals',
 'c' => ' Water',
 'd' => 'All of the above.',
],['onClick' => 'getValue($(this).val());'])?> 


<?= $form->field($model, 'q16')->textInput(['maxlength' => true])->label("Q16. Were you a bird, you ______________ in the sky")->radioList([
  'a' => 'would fly',
  'b' => 'shall fly',
  'c' => 'should fly',
  'd' => 'shall have flown',
],['onClick' => 'getValue($(this).val());'])?> 


<?= $form->field($model, 'q17')->textInput(['maxlength' => true])->label("Q17. What is the H.C.F of 4/5, 6/8, 8/25.")->radioList([
  'a' => ' 1/200',
  'b' => '1/100',
  'c' => '1/5',
  'd' => ' 1/50',
],['onClick' => 'getValue($(this).val());'])?> 


<?= $form->field($model, 'q18')->textInput(['maxlength' => true])->label("Q18. Find the least number which when divided by 6, 7, 8, 9, and 12, leaves remainder 4 in each case?")->radioList([
   'a' => '508',
   'b' => '504',
   'c' => '606',
   'd' => '656',
],['onClick' => 'getValue($(this).val());'])?> 


<?= $form->field($model, 'q19')->textInput(['maxlength' => true])->label("Q19. The least number, which when divided by 3, 5, 7, 6, 8 leaves a remainder of 2 in each case is.")->radioList([
   'a' => '212',
   'b' => '722',
   'c' => '842',
   'd' => '282',
],['onClick' => 'getValue($(this).val());'])?> 


<?= $form->field($model, 'q20')->textInput(['maxlength' => true])->label("Q20. The HCF of two numbers is 98 and their LCM is 2352. The sum of the numbers may be")->radioList([
   'a' => '1078',
   'b' => ' 1398',
   'c' => '1426',
   'd' => '1484',
],['onClick' => 'getValue($(this).val());'])?> 


<?= $form->field($model, 'q21')->textInput(['maxlength' => true])->label("Q21. A 275m long train overtakes a man walking at 9km/h, in the same direction, in 18 seconds. How much time will it take to pass a 450m long tunnel with the same speed?")->radioList([
'a' => '50.50sec',
'b' => '65sec',
'c' => '56.64sec',
'd' => '40.7 sec',
],['onClick' => 'getValue($(this).val());'])?> 


<?= $form->field($model, 'q22')->textInput(['maxlength' => true])->label("Q22. Three men went together for Kashi Vishwanath Temple. Their steps measure 252 cm, 280 cm and 308 cm respectively. The minimum distance, each should cover so that all can cover the distance in complete steps is:")->radioList([
 'a' => '27,680',
 'b' => '27,094',
 'c' => '27,720',
 'd' => '27,730',
],['onClick' => 'getValue($(this).val());'])?> 


<?= $form->field($model, 'q23')->textInput(['maxlength' => true])->label("Q23. Train A crosses a tree in 17.5 seconds and also crosses a 250m long platform in 30 seconds. If the length of train B is 50 m less than that of A and the speed of train B is 18 kmph more than that of A, then find the time taken by train B crosses a 150m long tunnel.")->radioList([
 'a' => '24 seconds',
 'b' => '12 seconds',
 'c' => '18 seconds',
 'd' => '36 seconds',
],['onClick' => 'getValue($(this).val());'])?> 

<?= $form->field($model, 'q24')->textInput(['maxlength' => true])->label("Q24. The length of train A is 25% more than that of train B and the speed of train A is 20% more than that of B. If train A crosses a tree in 12 seconds and also crosses train B running in the same direction in 162 seconds, then find the speed of train B. ")->radioList([
'a' => '100 kmph',
'b' => '60 kmph',
'c' => '120 kmph',
'd' => '90 kmph',
],['onClick' => 'getValue($(this).val());'])?> 


<?= $form->field($model, 'q25')->textInput(['maxlength' => true])->label("Q25. A shopkeeper is selling a fan at a discount of 30% on the mark price. If the marked price is 20% above the cost price and the fan was sold for Rs.420 then the cost price is
")->radioList([
  'a' => 'RS.700',
  'b' => 'RS.500',
  'c' => 'RS.1200',
  'd' => 'RS.100',
],['onClick' => 'getValue($(this).val());'])?> 

    </div>




   
   

 



    <div class="form-group">
        <?= Html::submitButton('Save', [  'class' => 'btn btn-danger',
            'data' => [
                'confirm' => 'Are you sure you want to Submit?',
                'method' => 'post',
            ],]) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>



 

<script>

function getValue($value) {
  qt1 = $("input:radio[name='Set2[q1]']:checked").val();
   var q1,q2,q3,q4,q5,q6,q7,q8,q9,q10,q11,q12,q13,q14,q15,q16,q17,q18,q19,q20,q21,q22,q23,q24,q25;
   var total;
   if(qt1 == 'c')
   {
     q1 = 1;
  
   }
   else
   {
      q1 = 0;
     
   }
   
   qt2 = $("input:radio[name='Set2[q2]']:checked").val();
   if(qt2 == 'a')
   {
     q2 = 1;
  
   }
   else
   {
      q2 = 0;
     
   }
   qt3 = $("input:radio[name='Set2[q3]']:checked").val();
   if(qt3 == 'b')
   {
     q3 = 1;
  
   }
   else
   {
      q3 = 0;
     
   }
   qt4 = $("input:radio[name='Set2[q4]']:checked").val();
   if(qt4 == 'b')
   {
     q4 = 1;
  
   }
   else
   {
      q4 = 0;
     
   }
   qt5 = $("input:radio[name='Set2[q5]']:checked").val();
   if(qt5 == 'd')
   {
     q5 = 1;
  
   }
   else
   {
      q5 = 0;
     
   }
   qt6 = $("input:radio[name='Set2[q6]']:checked").val();
   if(qt6 == 'b')
   {
     q6 = 1;
  
   }
   else
   {
      q6 = 0;
     
   }
   qt7 = $("input:radio[name='Set2[q7]']:checked").val();
   if(qt7 == 'c')
   {
     q7 = 1;
  
   }
   else
   {
      q7 = 0;
     
   }
   qt8 = $("input:radio[name='Set2[q8]']:checked").val();
   if(qt8 == 'a')
   {
     q8 = 1;
  
   }
   else
   {
      q8 = 0;
     
   }
   qt9 = $("input:radio[name='Set2[q9]']:checked").val();
   if(qt9 == 'a')
   {
     q9 = 1;
  
   }
   else
   {
      q9 = 0;
     
   }
   qt10 = $("input:radio[name='Set2[q10]']:checked").val();
   if(qt10 == 'b')
   {
     q10 = 1;
  
   }
   else
   {
      q10 = 0;
     
   }
   qt11 = $("input:radio[name='Set2[q11]']:checked").val();
   if(qt11 == 'b')
   {
     q11 = 1;
  
   }
   else
   {
      q11 = 0;
     
   }
   qt12 = $("input:radio[name='Set2[q12]']:checked").val();
   if(qt12 == 'a')
   {
     q12 = 1;
  
   }
   else
   {
      q12 = 0;
     
   }
   qt13 = $("input:radio[name='Set2[q13]']:checked").val();
   if(qt13 == 'd')
   {
     q13 = 1;
  
   }
   else
   {
      q13 = 0;
     
   }
   qt14 = $("input:radio[name='Set2[q14]']:checked").val();
   if(qt14 == 'c')
   {
     q14 = 1;
  
   }
   else
   {
      q14 = 0;
     
   }
   qt15 = $("input:radio[name='Set2[q15]']:checked").val();
   if(qt15 == 'a')
   {
     q15 = 1;
  
   }
   else
   {
      q15 = 0;
     
   }
   qt16 = $("input:radio[name='Set2[q16]']:checked").val();
   if(qt16 == 'a')
   {
     q16 = 1;
  
   }
   else
   {
      q16 = 0;
     
   }
   qt17 = $("input:radio[name='Set2[q17]']:checked").val();
   if(qt17 == 'b')
   {
     q17 = 1;
  
   }
   else
   {
      q17 = 0;
     
   }
   qt18 = $("input:radio[name='Set2[q18]']:checked").val();
   if(qt18 == 'a')
   {
     q18 = 1;
  
   }
   else
   {
      q18 = 0;
     
   }
   qt19 = $("input:radio[name='Set2[q19]']:checked").val();
   if(qt19 == 'c')
   {
     q19 = 1;
  
   }
   else
   {
      q19 = 0;
     
   }
   qt20 = $("input:radio[name='Set2[q20]']:checked").val();
   if(qt20 == 'a')
   {
     q20 = 1;
  
   }
   else
   {
      q20 = 0;
     
   }
   qt21 = $("input:radio[name='Set2[q21]']:checked").val();
   if(qt21 == 'd')
   {
     q21 = 1;
  
   }
   else
   {
      q21 = 0;
     
   }
   qt22 = $("input:radio[name='Set2[q22]']:checked").val();
   if(qt22 == 'c')
   {
     q22 = 1;
  
   }
   else
   {
      q22 = 0;
     
   }
   qt23 = $("input:radio[name='Set2[q23]']:checked").val();
   if(qt23 == 'c')
   {
     q23 = 1;
  
   }
   else
   {
      q23 = 0;
     
   }
   qt24 = $("input:radio[name='Set2[q24]']:checked").val();
   if(qt24 == 'b')
   {
     q24 = 1;
  
   }
   else
   {
      q24 = 0;
     
   }
   qt25 = $("input:radio[name='Set2[q25]']:checked").val();
   if(qt25 == 'b')
   {
     q25 = 1;
  
   }
   else
   {
      q25 = 0;
     
   }
   total =  q1+q2+q3+q4+q5+q6+q7+q8+q9+q10+q11+q12+q13+q14+q15+q16+q17+q18+q19+q20+q21+q22+q23+q24+q25;
  
        
   $('#set2-total').val(total)
   console.log(total)
}




</script>

<script>
// Set the date we're counting down to
var countDownDate = new Date("July 31, 2023 19:30:00").getTime();

// Update the count down every 1 second
var x = setInterval(function() {

  // Get today's date and time
  var now = new Date().getTime();

  // Find the distance between now and the count down date
  var distance = countDownDate - now;

  // Time calculations for days, hours, minutes and seconds
  var days = Math.floor(distance / (1000 * 60 * 60 * 24));
  var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
  var seconds = Math.floor((distance % (1000 * 60)) / 1000);

  // Display the result in the element with id="demo"
  document.getElementById("demo").innerHTML = " Ends In: "+days + "d " + hours + "h "
  + minutes + "m " + seconds + "s ";
   var redirecct;
  // If the count down is finished, write some text
  if (distance < 0) {
    clearInterval(x);
      redirecct == -1;
    //document.getElementById("w0").submit();
  }

  if (redirecct < 0) {
    

      window.location.replace('../site');
  }


 
}, 1000);
</script>