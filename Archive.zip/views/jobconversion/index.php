<?php

use yii\helpers\Html;
use yii\grid\GridView;

/* @var $this yii\web\View */
/* @var $searchModel app\models\SearchJobconversion */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Jobconversions';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="jobconversion-index">

    <h1><?= Html::encode($this->title) ?></h1>

    <p>
        <?= Html::a('Create Jobconversion', ['create'], ['class' => 'btn btn-success']) ?>
    </p>

    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

          //  'id',
          [
            'label' => "Student Name",
            'attribute' => 'student_name',
            'value' => 'user.username'
        ],
        'isplaced',
            'type',
            'company',
            'companyid',
            [
                'attribute'=>'intershipoffer',
                'format'=>'raw',
                'value' => function($data)
                {
                return
                Html::a('Download file', ['/uploads/'.$data->intershipoffer, 'id' => $data->id,'intershipoffer' => $data->intershipoffer],['class' => 'btn btn-primary','target'=>'_blank']);
        
                }
                ],
            
                [
                    'attribute'=>'offerletter',
                    'format'=>'raw',
                    'value' => function($data)
                    {
                    return
                    Html::a('Download file', ['/uploads/'.$data->offerletter, 'id' => $data->id,'offerletter' => $data->offerletter],['class' => 'btn btn-primary','target'=>'_blank']);
            
                    }
                    ],
            
            //'created_at',
            //'updated_at',
            //'user_id',

            ['class' => 'yii\grid\ActionColumn'],
        ],
    ]); ?>


</div>
