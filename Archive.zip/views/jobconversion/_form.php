<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\Jobconversion */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="jobconversion-form" style="width: 30%;">

    <?php $form = ActiveForm::begin(['options' => ['enctype' => 'multipart/form-data']]); ?>

    <?= $form->field($model, 'isplaced')->dropDownList(['prompt'=>' Are You Placed','Yes' => 'Yes', 'No' => 'No'])->label("Are You Placed"); ?>

    <?= $form->field($model, 'type')->dropDownList(['prompt'=>' Select Type of Placement','On Campus' => 'On Campus', 'Off Campus' => 'Off Campus'])->label("Type of Placement"); ?>

    <?= $form->field($model, 'company')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'intershipoffer')->fileInput() ?>

    <?= $form->field($model, 'offerletter')->fileInput() ?>

    <?= $form->field($model, 'companyid')->textInput(['maxlength' => true])->label("Company Staff ID") ?>

 

<?php
  

$id= yii::$app->user->identity->user_id;
  
echo $form->field($model, 'user_id')->hiddenInput(['value' => $id])->label(false);
    
  
  
  ?>

    <div class="form-group">
        <?= Html::submitButton('Save', ['class' => 'btn btn-success']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
