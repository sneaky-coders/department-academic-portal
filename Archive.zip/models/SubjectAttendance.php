<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "subject_attendance".
 *
 * @property int $id
 * @property int $user_id
 * @property string $subject
 * @property string $date
 * @property int|null $attended
 * @property string $created_at
 * @property string|null $updated_at
 */
class SubjectAttendance extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'subject_attendance';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['user_id', 'subject', 'date'], 'required'],
            [['user_id', 'attended'], 'integer'],
            [['date', 'created_at', 'updated_at'], 'safe'],
            [['subject'], 'string', 'max' => 255],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'user_id' => 'User ID',
            'subject' => 'Subject',
            'date' => 'Date',
            'attended' => 'Attended',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
        ];
    }
}
