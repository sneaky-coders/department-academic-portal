<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "jobconversion".
 *
 * @property int $id
 * @property string $intershipoffer
 * @property string $isplaced
 * @property string $type
 * @property string $company
 * @property string $offerletter
 * @property string $companyid
 * @property string $created_at
 * @property string $updated_at
 * @property int $user_id
 *
 * @property Users $user
 */
class Jobconversion extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'jobconversion';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['intershipoffer', 'isplaced', 'type', 'company', 'offerletter', 'companyid', 'user_id'], 'required'],
            [['created_at', 'updated_at'], 'safe'],
            [['user_id'], 'integer'],
            [['intershipoffer'], 'string', 'max' => 100],
            [['isplaced', 'type', 'company'], 'string', 'max' => 20],
            [['offerletter', 'companyid'], 'string', 'max' => 50],
            [['user_id'], 'exist', 'skipOnError' => true, 'targetClass' => Users::className(), 'targetAttribute' => ['user_id' => 'user_id']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'intershipoffer' => 'Intershipoffer',
            'isplaced' => 'Isplaced',
            'type' => 'Type',
            'company' => 'Company',
            'offerletter' => 'Offerletter',
            'companyid' => 'Companyid',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
            'user_id' => 'User ID',
        ];
    }

    /**
     * Gets query for [[User]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getUser()
    {
        return $this->hasOne(Users::className(), ['user_id' => 'user_id']);
    }
}
