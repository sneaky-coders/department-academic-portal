<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "set2".
 *
 * @property int $id
 * @property string $usn
 * @property int $user_id
 * @property string $category
 * @property string $q1
 * @property string $q2
 * @property string $q3
 * @property string $q4
 * @property string $q5
 * @property string $q6
 * @property string $q7
 * @property string $q8
 * @property string $q9
 * @property string $q10
 * @property string $q11
 * @property string $q12
 * @property string $q13
 * @property string $q14
 * @property string $q15
 * @property string $q16
 * @property string $q17
 * @property string $q18
 * @property string $q19
 * @property string $q20
 * @property string $q21
 * @property string $q22
 * @property string $q23
 * @property string $q24
 * @property string $q25
 * @property string $total
 * @property string $test_date
 * @property string $created_at
 * @property string $updated_at
 *
 * @property Users $user
 */
class Set2 extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'set2';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['usn', 'user_id','total'], 'required'],
            [['user_id'], 'integer'],
            [['user_id'],'unique'],
            [['test_date', 'created_at', 'updated_at'], 'safe'],
            [['usn', 'category', 'q1', 'q2', 'q3', 'q4', 'q5', 'q6', 'q7', 'q8', 'q9', 'q10', 'q11', 'q12', 'q13', 'q14', 'q15', 'q16', 'q17', 'q18', 'q19', 'q20', 'q21', 'q22', 'q23', 'q24', 'q25', 'total'], 'string', 'max' => 100],
            [['user_id'], 'exist', 'skipOnError' => true, 'targetClass' => Users::className(), 'targetAttribute' => ['user_id' => 'user_id']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'usn' => 'Usn',
            'user_id' => 'User ID',
            'category' => 'Category',
            'q1' => 'Q1',
            'q2' => 'Q2',
            'q3' => 'Q3',
            'q4' => 'Q4',
            'q5' => 'Q5',
            'q6' => 'Q6',
            'q7' => 'Q7',
            'q8' => 'Q8',
            'q9' => 'Q9',
            'q10' => 'Q10',
            'q11' => 'Q11',
            'q12' => 'Q12',
            'q13' => 'Q13',
            'q14' => 'Q14',
            'q15' => 'Q15',
            'q16' => 'Q16',
            'q17' => 'Q17',
            'q18' => 'Q18',
            'q19' => 'Q19',
            'q20' => 'Q20',
            'q21' => 'Q21',
            'q22' => 'Q22',
            'q23' => 'Q23',
            'q24' => 'Q24',
            'q25' => 'Q25',
            'total' => 'Total',
            'test_date' => 'Test Date',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
        ];
    }

    /**
     * Gets query for [[User]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getUser()
    {
        return $this->hasOne(Users::className(), ['user_id' => 'user_id']);
    }
}
