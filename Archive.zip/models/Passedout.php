<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "passedout".
 *
 * @property int $id
 * @property string $name
 * @property string $batch
 * @property string $companyname
 * @property string $offerletter
 * @property int $companyid
 * @property string $created_at
 * @property string|null $updated_at
 * @property int $mentor_id
 *
 * @property Mentor $mentor
 */
class Passedout extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'passedout';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['name', 'batch', 'companyname', 'offerletter', 'companyid', 'mentor_id'], 'required'],
            [['mentor_id'], 'integer'],
            [['created_at', 'updated_at'], 'safe'],
            [['name', 'batch', 'companyname', 'offerletter','companyid'], 'string', 'max' => 200],
            [['mentor_id'], 'exist', 'skipOnError' => true, 'targetClass' => Mentor::className(), 'targetAttribute' => ['mentor_id' => 'id']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'name' => 'Full Name',
            'batch' => 'Passed Out Batch',
            'companyname' => 'Company Name',
            'offerletter' => 'Upload Offer Letter',
            'companyid' => 'Enter Company id',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
            'mentor_id' => 'Mentor ID',
        ];
    }

    /**
     * Gets query for [[Mentor]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getMentor()
    {
        return $this->hasOne(Mentor::className(), ['id' => 'mentor_id']);
    }
}
