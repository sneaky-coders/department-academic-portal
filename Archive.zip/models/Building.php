<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "building".
 *
 * @property int $id
 * @property string $name
 * @property string $room
 * @property string $latitude
 * @property string $longitude
 * @property string $created_at
 * @property string|null $updated_at
 *
 * @property Faculty[] $faculties
 */
class Building extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'building';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['name', 'room', 'latitude', 'longitude'], 'required'],
            [['created_at', 'updated_at'], 'safe'],
            [['name', 'latitude', 'longitude'], 'string', 'max' => 200],
            [['room'], 'string', 'max' => 50],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'name' => 'Building Name',
            'room' => 'Room No',
            'latitude' => 'Latitude',
            'longitude' => 'Longitude',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
        ];
    }

    /**
     * Gets query for [[Faculties]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getFaculties()
    {
        return $this->hasMany(Faculty::className(), ['building_id' => 'id']);
    }
}
