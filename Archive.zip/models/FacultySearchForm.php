<?php

namespace app\models;

use yii\base\Model;

class FacultySearchForm extends Model
{
    public $query;

    public function rules()
    {
        return [
            [['query'], 'string'],
        ];
    }
}
