<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "profile".
 *
 * @property int $id
 * @property int $user_id
 * @property string $picture
 * @property string $xcgpa
 * @property string $xiicgpa
 * @property string $sem1cgpa
 * @property string $sem2cgpa
 * @property string $sem3cgpa
 * @property string $sem4cgpa
 * @property string $created_at
 * @property string $updated_at
 *
 * @property Users $user
 */
class Profile extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'profile';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['user_id', 'xcgpa', 'xiicgpa', 'sem1cgpa'], 'required'],
            [['user_id'], 'integer'],
            [['created_at', 'updated_at'], 'safe'],
            [['picture'], 'string', 'max' => 100],
            [['xcgpa', 'xiicgpa', 'sem1cgpa', 'sem2cgpa', 'sem3cgpa', 'sem4cgpa'], 'string', 'max' => 20],
            [['user_id'], 'exist', 'skipOnError' => true, 'targetClass' => Users::className(), 'targetAttribute' => ['user_id' => 'user_id']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'user_id' => 'User ID',
            'picture' => 'Picture',
            'xcgpa' => 'Xcgpa',
            'xiicgpa' => 'Xiicgpa',
            'sem1cgpa' => 'Sem1cgpa',
            'sem2cgpa' => 'Sem2cgpa',
            'sem3cgpa' => 'Sem3cgpa',
            'sem4cgpa' => 'Sem4cgpa',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
        ];
    }

    /**
     * Gets query for [[User]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getUser()
    {
        return $this->hasOne(Users::className(), ['user_id' => 'user_id']);
    }
}
