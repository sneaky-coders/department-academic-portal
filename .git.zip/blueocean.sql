-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Sep 20, 2020 at 01:12 PM
-- Server version: 10.4.10-MariaDB
-- PHP Version: 7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `blueocean`
--

-- --------------------------------------------------------

--
-- Table structure for table `buyer`
--

CREATE TABLE `buyer` (
  `buyer_id` int(11) NOT NULL,
  `name` varchar(25) NOT NULL,
  `email` varchar(100) NOT NULL,
  `TPIN` text NOT NULL,
  `contact_person_name` varchar(25) NOT NULL,
  `contact_person_number` int(10) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE current_timestamp(),
  `is_deleted` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `buyer`
--

INSERT INTO `buyer` (`buyer_id`, `name`, `email`, `TPIN`, `contact_person_name`, `contact_person_number`, `created_at`, `updated_at`, `is_deleted`) VALUES
(2, 'john1', 'john@gmail', '3432', 'doe', 1312232334, '2020-07-15 12:32:31', '2020-07-20 07:21:21', 0),
(3, 'test', 'test', '243', 'test', 123213, '2020-07-20 07:23:30', '2020-07-20 07:24:03', 1),
(4, 'doe', 'doe@gmail', '24332', 'test', 123213, '2020-07-27 15:35:52', '0000-00-00 00:00:00', 0),
(5, 'test', 'doe@gmail', '2433223', 'test 2', 1312232334, '2020-09-05 15:52:48', '2020-09-05 15:52:57', 0);

-- --------------------------------------------------------

--
-- Table structure for table `consumables`
--

CREATE TABLE `consumables` (
  `consumables_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `supplier_id` int(11) NOT NULL,
  `raw_material_id` int(11) NOT NULL,
  `currency_id` int(11) NOT NULL,
  `price` double NOT NULL,
  `vat` double NOT NULL,
  `quantity` double NOT NULL,
  `units_id` int(11) NOT NULL,
  `remarks` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE current_timestamp(),
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `consumables`
--

INSERT INTO `consumables` (`consumables_id`, `date`, `supplier_id`, `raw_material_id`, `currency_id`, `price`, `vat`, `quantity`, `units_id`, `remarks`, `created_at`, `updated_at`, `is_deleted`) VALUES
(1, '2020-09-08', 5, 3, 6, 324444, 16, 200, 1, 'asd', '2020-09-07 05:38:54', '2020-09-18 13:27:47', 0),
(2, '2020-09-17', 4, 3, 6, 30000, 18, 500, 1, 'asd', '2020-09-07 06:21:15', '0000-00-00 00:00:00', 0);

-- --------------------------------------------------------

--
-- Table structure for table `consumption`
--

CREATE TABLE `consumption` (
  `consumption_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `raw_material_id` int(11) NOT NULL,
  `mine_location_id` int(11) NOT NULL,
  `quantity` double NOT NULL,
  `cost` double NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE current_timestamp(),
  `is_delete` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `consumption`
--

INSERT INTO `consumption` (`consumption_id`, `date`, `raw_material_id`, `mine_location_id`, `quantity`, `cost`, `created_at`, `updated_at`, `is_delete`) VALUES
(1, '2020-07-03', 3, 3, 2.2, 121.23, '2020-07-28 07:12:50', '2020-08-06 05:59:50', 0),
(2, '2020-07-03', 3, 3, 32, 3242, '2020-07-28 08:14:14', '2020-08-06 05:59:50', 0),
(3, '2020-08-01', 2, 5, 123, 12312, '2020-08-06 06:03:23', '2020-08-06 06:03:42', 0);

-- --------------------------------------------------------

--
-- Table structure for table `currency`
--

CREATE TABLE `currency` (
  `currency_id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE current_timestamp(),
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `currency`
--

INSERT INTO `currency` (`currency_id`, `name`, `created_at`, `updated_at`, `is_deleted`) VALUES
(1, 'Dollar', '2020-07-24 06:58:09', '2020-09-05 15:46:58', 0),
(6, 'Rupee', '2020-09-05 15:45:55', '0000-00-00 00:00:00', 0);

-- --------------------------------------------------------

--
-- Table structure for table `daily_works`
--

CREATE TABLE `daily_works` (
  `daily_works_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `nature_of_job` varchar(90) NOT NULL,
  `location` text NOT NULL,
  `mine_location_id` int(11) NOT NULL,
  `resources_employed` text NOT NULL,
  `distance_travelled` varchar(80) NOT NULL,
  `vehicles_used` varchar(80) NOT NULL,
  `cost_incurred` double NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE current_timestamp(),
  `is_delete` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `daily_works`
--

INSERT INTO `daily_works` (`daily_works_id`, `date`, `nature_of_job`, `location`, `mine_location_id`, `resources_employed`, `distance_travelled`, `vehicles_used`, `cost_incurred`, `created_at`, `updated_at`, `is_delete`) VALUES
(1, '2020-07-01', 'edas', 'goa', 3, 'as', '2131', '2', 213, '2020-07-30 10:51:58', '2020-08-06 06:24:27', 0),
(2, '2020-08-27', 'asd', 'margao', 3, 'asd', '12km', '20', 10000, '2020-08-04 07:55:15', '0000-00-00 00:00:00', 0),
(3, '2020-08-21', 'asd', 'goa', 5, 'asd', '20km', 'asd', 4500, '2020-08-04 10:00:22', '0000-00-00 00:00:00', 0),
(4, '2020-09-09', 'edas', 'margao', 5, 'asd', '2131', '20', 10000, '2020-09-05 09:46:11', '0000-00-00 00:00:00', 0);

-- --------------------------------------------------------

--
-- Table structure for table `dispatch`
--

CREATE TABLE `dispatch` (
  `dispatch_id` int(11) NOT NULL,
  `mine_location_id` int(11) NOT NULL,
  `sales_contract_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `quantity_dispatched` double NOT NULL,
  `quantity_received` double NOT NULL,
  `exchange_rate` double NOT NULL,
  `trailer_no` varchar(100) NOT NULL,
  `type_of_dispatch` enum('Mined','Procured') NOT NULL,
  `truck_no` varchar(25) NOT NULL,
  `driver_name` varchar(50) NOT NULL,
  `driver_contact_no` varchar(15) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE current_timestamp(),
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `dispatch`
--

INSERT INTO `dispatch` (`dispatch_id`, `mine_location_id`, `sales_contract_id`, `date`, `quantity_dispatched`, `quantity_received`, `exchange_rate`, `trailer_no`, `type_of_dispatch`, `truck_no`, `driver_name`, `driver_contact_no`, `created_at`, `updated_at`, `is_deleted`) VALUES
(10, 3, 5, '2020-09-04', 12, 23, 1, '', 'Mined', 'GA09R8822', 'john', '89676897', '2020-09-04 06:09:36', '0000-00-00 00:00:00', 0),
(11, 3, 6, '2020-09-12', 23, 23, 1, '', 'Mined', 'GA09R8232', 'asd', '89676897756', '2020-09-04 06:12:52', '0000-00-00 00:00:00', 0),
(12, 3, 6, '2020-09-26', 12, 23, 211, '3554464', 'Procured', 'GA09R8232', 'sa', '89676897', '2020-09-18 10:52:13', '0000-00-00 00:00:00', 0);

-- --------------------------------------------------------

--
-- Table structure for table `equipment`
--

CREATE TABLE `equipment` (
  `equipment_id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `mine_location_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE current_timestamp(),
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `equipment`
--

INSERT INTO `equipment` (`equipment_id`, `name`, `mine_location_id`, `created_at`, `updated_at`, `is_deleted`) VALUES
(3, 'Equipment a', 3, '2020-09-05 16:06:07', '0000-00-00 00:00:00', 0),
(4, 'Equipment b', 5, '2020-09-05 16:20:20', '0000-00-00 00:00:00', 0),
(5, 'Equipment c', 4, '2020-09-19 07:39:26', '0000-00-00 00:00:00', 0);

-- --------------------------------------------------------

--
-- Table structure for table `GRN`
--

CREATE TABLE `GRN` (
  `grn_id` int(11) NOT NULL,
  `purchase_contract_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `supplier_id` int(11) NOT NULL,
  `po_no` varchar(50) NOT NULL,
  `raw_material_id` int(11) NOT NULL,
  `quantity_received` double NOT NULL,
  `exchange_rate` double NOT NULL,
  `truck_no` varchar(40) NOT NULL,
  `driver_name` varchar(50) NOT NULL,
  `remark` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE current_timestamp(),
  `is_delete` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `GRN`
--

INSERT INTO `GRN` (`grn_id`, `purchase_contract_id`, `date`, `supplier_id`, `po_no`, `raw_material_id`, `quantity_received`, `exchange_rate`, `truck_no`, `driver_name`, `remark`, `created_at`, `updated_at`, `is_delete`) VALUES
(19, 2, '2020-09-25', 4, '347624354358', 2, 32, 34, 'GA092222', 'john22', 'ghtfc', '2020-09-05 09:48:41', '2020-09-07 06:30:34', 0),
(20, 3, '2020-10-02', 4, '34762435435', 2, 22, 34, 'GA092222', 'te', 'awe', '2020-09-05 09:52:28', '0000-00-00 00:00:00', 0);

-- --------------------------------------------------------

--
-- Table structure for table `machine`
--

CREATE TABLE `machine` (
  `machine_id` int(11) NOT NULL,
  `machine_name` varchar(30) NOT NULL,
  `mine_location_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE current_timestamp(),
  `is_deleted` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `machine`
--

INSERT INTO `machine` (`machine_id`, `machine_name`, `mine_location_id`, `created_at`, `updated_at`, `is_deleted`) VALUES
(7, 'machine A', 4, '2020-09-02 14:41:00', '2020-09-05 15:50:21', 0),
(8, 'machine b', 4, '2020-09-02 15:05:06', '0000-00-00 00:00:00', 0),
(9, 'machine c', 3, '2020-09-02 15:05:18', '0000-00-00 00:00:00', 0),
(10, 'machine d', 5, '2020-09-02 15:05:29', '0000-00-00 00:00:00', 0),
(11, 'machine e', 4, '2020-09-02 15:05:40', '0000-00-00 00:00:00', 0);

-- --------------------------------------------------------

--
-- Table structure for table `maintenance`
--

CREATE TABLE `maintenance` (
  `maintenance_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `mine_location_id` int(11) NOT NULL,
  `nature_of_maintenance` enum('Vehicle','Electrical','Mechanical','Other') NOT NULL,
  `type_of_maintenance` enum('Scheduled','Breakdown') NOT NULL,
  `details` text NOT NULL,
  `resources_employed` varchar(100) NOT NULL,
  `other_expenses` double NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE current_timestamp(),
  `is_delete` tinyint(4) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `maintenance`
--

INSERT INTO `maintenance` (`maintenance_id`, `date`, `mine_location_id`, `nature_of_maintenance`, `type_of_maintenance`, `details`, `resources_employed`, `other_expenses`, `created_at`, `updated_at`, `is_delete`) VALUES
(10, '2020-09-17', 3, 'Mechanical', 'Breakdown', 'ads', 'abcd', 45, '2020-09-20 11:03:56', '0000-00-00 00:00:00', 0);

-- --------------------------------------------------------

--
-- Table structure for table `maintenance_equipment`
--

CREATE TABLE `maintenance_equipment` (
  `maintenance_equipment_id` int(11) NOT NULL,
  `maintenance_id` int(11) NOT NULL,
  `equipment_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `maintenance_equipment`
--

INSERT INTO `maintenance_equipment` (`maintenance_equipment_id`, `maintenance_id`, `equipment_id`, `created_at`) VALUES
(28, 10, 5, '2020-09-20 11:04:36'),
(29, 10, 4, '2020-09-20 11:04:36');

-- --------------------------------------------------------

--
-- Table structure for table `maintenance_quantity`
--

CREATE TABLE `maintenance_quantity` (
  `maintenance_quantity_id` int(11) NOT NULL,
  `maintenance_id` int(11) NOT NULL,
  `raw_material_id` int(11) NOT NULL,
  `quantity` double NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `maintenance_quantity`
--

INSERT INTO `maintenance_quantity` (`maintenance_quantity_id`, `maintenance_id`, `raw_material_id`, `quantity`, `created_at`) VALUES
(46, 10, 4, 12, '2020-09-20 11:11:51'),
(47, 10, 3, 1, '2020-09-20 11:11:51');

-- --------------------------------------------------------

--
-- Table structure for table `mine_location`
--

CREATE TABLE `mine_location` (
  `mine_location_id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `address` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE current_timestamp(),
  `is_deleted` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `mine_location`
--

INSERT INTO `mine_location` (`mine_location_id`, `name`, `address`, `created_at`, `updated_at`, `is_deleted`) VALUES
(3, 'location 1', 'asdhg', '2020-08-01 06:53:03', '2020-09-05 15:55:51', 0),
(4, 'location 2', 'ad', '2020-08-01 06:53:14', '0000-00-00 00:00:00', 0),
(5, 'location 3', 'asd hv', '2020-08-01 06:53:25', '2020-09-05 15:55:11', 0),
(6, 'location 4', 'asd', '2020-09-05 15:56:03', '0000-00-00 00:00:00', 0);

-- --------------------------------------------------------

--
-- Table structure for table `operation`
--

CREATE TABLE `operation` (
  `operation_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `mine_location_id` int(30) NOT NULL,
  `other_costs` double NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE current_timestamp(),
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `operation`
--

INSERT INTO `operation` (`operation_id`, `date`, `mine_location_id`, `other_costs`, `created_at`, `updated_at`, `is_deleted`) VALUES
(13, '2020-09-24', 4, 40, '2020-09-03 12:53:46', '0000-00-00 00:00:00', 0),
(14, '2020-09-05', 3, 12234, '2020-09-04 06:06:10', '0000-00-00 00:00:00', 0);

-- --------------------------------------------------------

--
-- Table structure for table `operation_data`
--

CREATE TABLE `operation_data` (
  `operation_data_id` int(11) NOT NULL,
  `operation_id` int(11) NOT NULL,
  `machine_id` int(11) NOT NULL,
  `hours` double NOT NULL,
  `cost_of_machine_operation` double NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `operation_data`
--

INSERT INTO `operation_data` (`operation_data_id`, `operation_id`, `machine_id`, `hours`, `cost_of_machine_operation`, `created_at`, `updated_at`) VALUES
(35, 14, 9, 23, 20000, '2020-09-04 06:06:10', '0000-00-00 00:00:00'),
(39, 13, 7, 111, 10000, '2020-09-17 10:23:15', '0000-00-00 00:00:00'),
(40, 13, 8, 222, 20000, '2020-09-17 10:23:15', '0000-00-00 00:00:00'),
(41, 13, 11, 0, 1.4, '2020-09-17 10:23:15', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `product_id` int(11) NOT NULL,
  `product_name` varchar(25) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE current_timestamp(),
  `is_delete` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`product_id`, `product_name`, `created_at`, `updated_at`, `is_delete`) VALUES
(26, 'p1', '2020-07-23 16:43:15', '2020-09-05 15:33:07', 0),
(27, 'p2', '2020-07-23 16:43:50', '0000-00-00 00:00:00', 0),
(28, 'test prod', '2020-07-24 06:16:51', '2020-07-24 06:17:12', 0);

-- --------------------------------------------------------

--
-- Table structure for table `production`
--

CREATE TABLE `production` (
  `production_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `mine_location_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` double DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE current_timestamp(),
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `production`
--

INSERT INTO `production` (`production_id`, `date`, `mine_location_id`, `product_id`, `quantity`, `created_at`, `updated_at`, `is_deleted`) VALUES
(33, '2020-08-06', 3, 26, 123, '2020-08-01 07:35:56', '2020-08-01 07:37:47', 1),
(34, '2020-08-07', 3, 26, 12, '2020-08-01 07:39:04', '2020-08-01 08:12:02', 1),
(35, '2020-08-20', 4, 26, 2122, '2020-08-01 07:39:30', '2020-08-01 08:12:04', 1),
(36, '2020-08-22', 3, 26, 211, '2020-08-01 08:13:51', '0000-00-00 00:00:00', 0),
(37, '2020-08-13', 4, 27, 132, '2020-08-01 08:14:23', '2020-08-01 08:16:50', 0),
(39, '2020-08-01', 4, 27, 12, '2020-08-06 07:39:07', '2020-08-06 07:41:23', 0),
(40, '2020-09-24', 4, 26, 7, '2020-09-04 06:24:14', '2020-09-04 06:24:25', 0);

-- --------------------------------------------------------

--
-- Table structure for table `production_analysis`
--

CREATE TABLE `production_analysis` (
  `production_analysis_id` int(11) NOT NULL,
  `production_id` int(11) NOT NULL,
  `component_id` int(11) NOT NULL,
  `value` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `production_analysis`
--

INSERT INTO `production_analysis` (`production_analysis_id`, `production_id`, `component_id`, `value`) VALUES
(68, 34, 28, 'as'),
(69, 34, 29, 'aad'),
(70, 35, 29, 'aa'),
(71, 36, 28, 'a'),
(72, 36, 29, 'a'),
(76, 37, 30, 'aaa'),
(79, 39, 30, 'asd'),
(82, 40, 28, 'abc'),
(83, 40, 29, 'asd');

-- --------------------------------------------------------

--
-- Table structure for table `product_component`
--

CREATE TABLE `product_component` (
  `product_component_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `name` varchar(25) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product_component`
--

INSERT INTO `product_component` (`product_component_id`, `product_id`, `name`, `created_at`, `updated_at`) VALUES
(28, 26, 'c1', '2020-07-23 16:43:15', '0000-00-00 00:00:00'),
(29, 26, 'c2', '2020-07-23 16:43:15', '0000-00-00 00:00:00'),
(30, 27, 'c11', '2020-07-23 16:43:51', '0000-00-00 00:00:00'),
(31, 28, 'com1', '2020-07-24 06:16:51', '0000-00-00 00:00:00'),
(32, 28, 'com2', '2020-07-24 06:16:51', '0000-00-00 00:00:00'),
(33, 28, 'com3', '2020-07-24 06:16:51', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `product_grade`
--

CREATE TABLE `product_grade` (
  `product_grade_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `name` varchar(25) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product_grade`
--

INSERT INTO `product_grade` (`product_grade_id`, `product_id`, `name`, `created_at`, `updated_at`) VALUES
(30, 26, 'g1', '2020-07-23 16:43:15', '0000-00-00 00:00:00'),
(31, 27, 'g11', '2020-07-23 16:43:51', '0000-00-00 00:00:00'),
(32, 28, 'gg', '2020-07-24 06:16:51', '0000-00-00 00:00:00'),
(33, 28, 'op', '2020-09-03 14:51:23', '0000-00-00 00:00:00'),
(34, 26, 'g2', '2020-09-03 15:35:19', '0000-00-00 00:00:00'),
(35, 26, 'g3', '2020-09-03 15:35:19', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `purchase_contract`
--

CREATE TABLE `purchase_contract` (
  `purchase_contract_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `contract_no` varchar(100) NOT NULL,
  `supplier_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_grade_id` int(11) NOT NULL,
  `size` double NOT NULL,
  `specification` text NOT NULL,
  `unit_id` int(11) NOT NULL,
  `quantity` double NOT NULL,
  `mine_location_id` int(11) NOT NULL,
  `price` double NOT NULL,
  `currency_id` int(11) NOT NULL,
  `vat` double NOT NULL,
  `mode_of_payment` varchar(100) NOT NULL,
  `terms_of_delivery` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE current_timestamp(),
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `purchase_contract`
--

INSERT INTO `purchase_contract` (`purchase_contract_id`, `date`, `contract_no`, `supplier_id`, `product_id`, `product_grade_id`, `size`, `specification`, `unit_id`, `quantity`, `mine_location_id`, `price`, `currency_id`, `vat`, `mode_of_payment`, `terms_of_delivery`, `created_at`, `updated_at`, `is_deleted`) VALUES
(2, '2020-09-17', '34354', 4, 26, 35, 23, 'sds', 2, 0, 3, 20000, 1, 18, 'cash', 'asd', '2020-09-05 09:24:12', '2020-09-05 09:48:53', 0),
(3, '2020-09-11', '3435423', 4, 26, 34, 23, 'wqewq', 2, 0, 4, 20000, 1, 12, 'cash', 'asd', '2020-09-05 09:52:07', '0000-00-00 00:00:00', 0),
(4, '2020-09-18', '343542344', 4, 26, 35, 23, 'asd', 2, 43, 6, 500000, 6, 16, 'cash', 'asd', '2020-09-18 13:10:50', '0000-00-00 00:00:00', 0);

-- --------------------------------------------------------

--
-- Table structure for table `raw_material`
--

CREATE TABLE `raw_material` (
  `raw_material_id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE current_timestamp(),
  `is_deleted` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `raw_material`
--

INSERT INTO `raw_material` (`raw_material_id`, `name`, `created_at`, `updated_at`, `is_deleted`) VALUES
(1, 'test', '2020-07-15 12:23:29', '2020-07-19 15:27:52', 1),
(2, 'test 1', '2020-07-19 15:27:36', '2020-09-05 15:51:34', 0),
(3, 'test 3', '2020-07-27 15:32:55', '0000-00-00 00:00:00', 0),
(4, 'test 2', '2020-09-05 15:51:42', '0000-00-00 00:00:00', 0);

-- --------------------------------------------------------

--
-- Table structure for table `sales_contract`
--

CREATE TABLE `sales_contract` (
  `sales_contract_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `contract_no` varchar(100) NOT NULL,
  `buyer_po_no` varchar(100) NOT NULL,
  `buyer_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_grade_id` int(11) NOT NULL,
  `size` double NOT NULL,
  `specification` varchar(300) NOT NULL,
  `units_id` int(11) NOT NULL,
  `quantity` double NOT NULL,
  `destination` text NOT NULL,
  `price` double NOT NULL,
  `currency_id` int(11) NOT NULL,
  `vat` int(11) NOT NULL,
  `mode_of_payment` varchar(200) NOT NULL,
  `terms_of_delivery` varchar(200) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE current_timestamp(),
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sales_contract`
--

INSERT INTO `sales_contract` (`sales_contract_id`, `date`, `contract_no`, `buyer_po_no`, `buyer_id`, `product_id`, `product_grade_id`, `size`, `specification`, `units_id`, `quantity`, `destination`, `price`, `currency_id`, `vat`, `mode_of_payment`, `terms_of_delivery`, `created_at`, `updated_at`, `is_deleted`) VALUES
(5, '2020-09-04', '92837723', '24223653', 2, 26, 34, 200, 'asd', 1, 99, 'goa', 20000, 1, 18, 'cash', 'ads', '2020-09-04 06:08:59', '2020-09-18 10:27:08', 0),
(6, '2020-09-03', '234928377', '43524223653', 2, 27, 31, 200, 'asd', 1, 33, 'goa', 2000034, 1, 18, 'cash', 'ads', '2020-09-04 06:11:55', '2020-09-18 10:27:15', 0),
(7, '2020-09-24', '92837723', 'PO2324', 2, 26, 35, 2004, 'asd', 2, 200, 'goa', 2000034, 6, 18, 'cash', 'ads', '2020-09-18 10:38:30', '0000-00-00 00:00:00', 0);

-- --------------------------------------------------------

--
-- Table structure for table `supplier`
--

CREATE TABLE `supplier` (
  `supplier_id` int(11) NOT NULL,
  `name` varchar(25) NOT NULL,
  `email` varchar(100) NOT NULL,
  `TPIN` text NOT NULL,
  `contact_person_name` varchar(25) NOT NULL,
  `contact_person_number` varchar(10) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE current_timestamp(),
  `is_deleted` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `supplier`
--

INSERT INTO `supplier` (`supplier_id`, `name`, `email`, `TPIN`, `contact_person_name`, `contact_person_number`, `created_at`, `updated_at`, `is_deleted`) VALUES
(1, 'test', 'test@12', '23453', 'test', '9725326536', '2020-07-15 12:31:45', '2020-09-05 15:54:08', 0),
(3, 'abc', '321', '1231', 'adssd', 'ada', '2020-07-20 07:28:29', '2020-07-20 07:28:49', 1),
(4, 'asd', 'asd@12', '123231', 'test', '3224234278', '2020-09-04 11:59:34', '0000-00-00 00:00:00', 0),
(5, 'test', 'asd@12', '23453', 'sde', '9725326536', '2020-09-05 15:54:25', '0000-00-00 00:00:00', 0);

-- --------------------------------------------------------

--
-- Table structure for table `units`
--

CREATE TABLE `units` (
  `unit_id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `units`
--

INSERT INTO `units` (`unit_id`, `name`, `is_deleted`, `created_at`, `updated_at`) VALUES
(1, 'inch', 0, '2020-07-24 06:54:23', '0000-00-00 00:00:00'),
(2, 'yard', 0, '2020-09-04 08:36:28', '2020-09-05 15:28:32');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `username` varchar(25) NOT NULL,
  `password` text NOT NULL,
  `name` varchar(25) NOT NULL,
  `email` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE current_timestamp(),
  `is_deleted` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `password`, `name`, `email`, `created_at`, `updated_at`, `is_deleted`) VALUES
(5, 'john', '$2y$13$Yqy3D2zhKnv7rRC2etiBRuJl9lY6oDFUe7paNQ8c7luffpUH0ADbi', 'john', 'john@gmail.com', '2020-07-15 08:27:50', '2020-07-19 14:49:28', 0),
(6, 'admin', '$2y$13$TeiMtvcYkuVyDwjD3/ErQ.a.b6F6cbnquwJ0/tdPx3Qm9lG1DY1iW', 'administrator1', 'administrator1', '2020-07-15 08:30:59', '2020-08-19 06:20:52', 0),
(7, 'Doe', '$2y$13$UdVaqeKTsgRF8qC1wJ.ByOQZi7TJso.4jWJA.cM08Hv.JxysjVq.K', 'doe', 'doe@gmail.com', '2020-07-19 07:34:11', '2020-09-05 15:57:35', 0),
(8, 'test', '$2y$13$wTMh6UAJJtrnWpUpgsMsdupiQkdlU97L1ffIOjZliflTQTrk3bQSW', 'test', 'test', '2020-07-19 14:47:33', '2020-07-19 14:48:34', 1),
(9, 'qaiser', '$2y$13$IZlDmq6KUujCZuYz47QspuZEpMQzYLik0smqSlU6qcKCaZ2PcbQfK', 'qaiser', 'qaiser', '2020-07-19 14:59:23', '2020-07-19 14:59:47', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `buyer`
--
ALTER TABLE `buyer`
  ADD PRIMARY KEY (`buyer_id`);

--
-- Indexes for table `consumables`
--
ALTER TABLE `consumables`
  ADD PRIMARY KEY (`consumables_id`),
  ADD KEY `currency_id` (`currency_id`),
  ADD KEY `raw_material_id` (`raw_material_id`),
  ADD KEY `supplier_id` (`supplier_id`),
  ADD KEY `units_id` (`units_id`);

--
-- Indexes for table `consumption`
--
ALTER TABLE `consumption`
  ADD PRIMARY KEY (`consumption_id`),
  ADD KEY `rm3` (`raw_material_id`),
  ADD KEY `ml` (`mine_location_id`);

--
-- Indexes for table `currency`
--
ALTER TABLE `currency`
  ADD PRIMARY KEY (`currency_id`);

--
-- Indexes for table `daily_works`
--
ALTER TABLE `daily_works`
  ADD PRIMARY KEY (`daily_works_id`),
  ADD KEY `ml4` (`mine_location_id`);

--
-- Indexes for table `dispatch`
--
ALTER TABLE `dispatch`
  ADD PRIMARY KEY (`dispatch_id`),
  ADD KEY `mine_location_id` (`mine_location_id`),
  ADD KEY `sales_contract_id` (`sales_contract_id`);

--
-- Indexes for table `equipment`
--
ALTER TABLE `equipment`
  ADD PRIMARY KEY (`equipment_id`),
  ADD KEY `mine_location_id` (`mine_location_id`);

--
-- Indexes for table `GRN`
--
ALTER TABLE `GRN`
  ADD PRIMARY KEY (`grn_id`),
  ADD KEY `rm2` (`raw_material_id`),
  ADD KEY `sup2` (`supplier_id`),
  ADD KEY `GRN_ibfk_1` (`purchase_contract_id`);

--
-- Indexes for table `machine`
--
ALTER TABLE `machine`
  ADD PRIMARY KEY (`machine_id`),
  ADD KEY `mine_location_id` (`mine_location_id`);

--
-- Indexes for table `maintenance`
--
ALTER TABLE `maintenance`
  ADD PRIMARY KEY (`maintenance_id`),
  ADD KEY `ml5` (`mine_location_id`);

--
-- Indexes for table `maintenance_equipment`
--
ALTER TABLE `maintenance_equipment`
  ADD PRIMARY KEY (`maintenance_equipment_id`),
  ADD KEY `equipment_id` (`equipment_id`),
  ADD KEY `maintenance_id` (`maintenance_id`);

--
-- Indexes for table `maintenance_quantity`
--
ALTER TABLE `maintenance_quantity`
  ADD PRIMARY KEY (`maintenance_quantity_id`),
  ADD KEY `maintenance_id` (`maintenance_id`),
  ADD KEY `raw_material_id` (`raw_material_id`);

--
-- Indexes for table `mine_location`
--
ALTER TABLE `mine_location`
  ADD PRIMARY KEY (`mine_location_id`);

--
-- Indexes for table `operation`
--
ALTER TABLE `operation`
  ADD PRIMARY KEY (`operation_id`),
  ADD KEY `mine_location_id` (`mine_location_id`);

--
-- Indexes for table `operation_data`
--
ALTER TABLE `operation_data`
  ADD PRIMARY KEY (`operation_data_id`),
  ADD KEY `machine_id` (`machine_id`),
  ADD KEY `operation_id` (`operation_id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `production`
--
ALTER TABLE `production`
  ADD PRIMARY KEY (`production_id`),
  ADD KEY `product_id` (`product_id`),
  ADD KEY `mine_location_id` (`mine_location_id`);

--
-- Indexes for table `production_analysis`
--
ALTER TABLE `production_analysis`
  ADD PRIMARY KEY (`production_analysis_id`),
  ADD KEY `com1` (`component_id`),
  ADD KEY `productio` (`production_id`);

--
-- Indexes for table `product_component`
--
ALTER TABLE `product_component`
  ADD PRIMARY KEY (`product_component_id`),
  ADD KEY `p1` (`product_id`);

--
-- Indexes for table `product_grade`
--
ALTER TABLE `product_grade`
  ADD PRIMARY KEY (`product_grade_id`),
  ADD KEY `p2` (`product_id`);

--
-- Indexes for table `purchase_contract`
--
ALTER TABLE `purchase_contract`
  ADD PRIMARY KEY (`purchase_contract_id`),
  ADD KEY `currency_id` (`currency_id`),
  ADD KEY `mine_location_id` (`mine_location_id`),
  ADD KEY `product_grade_id` (`product_grade_id`),
  ADD KEY `product_id` (`product_id`),
  ADD KEY `supplier_id` (`supplier_id`),
  ADD KEY `unit_id` (`unit_id`);

--
-- Indexes for table `raw_material`
--
ALTER TABLE `raw_material`
  ADD PRIMARY KEY (`raw_material_id`);

--
-- Indexes for table `sales_contract`
--
ALTER TABLE `sales_contract`
  ADD PRIMARY KEY (`sales_contract_id`),
  ADD KEY `buyer_id` (`buyer_id`),
  ADD KEY `currency_id` (`currency_id`),
  ADD KEY `product_grade_id` (`product_grade_id`),
  ADD KEY `units_id` (`units_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `supplier`
--
ALTER TABLE `supplier`
  ADD PRIMARY KEY (`supplier_id`);

--
-- Indexes for table `units`
--
ALTER TABLE `units`
  ADD PRIMARY KEY (`unit_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `buyer`
--
ALTER TABLE `buyer`
  MODIFY `buyer_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `consumables`
--
ALTER TABLE `consumables`
  MODIFY `consumables_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `consumption`
--
ALTER TABLE `consumption`
  MODIFY `consumption_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `currency`
--
ALTER TABLE `currency`
  MODIFY `currency_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `daily_works`
--
ALTER TABLE `daily_works`
  MODIFY `daily_works_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `dispatch`
--
ALTER TABLE `dispatch`
  MODIFY `dispatch_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `equipment`
--
ALTER TABLE `equipment`
  MODIFY `equipment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `GRN`
--
ALTER TABLE `GRN`
  MODIFY `grn_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `machine`
--
ALTER TABLE `machine`
  MODIFY `machine_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `maintenance`
--
ALTER TABLE `maintenance`
  MODIFY `maintenance_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `maintenance_equipment`
--
ALTER TABLE `maintenance_equipment`
  MODIFY `maintenance_equipment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `maintenance_quantity`
--
ALTER TABLE `maintenance_quantity`
  MODIFY `maintenance_quantity_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;

--
-- AUTO_INCREMENT for table `mine_location`
--
ALTER TABLE `mine_location`
  MODIFY `mine_location_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `operation`
--
ALTER TABLE `operation`
  MODIFY `operation_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `operation_data`
--
ALTER TABLE `operation_data`
  MODIFY `operation_data_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `production`
--
ALTER TABLE `production`
  MODIFY `production_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `production_analysis`
--
ALTER TABLE `production_analysis`
  MODIFY `production_analysis_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=84;

--
-- AUTO_INCREMENT for table `product_component`
--
ALTER TABLE `product_component`
  MODIFY `product_component_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `product_grade`
--
ALTER TABLE `product_grade`
  MODIFY `product_grade_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `purchase_contract`
--
ALTER TABLE `purchase_contract`
  MODIFY `purchase_contract_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `raw_material`
--
ALTER TABLE `raw_material`
  MODIFY `raw_material_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `sales_contract`
--
ALTER TABLE `sales_contract`
  MODIFY `sales_contract_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `supplier`
--
ALTER TABLE `supplier`
  MODIFY `supplier_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `units`
--
ALTER TABLE `units`
  MODIFY `unit_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `consumables`
--
ALTER TABLE `consumables`
  ADD CONSTRAINT `consumables_ibfk_1` FOREIGN KEY (`currency_id`) REFERENCES `currency` (`currency_id`),
  ADD CONSTRAINT `consumables_ibfk_2` FOREIGN KEY (`raw_material_id`) REFERENCES `raw_material` (`raw_material_id`),
  ADD CONSTRAINT `consumables_ibfk_3` FOREIGN KEY (`supplier_id`) REFERENCES `supplier` (`supplier_id`),
  ADD CONSTRAINT `consumables_ibfk_4` FOREIGN KEY (`units_id`) REFERENCES `units` (`unit_id`);

--
-- Constraints for table `consumption`
--
ALTER TABLE `consumption`
  ADD CONSTRAINT `ml` FOREIGN KEY (`mine_location_id`) REFERENCES `mine_location` (`mine_location_id`),
  ADD CONSTRAINT `rm3` FOREIGN KEY (`raw_material_id`) REFERENCES `raw_material` (`raw_material_id`);

--
-- Constraints for table `daily_works`
--
ALTER TABLE `daily_works`
  ADD CONSTRAINT `ml4` FOREIGN KEY (`mine_location_id`) REFERENCES `mine_location` (`mine_location_id`);

--
-- Constraints for table `dispatch`
--
ALTER TABLE `dispatch`
  ADD CONSTRAINT `dispatch_ibfk_1` FOREIGN KEY (`mine_location_id`) REFERENCES `mine_location` (`mine_location_id`),
  ADD CONSTRAINT `dispatch_ibfk_2` FOREIGN KEY (`sales_contract_id`) REFERENCES `sales_contract` (`sales_contract_id`);

--
-- Constraints for table `equipment`
--
ALTER TABLE `equipment`
  ADD CONSTRAINT `equipment_ibfk_1` FOREIGN KEY (`mine_location_id`) REFERENCES `mine_location` (`mine_location_id`);

--
-- Constraints for table `GRN`
--
ALTER TABLE `GRN`
  ADD CONSTRAINT `GRN_ibfk_1` FOREIGN KEY (`purchase_contract_id`) REFERENCES `purchase_contract` (`purchase_contract_id`),
  ADD CONSTRAINT `rm2` FOREIGN KEY (`raw_material_id`) REFERENCES `raw_material` (`raw_material_id`),
  ADD CONSTRAINT `sup2` FOREIGN KEY (`supplier_id`) REFERENCES `supplier` (`supplier_id`);

--
-- Constraints for table `machine`
--
ALTER TABLE `machine`
  ADD CONSTRAINT `machine_ibfk_1` FOREIGN KEY (`mine_location_id`) REFERENCES `mine_location` (`mine_location_id`);

--
-- Constraints for table `maintenance`
--
ALTER TABLE `maintenance`
  ADD CONSTRAINT `ml5` FOREIGN KEY (`mine_location_id`) REFERENCES `mine_location` (`mine_location_id`);

--
-- Constraints for table `maintenance_equipment`
--
ALTER TABLE `maintenance_equipment`
  ADD CONSTRAINT `maintenance_equipment_ibfk_1` FOREIGN KEY (`equipment_id`) REFERENCES `equipment` (`equipment_id`),
  ADD CONSTRAINT `maintenance_equipment_ibfk_2` FOREIGN KEY (`maintenance_id`) REFERENCES `maintenance` (`maintenance_id`);

--
-- Constraints for table `maintenance_quantity`
--
ALTER TABLE `maintenance_quantity`
  ADD CONSTRAINT `maintenance_quantity_ibfk_1` FOREIGN KEY (`maintenance_id`) REFERENCES `maintenance` (`maintenance_id`),
  ADD CONSTRAINT `maintenance_quantity_ibfk_2` FOREIGN KEY (`raw_material_id`) REFERENCES `raw_material` (`raw_material_id`);

--
-- Constraints for table `operation`
--
ALTER TABLE `operation`
  ADD CONSTRAINT `operation_ibfk_1` FOREIGN KEY (`mine_location_id`) REFERENCES `mine_location` (`mine_location_id`);

--
-- Constraints for table `operation_data`
--
ALTER TABLE `operation_data`
  ADD CONSTRAINT `operation_data_ibfk_1` FOREIGN KEY (`machine_id`) REFERENCES `machine` (`machine_id`),
  ADD CONSTRAINT `operation_data_ibfk_2` FOREIGN KEY (`operation_id`) REFERENCES `operation` (`operation_id`);

--
-- Constraints for table `production`
--
ALTER TABLE `production`
  ADD CONSTRAINT `product_id` FOREIGN KEY (`product_id`) REFERENCES `product` (`product_id`),
  ADD CONSTRAINT `production_ibfk_1` FOREIGN KEY (`mine_location_id`) REFERENCES `mine_location` (`mine_location_id`);

--
-- Constraints for table `production_analysis`
--
ALTER TABLE `production_analysis`
  ADD CONSTRAINT `com1` FOREIGN KEY (`component_id`) REFERENCES `product_component` (`product_component_id`),
  ADD CONSTRAINT `productio` FOREIGN KEY (`production_id`) REFERENCES `production` (`production_id`);

--
-- Constraints for table `product_component`
--
ALTER TABLE `product_component`
  ADD CONSTRAINT `p1` FOREIGN KEY (`product_id`) REFERENCES `product` (`product_id`);

--
-- Constraints for table `product_grade`
--
ALTER TABLE `product_grade`
  ADD CONSTRAINT `p2` FOREIGN KEY (`product_id`) REFERENCES `product` (`product_id`);

--
-- Constraints for table `purchase_contract`
--
ALTER TABLE `purchase_contract`
  ADD CONSTRAINT `purchase_contract_ibfk_1` FOREIGN KEY (`currency_id`) REFERENCES `currency` (`currency_id`),
  ADD CONSTRAINT `purchase_contract_ibfk_2` FOREIGN KEY (`mine_location_id`) REFERENCES `mine_location` (`mine_location_id`),
  ADD CONSTRAINT `purchase_contract_ibfk_3` FOREIGN KEY (`product_grade_id`) REFERENCES `product_grade` (`product_grade_id`),
  ADD CONSTRAINT `purchase_contract_ibfk_4` FOREIGN KEY (`product_id`) REFERENCES `product` (`product_id`),
  ADD CONSTRAINT `purchase_contract_ibfk_5` FOREIGN KEY (`supplier_id`) REFERENCES `supplier` (`supplier_id`),
  ADD CONSTRAINT `purchase_contract_ibfk_6` FOREIGN KEY (`unit_id`) REFERENCES `units` (`unit_id`);

--
-- Constraints for table `sales_contract`
--
ALTER TABLE `sales_contract`
  ADD CONSTRAINT `sales_contract_ibfk_1` FOREIGN KEY (`buyer_id`) REFERENCES `buyer` (`buyer_id`),
  ADD CONSTRAINT `sales_contract_ibfk_2` FOREIGN KEY (`currency_id`) REFERENCES `currency` (`currency_id`),
  ADD CONSTRAINT `sales_contract_ibfk_3` FOREIGN KEY (`product_grade_id`) REFERENCES `product_grade` (`product_grade_id`),
  ADD CONSTRAINT `sales_contract_ibfk_4` FOREIGN KEY (`units_id`) REFERENCES `units` (`unit_id`),
  ADD CONSTRAINT `sales_contract_ibfk_5` FOREIGN KEY (`product_id`) REFERENCES `product` (`product_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
