<?php

use yii\helpers\Html;
use yii\grid\GridView;

/* @var $this yii\web\View */
/* @var $searchModel app\models\MaintenanceQuantitySearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Maintenance Quantities';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="maintenance-quantity-index">

    <h1><?= Html::encode($this->title) ?></h1>

    <p>
        <?= Html::a('Create Maintenance Quantity', ['create'], ['class' => 'btn btn-success']) ?>
    </p>

    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            'maintenance_quantity_id',
            'maintenance_id',
            'raw_material_id',
            'quantity',
            'created_at',

            ['class' => 'yii\grid\ActionColumn'],
        ],
    ]); ?>


</div>
