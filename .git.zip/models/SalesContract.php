<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "sales_contract".
 *
 * @property int $sales_contract_id
 * @property string $date
 * @property string $contract_no
 * @property string $buyer_po_no
 * @property int $buyer_id
 * @property int $product_id
 * @property int $product_grade_id
 * @property float $size
 * @property string $specification
 * @property int $units_id
 * @property string $destination
 * @property float $price
 * @property int $currency_id
 * @property int $vat
 * @property string $mode_of_payment
 * @property string $terms_of_delivery
 * @property string $created_at
 * @property string $updated_at
 * @property int $is_deleted
 *
 * @property Buyer $buyer
 * @property Currency $currency
 * @property ProductGrade $productGrade
 * @property Units $units
 * @property Product $product
 */
class SalesContract extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'sales_contract';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['date', 'contract_no','quantity', 'buyer_po_no', 'buyer_id', 'product_id', 'product_grade_id', 'size', 'specification', 'units_id', 'destination', 'price', 'currency_id', 'vat', 'mode_of_payment', 'terms_of_delivery'], 'required'],
            [['date', 'created_at', 'updated_at'], 'safe'],
            [['buyer_id', 'product_id', 'product_grade_id', 'units_id', 'currency_id', 'vat', 'is_deleted'], 'integer'],
            [['size', 'price','quantity'], 'number'],
            [['destination'], 'string'],
            [['contract_no', 'buyer_po_no'], 'string', 'max' => 100],
            [['specification'], 'string', 'max' => 300],
            [['mode_of_payment', 'terms_of_delivery'], 'string', 'max' => 200],
            [['buyer_id'], 'exist', 'skipOnError' => true, 'targetClass' => Buyer::className(), 'targetAttribute' => ['buyer_id' => 'buyer_id']],
            [['currency_id'], 'exist', 'skipOnError' => true, 'targetClass' => Currency::className(), 'targetAttribute' => ['currency_id' => 'currency_id']],
            [['product_grade_id'], 'exist', 'skipOnError' => true, 'targetClass' => ProductGrade::className(), 'targetAttribute' => ['product_grade_id' => 'product_grade_id']],
            [['units_id'], 'exist', 'skipOnError' => true, 'targetClass' => Units::className(), 'targetAttribute' => ['units_id' => 'unit_id']],
            [['product_id'], 'exist', 'skipOnError' => true, 'targetClass' => Product::className(), 'targetAttribute' => ['product_id' => 'product_id']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'sales_contract_id' => 'Sales Contract ID',
            'date' => 'Date',
            'contract_no' => 'Contract No',
            'buyer_po_no' => "Buyer's PO No",
            'buyer_id' => "Buyer's Name",
            'product_id' => 'Product',
            'product_grade_id' => 'Grade',
            'size' => 'Size',
            'specification' => 'Specification',
            'units_id' => 'Unit of Measurement',
            'destination' => 'Destination',
            'price' => 'Price',
            'quantity' => 'Quantity',
            'currency_id' => 'Currency',
            'vat' => 'VAT',
            'mode_of_payment' => 'Mode/Terms Of Payment',
            'terms_of_delivery' => 'Terms Of Delivery',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
            'is_deleted' => 'Is Deleted',
        ];
    }

    /**
     * Gets query for [[Buyer]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getBuyer()
    {
        return $this->hasOne(Buyer::className(), ['buyer_id' => 'buyer_id']);
    }

    /**
     * Gets query for [[Currency]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getCurrency()
    {
        return $this->hasOne(Currency::className(), ['currency_id' => 'currency_id']);
    }

    /**
     * Gets query for [[ProductGrade]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getProductGrade()
    {
        return $this->hasOne(ProductGrade::className(), ['product_grade_id' => 'product_grade_id']);
    }

    /**
     * Gets query for [[Units]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getUnits()
    {
        return $this->hasOne(Units::className(), ['unit_id' => 'units_id']);
    }

    /**
     * Gets query for [[Product]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getProduct()
    {
        return $this->hasOne(Product::className(), ['product_id' => 'product_id']);
    }
}
