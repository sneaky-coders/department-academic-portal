<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "production".
 *
 * @property int $production_id
 * @property string $date
 * @property int $mine_location_id
 * @property int $product_id
 * @property float $quantity
 * @property string $created_at
 * @property string $updated_at
 * @property int $is_deleted
 *
 * @property Product $productName
 * @property MineLocation $mineLocation 
 * @property ProductionAnalysis[] $productionAnalyses
 */
class Production extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'production';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['date', 'mine_location_id', 'product_id'], 'required'],
            [['date', 'created_at', 'updated_at','product_id','quantity'], 'safe'],
            [[ 'is_deleted'], 'integer'],
            [['quantity'], 'number'],
            [['mine_location_id'], 'exist', 'skipOnError' => true, 'targetClass' => MineLocation::className(), 'targetAttribute' => ['mine_location_id' => 'mine_location_id']], 
            [['product_id'], 'exist', 'skipOnError' => true, 'targetClass' => Product::className(), 'targetAttribute' => ['product_id' => 'product_id']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'production_id' => 'Production ID',
            'date' => 'Date',
            'mine_location_id' => 'Mine Location',
            'product_id' => 'Product Name',
            'quantity' => 'Quantity',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
            'is_deleted' => 'Is Deleted',
        ];
    }

    /**
     * Gets query for [[ProductName]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getProduct()
    {
        return $this->hasOne(Product::className(), ['product_id' => 'product_id']);
    }

    /**
     * Gets query for [[ProductionAnalyses]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getProductionAnalyses()
    {
        return $this->hasMany(ProductionAnalysis::className(), ['production_id' => 'production_id']);
    }

    /**
	* Gets query for [[MineLocation]]. 
	* 
	* @return \yii\db\ActiveQuery 
	*/ 
    public function getMineLocation() 
    { 
        return $this->hasOne(MineLocation::className(), ['mine_location_id' => 'mine_location_id']); 
    } 
}
