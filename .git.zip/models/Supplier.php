<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "supplier".
 *
 * @property int $supplier_id
 * @property string $name
 * @property string $email
 * @property string $TPIN
 * @property string $contact_person_name
 * @property int $contact_person_number
 * @property string $created_at
 * @property string $updated_at
 * @property int $is_deleted
 */
class Supplier extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'supplier';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['name', 'email', 'TPIN', 'contact_person_name', 'contact_person_number'], 'required'],
            [['TPIN'], 'string'],
            [['is_deleted'], 'integer'],
            [['contact_person_number',], 'string', 'max' => 10],
            [['created_at', 'updated_at'], 'safe'],
            [['name', 'contact_person_name'], 'string', 'max' => 25],
            [['email'], 'string', 'max' => 100],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'supplier_id' => 'Supplier ID',
            'name' => 'Name',
            'email' => 'Email',
            'TPIN' => 'Tpin',
            'contact_person_name' => 'Contact Person Name',
            'contact_person_number' => 'Contact Person Number',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
            'is_deleted' => 'Is Deleted',
        ];
    }
}
