<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "dispatch".
 *
 * @property int $dispatch_id
 * @property int $mine_location_id
 * @property int $sales_contract_id
 * @property string $date
 * @property float $quantity_dispatched
 * @property float $quantity_received
 * @property float $exchange_rate
 * @property string $type_of_dispatch

 * @property string $truck_no
 * @property string $driver_name
 * @property string $driver_contact_no
 * @property string $created_at
 * @property string $updated_at
 * @property int $is_deleted
 *
 * @property MineLocation $mineLocation
 * @property SalesContract $salesContract
 */
class Dispatch extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'dispatch';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['mine_location_id', 'trailer_no','sales_contract_id', 'date', 'quantity_dispatched', 'quantity_received', 'exchange_rate', 'type_of_dispatch', 'truck_no', 'driver_name', 'driver_contact_no'], 'required'],
            [['mine_location_id', 'sales_contract_id', 'is_deleted'], 'integer'],
            [['date', 'created_at', 'updated_at'], 'safe'],
            [['quantity_dispatched', 'quantity_received', 'exchange_rate'], 'number'],
            [['type_of_dispatch'], 'string'],
            [[ 'driver_name'], 'string', 'max' => 50],
            [['truck_no'], 'string', 'max' => 25],
            [['trailer_no'], 'string', 'max' => 100],
            [['driver_contact_no'], 'string', 'max' => 15],
            [['mine_location_id'], 'exist', 'skipOnError' => true, 'targetClass' => MineLocation::className(), 'targetAttribute' => ['mine_location_id' => 'mine_location_id']],
            [['sales_contract_id'], 'exist', 'skipOnError' => true, 'targetClass' => SalesContract::className(), 'targetAttribute' => ['sales_contract_id' => 'sales_contract_id']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'dispatch_id' => 'Dispatch ID',
            'mine_location_id' => 'Mine Location',
            'sales_contract_id' => "Sales Contract No.",
            'date' => 'Date',
            'quantity_dispatched' => 'Quantity Dispatched',
            'quantity_received' => 'Quantity Received by Buyer',
            'exchange_rate' => 'Exchange Rate',
            'type_of_dispatch' => 'Type Of Dispatch',
            
            'truck_no' => 'Truck No',
            'driver_name' => "Driver's Name",
            'driver_contact_no' => "Driver's Contact No",
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
            'is_deleted' => 'Is Deleted',
        ];
    }

    /**
     * Gets query for [[MineLocation]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getMineLocation()
    {
        return $this->hasOne(MineLocation::className(), ['mine_location_id' => 'mine_location_id']);
    }

    /**
     * Gets query for [[SalesContract]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getSalesContract()
    {
        return $this->hasOne(SalesContract::className(), ['sales_contract_id' => 'sales_contract_id']);
    }
}
