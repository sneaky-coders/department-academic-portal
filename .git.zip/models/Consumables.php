<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "consumables".
 *
 * @property int $consumables_id
 * @property string $date
 * @property int $supplier_id
 * @property int $raw_material_id
 * @property int $currency_id
 * @property float $price
 * @property float $vat
 * @property float $quantity
 * @property int $units_id
 * @property string $remarks
 * @property string $created_at
 * @property string $updated_at
 * @property int $is_deleted
 *
 * @property Currency $currency
 * @property RawMaterial $rawMaterial
 * @property Supplier $supplier
 * @property Units $units
 */
class Consumables extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'consumables';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['date', 'supplier_id', 'raw_material_id', 'currency_id', 'price', 'vat', 'quantity', 'units_id', 'remarks'], 'required'],
            [['date', 'created_at', 'updated_at'], 'safe'],
            [['supplier_id', 'raw_material_id', 'currency_id', 'units_id', 'is_deleted'], 'integer'],
            [['price', 'vat', 'quantity'], 'number'],
            [['remarks'], 'string'],
            [['currency_id'], 'exist', 'skipOnError' => true, 'targetClass' => Currency::className(), 'targetAttribute' => ['currency_id' => 'currency_id']],
            [['raw_material_id'], 'exist', 'skipOnError' => true, 'targetClass' => RawMaterial::className(), 'targetAttribute' => ['raw_material_id' => 'raw_material_id']],
            [['supplier_id'], 'exist', 'skipOnError' => true, 'targetClass' => Supplier::className(), 'targetAttribute' => ['supplier_id' => 'supplier_id']],
            [['units_id'], 'exist', 'skipOnError' => true, 'targetClass' => Units::className(), 'targetAttribute' => ['units_id' => 'unit_id']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'consumables_id' => 'Consumables ID',
            'date' => 'Date',
            'supplier_id' => 'Supplier',
            'raw_material_id' => 'Raw Material',
            'currency_id' => 'Currency',
            'price' => 'Price',
            'vat' => 'VAT',
            'quantity' => 'Quantity',
            'units_id' => 'Units',
            'remarks' => 'Remarks',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
            'is_deleted' => 'Is Deleted',
        ];
    }

    /**
     * Gets query for [[Currency]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getCurrency()
    {
        return $this->hasOne(Currency::className(), ['currency_id' => 'currency_id']);
    }

    /**
     * Gets query for [[RawMaterial]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getRawMaterial()
    {
        return $this->hasOne(RawMaterial::className(), ['raw_material_id' => 'raw_material_id']);
    }

    /**
     * Gets query for [[Supplier]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getSupplier()
    {
        return $this->hasOne(Supplier::className(), ['supplier_id' => 'supplier_id']);
    }

    /**
     * Gets query for [[Units]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getUnits()
    {
        return $this->hasOne(Units::className(), ['unit_id' => 'units_id']);
    }
}
