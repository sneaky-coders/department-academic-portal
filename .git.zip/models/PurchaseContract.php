<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "purchase_contract".
 *
 * @property int $purchase_contract_id
 * @property string $date
 * @property string $contract_no
 * @property int $supplier_id
 * @property int $product_id
 * @property int $product_grade_id
 * @property float $size
 * @property string $specification
 * @property int $unit_id
 * @property int $mine_location_id
 * @property float $price
 * @property int $currency_id
 * @property float $vat
 * @property string $mode_of_payment
 * @property string $terms_of_delivery
 * @property string $created_at
 * @property string $updated_at
 * @property int $is_deleted
 *
 * @property Currency $currency
 * @property MineLocation $mineLocation
 * @property ProductGrade $productGrade
 * @property Product $product
 * @property Supplier $supplier
 * @property Units $unit
 */
class PurchaseContract extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'purchase_contract';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['date', 'contract_no','quantity' ,'supplier_id', 'product_id', 'product_grade_id', 'size', 'specification', 'unit_id', 'mine_location_id', 'price', 'currency_id', 'vat', 'mode_of_payment', 'terms_of_delivery'], 'required'],
            [['date', 'created_at', 'updated_at'], 'safe'],
            [['supplier_id', 'product_id', 'product_grade_id', 'unit_id', 'mine_location_id', 'currency_id', 'is_deleted'], 'integer'],
            [['size', 'price', 'vat','quantity'], 'number'],
            [['specification'], 'string'],
            [['contract_no', 'mode_of_payment', 'terms_of_delivery'], 'string', 'max' => 100],
            [['currency_id'], 'exist', 'skipOnError' => true, 'targetClass' => Currency::className(), 'targetAttribute' => ['currency_id' => 'currency_id']],
            [['mine_location_id'], 'exist', 'skipOnError' => true, 'targetClass' => MineLocation::className(), 'targetAttribute' => ['mine_location_id' => 'mine_location_id']],
            [['product_grade_id'], 'exist', 'skipOnError' => true, 'targetClass' => ProductGrade::className(), 'targetAttribute' => ['product_grade_id' => 'product_grade_id']],
            [['product_id'], 'exist', 'skipOnError' => true, 'targetClass' => Product::className(), 'targetAttribute' => ['product_id' => 'product_id']],
            [['supplier_id'], 'exist', 'skipOnError' => true, 'targetClass' => Supplier::className(), 'targetAttribute' => ['supplier_id' => 'supplier_id']],
            [['unit_id'], 'exist', 'skipOnError' => true, 'targetClass' => Units::className(), 'targetAttribute' => ['unit_id' => 'unit_id']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'purchase_contract_id' => 'Purchase Contract ID',
            'date' => 'Date',
            'contract_no' => 'Contract No',
            'supplier_id' => "Supplier's Name",
            'product_id' => 'Product',
            'product_grade_id' => 'Grade',
            'size' => 'Size',
            'specification' => 'Specification',
            'unit_id' => 'Units',
            'quantity' => 'Quantity',
            'mine_location_id' => 'Mine Location',
            'price' => 'Price',
            'currency_id' => 'Currency',
            'vat' => 'VAT',
            'mode_of_payment' => 'Mode Of Payment',
            'terms_of_delivery' => 'Terms Of Delivery',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
            'is_deleted' => 'Is Deleted',
        ];
    }

    /**
     * Gets query for [[Currency]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getCurrency()
    {
        return $this->hasOne(Currency::className(), ['currency_id' => 'currency_id']);
    }

    /**
     * Gets query for [[MineLocation]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getMineLocation()
    {
        return $this->hasOne(MineLocation::className(), ['mine_location_id' => 'mine_location_id']);
    }

    /**
     * Gets query for [[ProductGrade]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getProductGrade()
    {
        return $this->hasOne(ProductGrade::className(), ['product_grade_id' => 'product_grade_id']);
    }

    /**
     * Gets query for [[Product]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getProduct()
    {
        return $this->hasOne(Product::className(), ['product_id' => 'product_id']);
    }

    /**
     * Gets query for [[Supplier]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getSupplier()
    {
        return $this->hasOne(Supplier::className(), ['supplier_id' => 'supplier_id']);
    }

    /**
     * Gets query for [[Unit]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getUnit()
    {
        return $this->hasOne(Units::className(), ['unit_id' => 'unit_id']);
    }
}
