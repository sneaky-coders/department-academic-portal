<?php

namespace app\models;

use yii\base\Model;
use yii\data\ActiveDataProvider;
use app\models\Production;

/**
 * ProductionSearch represents the model behind the search form of `app\models\Production`.
 */
class ProductionSearch extends Production
{
    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['production_id', 'is_deleted'], 'integer'],
            [['date', 'mine_location_id', 'product_id', 'created_at', 'updated_at'], 'safe'],
            [['quantity'], 'number'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params)
    {
        $query = Production::find();

        // add conditions that should always apply here

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
        ]);

        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }

        $query->joinWith('product');
        $query->joinWith('mineLocation');

            // grid filtering conditions
            $query->andFilterWhere([
                'production_id' => $this->production_id,
                'date' => $this->date,
                'quantity' => $this->quantity,
            
                'created_at' => $this->created_at,
                'updated_at' => $this->updated_at,
                'production.is_deleted' => 0,
            ]);

            $query->andFilterWhere(['like', 'mine_location.name', $this->mine_location_id]);
        //  ->andFilterWhere(['like', 'product_id', $this->product_id]);
            $query->andFilterWhere(['like', 'product.product_name', $this->product_id]);

            return $dataProvider;
        }
}
