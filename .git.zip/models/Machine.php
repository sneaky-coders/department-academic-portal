<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "machine".
 *
 * @property int $machine_id
 * @property string $machine_name
 * @property string $created_at
 * @property string $updated_at
 * @property int $is_deleted
 */
class Machine extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'machine';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['machine_name', 'mine_location_id'], 'required'],
		    [['mine_location_id', 'is_deleted'], 'integer'],
            [['created_at', 'updated_at'], 'safe'],
            [['machine_name'], 'string', 'max' => 30],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'machine_id' => 'Machine ID',
            'machine_name' => 'Machine Name',
            'mine_location_id' => 'Mine Location', 
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
            'is_deleted' => 'Is Deleted',
        ];
    }
      /** 
		    * Gets query for [[MineLocation]]. 
		    * 
		    * @return \yii\db\ActiveQuery 
		    */ 
            public function getMineLocation() 
            { 
                return $this->hasOne(MineLocation::className(), ['mine_location_id' => 'mine_location_id']); 
            } 
          
            /** 
             * Gets query for [[Operations]]. 
             * 
             * @return \yii\db\ActiveQuery 
             */ 
            public function getOperations() 
            { 
                return $this->hasMany(Operation::className(), ['machine_id' => 'machine_id']); 
            } 
}
