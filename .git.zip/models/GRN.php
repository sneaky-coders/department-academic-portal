<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "GRN".
 *
 * @property int $grn_id
 * @property int $purchase_contract_id
 * @property string $date
 * @property int $supplier_id
 * @property string $po_no
 * @property int $raw_material
 * @property float $quantity_received
 * @property float $exchange_rate
 * @property string $truck_no
 * @property string $driver_name
 * @property string $remark
 * @property string $created_at
 * @property string $updated_at
 * @property int $is_delete
 *
 * @property PurchaseContract $purchaseContract
 * @property RawMaterial $rawMaterial
 * @property Supplier $supplier
 */
class GRN extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'GRN';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['purchase_contract_id', 'date', 'supplier_id', 'po_no', 'raw_material_id', 'quantity_received', 'exchange_rate', 'truck_no', 'driver_name', 'remark'], 'required'],
            [['purchase_contract_id', 'supplier_id', 'raw_material_id', 'is_delete'], 'integer'],
            [['date', 'created_at', 'updated_at'], 'safe'],
            [['quantity_received', 'exchange_rate'], 'number'],
            [['remark'], 'string'],
            [['po_no', 'driver_name'], 'string', 'max' => 50],
            [['truck_no'], 'string', 'max' => 40],
            [['purchase_contract_id'], 'exist', 'skipOnError' => true, 'targetClass' => PurchaseContract::className(), 'targetAttribute' => ['purchase_contract_id' => 'purchase_contract_id']],
            [['raw_material_id'], 'exist', 'skipOnError' => true, 'targetClass' => RawMaterial::className(), 'targetAttribute' => ['raw_material_id' => 'raw_material_id']],
            [['supplier_id'], 'exist', 'skipOnError' => true, 'targetClass' => Supplier::className(), 'targetAttribute' => ['supplier_id' => 'supplier_id']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'grn_id' => 'Grn ID',
            'purchase_contract_id' => 'Purchase Contract NO.',
            'date' => 'Date',
            'supplier_id' => 'Supplier',
            'po_no' => 'PO No',
            'raw_material_id' => 'Raw Material',
            'quantity_received' => 'Quantity Received',
            'exchange_rate' => 'Exchange Rate',
            'truck_no' => 'Truck No',
            'driver_name' => 'Driver Name',
            'remark' => 'Remark',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
            'is_delete' => 'Is Delete',
        ];
    }

    /**
     * Gets query for [[PurchaseContract]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getPurchaseContract()
    {
        return $this->hasOne(PurchaseContract::className(), ['purchase_contract_id' => 'purchase_contract_id']);
    }

    /**
     * Gets query for [[RawMaterial]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getRawMaterial()
    {
        return $this->hasOne(RawMaterial::className(), ['raw_material_id' => 'raw_material_id']);
    }

    /**
     * Gets query for [[Supplier]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getSupplier()
    {
        return $this->hasOne(Supplier::className(), ['supplier_id' => 'supplier_id']);
    }
}
