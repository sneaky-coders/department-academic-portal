<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "operation".
 *
 * @property int $operation_id
 * @property string $date
 

 
 * @property float $other_costs
 * @property string $created_at
 * @property string $updated_at
 * @property int $is_deleted
 * 
 */

class Operation extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public $machines;
    public $hours;
    public $cost;
    public static function tableName()
    {
        return 'operation';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['date', 'mine_location_id','other_costs','hours','cost'], 'required'],
            [['date', 'created_at', 'updated_at','mine_location_id','machines','hours','cost'], 'safe'],
            [['other_costs'], 'number'],
            [['is_deleted'], 'integer'],
            [['mine_location_id'], 'exist', 'skipOnError' => true, 'targetClass' => MineLocation::className(), 'targetAttribute' => ['mine_location_id' => 'mine_location_id']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'operation_id' => 'Operation ID',
            'date' => 'Date',
            'mine_location_id' => 'Location',
          
          
            'other_costs' => 'Other Costs',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
            'is_deleted' => 'Is Deleted',
        ];
    }

    /** 
		    * Gets query for [[MineLocation]]. 
		    * 
		    * @return \yii\db\ActiveQuery 
		    */ 
            public function getMineLocation() 
            { 
                return $this->hasOne(MineLocation::className(), ['mine_location_id' => 'mine_location_id']); 
            } 

}
