<?php

namespace app\models;

use yii\base\Model;
use yii\data\ActiveDataProvider;
use app\models\Consumption;

/**
 * ConsumptionSearch represents the model behind the search form of `app\models\Consumption`.
 */
class ConsumptionSearch extends Consumption
{
    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['consumption_id', 'is_delete'], 'integer'],
            [['date','raw_material_id', 'mine_location_id','created_at', 'updated_at'], 'safe'],
            [['quantity', 'cost'], 'number'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params)
    {
        $query = Consumption::find();

        // add conditions that should always apply here

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
        ]);

        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }

        $query->joinWith('rawMaterial');
        $query->joinWith('mineLocation');
        // grid filtering conditions
        $query->andFilterWhere([
            'consumption_id' => $this->consumption_id,
            'date' => $this->date,
           // 'raw_material_id' => $this->raw_material_id,
           // 'mine_location' => $this->mine_location,
            'quantity' => $this->quantity,
          
            'cost' => $this->cost,
            'created_at' => $this->created_at,
            'updated_at' => $this->updated_at,
            'is_delete' => 0,
        ]);

        $query->andFilterWhere(['like', 'raw_material.name', $this->raw_material_id])
        ->andFilterWhere(['like', 'mine_location.name', $this->mine_location_id]);


        return $dataProvider;
    }
}
