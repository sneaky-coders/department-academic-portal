<?php

namespace app\models;

use yii\base\Model;
use yii\data\ActiveDataProvider;
use app\models\Dispatch;

/**
 * DispatchSearch represents the model behind the search form of `app\models\Dispatch`.
 */
class DispatchSearch extends Dispatch
{
    /**
     * {@inheritdoc}
     */
    public $to;
    public $from;
    public function rules()
    {
        return [
            [['dispatch_id',  'is_deleted'], 'integer'],
            [['date', 'type_of_dispatch', 'truck_no','mine_location_id', 'sales_contract_id', 'driver_name', 'driver_contact_no', 'created_at', 'updated_at'], 'safe'],
            [['quantity_dispatched', 'quantity_received', 'exchange_rate'], 'number'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params)
    {
        $query = Dispatch::find();

        // add conditions that should always apply here

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
        ]);

        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }
        if($this->to != '' && $this->from != ""){
            $query->andFilterWhere(['between','dispatch.date',$this->from,$this->to]);
        }
        $query->joinWith('mineLocation');
        $query->joinWith('salesContract');

        // grid filtering conditions
        $query->andFilterWhere([
            'dispatch_id' => $this->dispatch_id,
            //'mine_location_id' => $this->mine_location_id,
            //'sales_contract_id' => $this->sales_contract_id,
            'dispatch.date' => $this->date,
            'quantity_dispatched' => $this->quantity_dispatched,
            'quantity_received' => $this->quantity_received,
            'exchange_rate' => $this->exchange_rate,
            'created_at' => $this->created_at,
            'updated_at' => $this->updated_at,
            'dispatch.is_deleted' => 0,
        ]);

        $query->andFilterWhere(['like', 'type_of_dispatch', $this->type_of_dispatch])
           
            ->andFilterWhere(['like', 'mine_location.name', $this->mine_location_id])
            ->andFilterWhere(['like', 'sales_contract.contract_no', $this->sales_contract_id])
            ->andFilterWhere(['like', 'truck_no', $this->truck_no])
            ->andFilterWhere(['like', 'driver_name', $this->driver_name])
            ->andFilterWhere(['like', 'driver_contact_no', $this->driver_contact_no]);

        return $dataProvider;
    }
}
