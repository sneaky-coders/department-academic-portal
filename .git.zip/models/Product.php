<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "product".
 *
 * @property int $product_id
 * @property string $product_name
 * @property string $created_at
 * @property string $updated_at
 * @property int $is_deleted
 *
 * @property ProductComponent[] $productComponents
 * @property ProductGrade[] $productGrades
 */
class Product extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'product';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['product_name'], 'required'],
            [['created_at', 'updated_at'], 'safe'],
            [['is_delete'], 'integer'],
            [['product_name'], 'string', 'max' => 25],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'product_id' => 'Product ID',
            'product_name' => 'Product Name',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
            'is_delete' => 'Is Deleted',
        ];
    }

    /**
     * Gets query for [[ProductComponents]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getProductComponents()
    {
        return $this->hasMany(ProductComponent::className(), ['product_id' => 'product_id']);
    }

    /**
     * Gets query for [[ProductGrades]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getProductGrades()
    {
        return $this->hasMany(ProductGrade::className(), ['product_id' => 'product_id']);
    }
}
