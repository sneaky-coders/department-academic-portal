<?php

namespace app\models;

use yii\base\Model;
use yii\data\ActiveDataProvider;
use app\models\Maintenance;

/**
 * MaintenanceSearch represents the model behind the search form of `app\models\Maintenance`.
 */

class MaintenanceSearch extends Maintenance
{
    public $to;
    public $from;
    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['maintenance_id',  'is_delete'], 'integer'],
            [['date', 'nature_of_maintenance','mine_location_id', 'type_of_maintenance', 'details','resources_employed', 'created_at', 'updated_at'], 'safe'],
            [['other_expenses'], 'number'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params)
    {
        $query = Maintenance::find();

        // add conditions that should always apply here

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
        ]);

        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }
        $query->joinWith('mineLocation');
        // grid filtering conditions

        if($this->to != "" && $this->from != ""){
            $query->andFilterWhere(['between', 'date', $this->from, $this->to]);
        }

        $query->andFilterWhere([
            'maintenance_id' => $this->maintenance_id,
            'date' => $this->date,
          //  'mine_location_id' => $this->mine_location_id,
            'other_expenses' => $this->other_expenses,
            'created_at' => $this->created_at,
            'updated_at' => $this->updated_at,
            'is_delete' => 0,
        ]);

        $query->andFilterWhere(['like', 'nature_of_maintenance', $this->nature_of_maintenance])
            ->andFilterWhere(['like', 'type_of_maintenance', $this->type_of_maintenance])
            ->andFilterWhere(['like', 'details', $this->details])
            ->andFilterWhere(['like', 'resources_employed', $this->resources_employed])
            ->andFilterWhere(['like', 'mine_location.name', $this->mine_location_id]);

        return $dataProvider;
    }
}
