<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "maintenance".
 *
 * @property int $maintenance_id
 * @property string $date
 * @property int $mine_location_id
 * @property string $nature_of_maintenance
 * @property string $type_of_maintenance
 * @property string $details
 * @property string $resources_employed
 * @property float $other_expenses
 * @property string $created_at
 * @property string $updated_at
 * @property int|null $is_delete
 *
 * @property MineLocation $mineLocation
 */
class Maintenance extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public $raw_material_id;
    public $quantity;
    public $equipment_id;
    public static function tableName()
    {
        return 'maintenance';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['date', 'mine_location_id', 'nature_of_maintenance', 'type_of_maintenance', 'details', 'resources_employed', 'other_expenses'], 'required'],
            [['date', 'created_at', 'updated_at','equipment_id','raw_material_id','quantity'], 'safe'],
            [['mine_location_id', 'is_delete'], 'integer'],
            [['nature_of_maintenance', 'type_of_maintenance', 'details'], 'string'],
            [['other_expenses'], 'number'],
            [['resources_employed'], 'string', 'max' => 100],
            [['mine_location_id'], 'exist', 'skipOnError' => true, 'targetClass' => MineLocation::className(), 'targetAttribute' => ['mine_location_id' => 'mine_location_id']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'maintenance_id' => 'Maintenance ID',
            'date' => 'Date',
            'mine_location_id' => 'Mine Location',
            'nature_of_maintenance' => 'Nature Of Maintenance',
            'type_of_maintenance' => 'Type Of Maintenance',
            'details' => 'Details',
       
            'resources_employed' => 'Resources Employed',
            'other_expenses' => 'Other Expenses',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
            'is_delete' => 'Is Delete',
        ];
    }

    /**
     * Gets query for [[MineLocation]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getMineLocation()
    {
        return $this->hasOne(MineLocation::className(), ['mine_location_id' => 'mine_location_id']);
    }
  
    public function getMaintenanceQuantities() 
    { 
        return $this->hasMany(MaintenanceQuantity::className(), ['maintenance_id' => 'maintenance_id']); 
    } 
}
