<?php

namespace app\models;

use yii\base\Model;
use yii\data\ActiveDataProvider;
use app\models\SalesContract;

/**
 * SalesContractSearch represents the model behind the search form of `app\models\SalesContract`.
 */
class SalesContractSearch extends SalesContract
{
    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['sales_contract_id', 'product_grade_id', 'units_id', 'currency_id', 'vat', 'is_deleted'], 'integer'],
            [['date', 'contract_no', 'buyer_id', 'product_id', 'buyer_po_no', 'specification', 'destination', 'mode_of_payment', 'terms_of_delivery', 'created_at', 'updated_at'], 'safe'],
            [['size', 'price'], 'number'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params)
    {
        $query = SalesContract::find();

        // add conditions that should always apply here

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
        ]);

        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }
        $query->joinWith(['product','buyer']);
        // grid filtering conditions
        $query->andFilterWhere([
            'sales_contract_id' => $this->sales_contract_id,
            'date' => $this->date,
            //'buyer_id' => $this->buyer_id,
            //'product_id' => $this->product_id,
            'product_grade_id' => $this->product_grade_id,
            'size' => $this->size,
            'units_id' => $this->units_id,
            'price' => $this->price,
            'currency_id' => $this->currency_id,
            'vat' => $this->vat,
            'created_at' => $this->created_at,
            'updated_at' => $this->updated_at,
            'is_deleted' => $this->is_deleted,
        ]);

        $query->andFilterWhere(['like', 'contract_no', $this->contract_no])
            ->andFilterWhere(['like', 'buyer_po_no', $this->buyer_po_no])
            ->andFilterWhere(['like', 'specification', $this->specification])
            ->andFilterWhere(['like', 'destination', $this->destination])
            ->andFilterWhere(['like', 'mode_of_payment', $this->mode_of_payment])
            ->andFilterWhere(['like', 'buyer.name', $this->buyer_id])
            ->andFilterWhere(['like', 'product.product_name', $this->product_id])
            ->andFilterWhere(['like', 'terms_of_delivery', $this->terms_of_delivery]);

        return $dataProvider;
    }
}
