<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "maintenance_quantity".
 *
 * @property int $maintenance_quantity_id
 * @property int $maintenance_id
 * @property int $raw_material_id
 * @property float $quantity
 * @property string $created_at
 *
 * @property Maintenance $maintenance
 * @property RawMaterial $rawMaterial
 */
class MaintenanceQuantity extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'maintenance_quantity';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['maintenance_id', 'raw_material_id', 'quantity'], 'required'],
            [['maintenance_id', 'raw_material_id'], 'integer'],
            [['quantity'], 'number'],
            [['created_at'], 'safe'],
            [['maintenance_id'], 'exist', 'skipOnError' => true, 'targetClass' => Maintenance::className(), 'targetAttribute' => ['maintenance_id' => 'maintenance_id']],
            [['raw_material_id'], 'exist', 'skipOnError' => true, 'targetClass' => RawMaterial::className(), 'targetAttribute' => ['raw_material_id' => 'raw_material_id']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'maintenance_quantity_id' => 'Maintenance Quantity ID',
            'maintenance_id' => 'Maintenance ID',
            'raw_material_id' => 'Raw Material ID',
            'quantity' => 'Quantity',
            'created_at' => 'Created At',
        ];
    }

    /**
     * Gets query for [[Maintenance]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getMaintenance()
    {
        return $this->hasOne(Maintenance::className(), ['maintenance_id' => 'maintenance_id']);
    }

    /**
     * Gets query for [[RawMaterial]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getRawMaterial()
    {
        return $this->hasOne(RawMaterial::className(), ['raw_material_id' => 'raw_material_id']);
    }
}
