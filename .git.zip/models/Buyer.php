<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "buyer".
 *
 * @property int $buyer_id
 * @property string $name
 * @property string $email
 * @property string $TPIN
 * @property string $contact_person_name
 * @property int $contact_person_number
 * @property string $created_at
 * @property string $updated_at
 * @property int $is_deleted
 */
class Buyer extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'buyer';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['name', 'email', 'TPIN', 'contact_person_name', 'contact_person_number'], 'required'],
            [['TPIN'], 'string'],
            [['contact_person_number', 'is_deleted'], 'integer'],
            [['created_at', 'updated_at'], 'safe'],
            [['name', 'contact_person_name'], 'string', 'max' => 25],
            [['email'], 'string', 'max' => 100],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'buyer_id' => 'Buyer ID',
            'name' => 'Name',
            'email' => 'Email',
            'TPIN' => 'Tpin',
            'contact_person_name' => 'Contact Person Name',
            'contact_person_number' => 'Contact Person Number',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
            'is_deleted' => 'Is Deleted',
        ];
    }
}
