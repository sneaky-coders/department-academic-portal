<?php

namespace app\models;

use yii\base\Model;
use yii\data\ActiveDataProvider;
use app\models\DailyWorks;

/**
 * DailyWorksSearch represents the model behind the search form of `app\models\DailyWorks`.
 */
class DailyWorksSearch extends DailyWorks
{
    public $to;
    public $from;
    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['daily_works_id',  'is_delete'], 'integer'],
            [['date', 'nature_of_job', 'location', 'mine_location_id','resources_employed', 'distance_travelled', 'vehicles_used', 'created_at', 'updated_at'], 'safe'],
            [['cost_incurred'], 'number'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params)
    {
        $query = DailyWorks::find();

        // add conditions that should always apply here

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
        ]);

        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }
        $query->joinWith('mineLocation');
        // grid filtering conditions
        if($this->to != "" && $this->from != ""){
            $query->andFilterWhere(['between', 'date', $this->from, $this->to]);
        }


        $query->andFilterWhere([
            'daily_works_id' => $this->daily_works_id,
            'date' => $this->date,
          //  'mine_location' => $this->mine_location,
            'cost_incurred' => $this->cost_incurred,
            'created_at' => $this->created_at,
            'updated_at' => $this->updated_at,
            'is_delete' => 0,
        ]);

        $query->andFilterWhere(['like', 'nature_of_job', $this->nature_of_job])
            ->andFilterWhere(['like', 'location', $this->location])
            ->andFilterWhere(['like', 'resources_employed', $this->resources_employed])
            ->andFilterWhere(['like', 'distance_travelled', $this->distance_travelled])
            ->andFilterWhere(['like', 'vehicles_used', $this->vehicles_used])
            ->andFilterWhere(['like', 'mine_location.name', $this->mine_location_id]);

        return $dataProvider;
    }
}
