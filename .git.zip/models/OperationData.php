<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "operation_data".
 *
 * @property int $operation_data_id
 * @property int $operation_id
 * @property int $machine_id
 * @property float $hours
 * @property string $created_at
 * @property string $updated_at
 *
 * @property Machine $machine
 * @property Operation $operation
 */
class OperationData extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
   
    public static function tableName()
    {
        return 'operation_data';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['operation_id', 'machine_id', 'hours','cost_of_machine_operation'], 'required'],
            [['operation_data_id', 'operation_id', 'machine_id'], 'integer'],
            [['hours','cost_of_machine_operation'], 'number'],
            [['created_at', 'updated_at'], 'safe'],
            [['machine_id'], 'exist', 'skipOnError' => true, 'targetClass' => Machine::className(), 'targetAttribute' => ['machine_id' => 'machine_id']],
            [['operation_id'], 'exist', 'skipOnError' => true, 'targetClass' => Operation::className(), 'targetAttribute' => ['operation_id' => 'operation_id']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'operation_data_id' => 'Operation Data ID',
            'operation_id' => 'Operation ID',
            'machine_id' => 'Machine ID',
            'cost_of_machine_operation' => 'Cost Of Machine Operation', 
            'hours' => 'Hours',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
        ];
    }

    /**
     * Gets query for [[Machine]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getMachine()
    {
        return $this->hasOne(Machine::className(), ['machine_id' => 'machine_id']);
    }

    /**
     * Gets query for [[Operation]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getOperation()
    {
        return $this->hasOne(Operation::className(), ['operation_id' => 'operation_id']);
    }
}
