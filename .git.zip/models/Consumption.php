<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "consumption".
 *
 * @property int $consumption_id
 * @property string $date
 * @property int $raw_material_id
 * @property int $mine_location_id
 * @property float $quantity
 * @property float $cost
 * @property string $created_at
 * @property string $updated_at
 * @property int $is_delete
 *
 * @property MineLocation $mineLocation
 * @property RawMaterial $rawMaterial
 */
class Consumption extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'consumption';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['date', 'raw_material_id', 'mine_location_id', 'quantity',  'cost'], 'required'],
            [['date', 'created_at', 'updated_at'], 'safe'],
            [['raw_material_id', 'mine_location_id', 'is_delete'], 'integer'],
            [['quantity', 'cost'], 'number'],
            [['mine_location_id'], 'exist', 'skipOnError' => true, 'targetClass' => MineLocation::className(), 'targetAttribute' => ['mine_location_id' => 'mine_location_id']],
            [['raw_material_id'], 'exist', 'skipOnError' => true, 'targetClass' => RawMaterial::className(), 'targetAttribute' => ['raw_material_id' => 'raw_material_id']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'consumption_id' => 'Consumption ID',
            'date' => 'Date',
            'raw_material_id' => 'Raw Material',
            'mine_location_id' => 'Mine Location',
            'quantity' => 'Quantity',
            'cost' => 'Other Costs Incurred',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
            'is_delete' => 'Is Delete',
        ];
    }

    /**
     * Gets query for [[MineLocation]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getMineLocation()
    {
        return $this->hasOne(MineLocation::className(), ['mine_location_id' => 'mine_location_id']);
    }

    /**
     * Gets query for [[RawMaterial]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getRawMaterial()
    {
        return $this->hasOne(RawMaterial::className(), ['raw_material_id' => 'raw_material_id']);
    }
}
