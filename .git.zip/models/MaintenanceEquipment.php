<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "maintenance_equipment".
 *
 * @property int $maintenance_equipment_id
 * @property int $maintenance_id
 * @property int $equipment_id
 * @property string $created_at
 *
 * @property Equipment $equipment
 * @property Maintenance $maintenance
 */
class MaintenanceEquipment extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'maintenance_equipment';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['maintenance_id', 'equipment_id'], 'required'],
            [['maintenance_id', 'equipment_id'], 'integer'],
            [['created_at'], 'safe'],
            [['equipment_id'], 'exist', 'skipOnError' => true, 'targetClass' => Equipment::className(), 'targetAttribute' => ['equipment_id' => 'equipment_id']],
            [['maintenance_id'], 'exist', 'skipOnError' => true, 'targetClass' => Maintenance::className(), 'targetAttribute' => ['maintenance_id' => 'maintenance_id']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'maintenance_equipment_id' => 'Maintenance Equipment ID',
            'maintenance_id' => 'Maintenance ID',
            'equipment_id' => 'Equipment ID',
            'created_at' => 'Created At',
        ];
    }

    /**
     * Gets query for [[Equipment]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getEquipment()
    {
        return $this->hasOne(Equipment::className(), ['equipment_id' => 'equipment_id']);
    }

    /**
     * Gets query for [[Maintenance]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getMaintenance()
    {
        return $this->hasOne(Maintenance::className(), ['maintenance_id' => 'maintenance_id']);
    }
}
