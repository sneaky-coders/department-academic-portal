<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "production_analysis".
 *
 * @property int $production_analysis_id
 * @property int $component_id
 * @property string $value
 *
 * @property Production[] $productions
 * @property ProductComponent $component
 */
class ProductionAnalysis extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'production_analysis';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
           
            [['production_id', 'component_id', 'value'], 'required'],
            [['production_id', 'component_id'], 'integer'],
            [['value'], 'string', 'max' => 40],
            [['component_id'], 'exist', 'skipOnError' => true, 'targetClass' => ProductComponent::className(), 'targetAttribute' => ['component_id' => 'product_component_id']],
            [['production_id'], 'exist', 'skipOnError' => true, 'targetClass' => Production::className(), 'targetAttribute' => ['production_id' => 'production_id']], 
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'production_analysis_id' => 'Production Analysis ID',
            'production_id' => 'Production ID', 
            'component_id' => 'Component ID',
            'value' => 'Value',
        ];
    }

  /** 
	* Gets query for [[Production]]. 
	* 
	* @return \yii\db\ActiveQuery 
	*/ 
    public function getProduction() 
    { 
        return $this->hasOne(Production::className(), ['production_id' => 'production_id']); 
    } 
    /**
     * Gets query for [[Component]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getComponent()
    {
        return $this->hasOne(ProductComponent::className(), ['product_component_id' => 'component_id']);
    }
}
