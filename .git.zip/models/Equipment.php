<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "equipment".
 *
 * @property int $equipment_id
 * @property string $name
 * @property string $created_at
 * @property string $updated_at
 * @property int $is_deleted
 */
class Equipment extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'equipment';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['name','mine_location_id'], 'required'],
            [['created_at', 'updated_at'], 'safe'],
            [['is_deleted'], 'integer'],
            [['name'], 'string', 'max' => 200],
            [['mine_location_id'], 'exist', 'skipOnError' => true, 'targetClass' => MineLocation::className(), 'targetAttribute' => ['mine_location_id' => 'mine_location_id']], 
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'equipment_id' => 'Equipment ID',
            'mine_location_id' => 'Mine Location',
            'name' => 'Name',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
            'is_deleted' => 'Is Deleted',
        ];
    }

    
	/** 
	* Gets query for [[MineLocation]]. 
	* 
	* @return \yii\db\ActiveQuery 
	*/ 
    public function getMineLocation() 
    { 
        return $this->hasOne(MineLocation::className(), ['mine_location_id' => 'mine_location_id']); 
    } 
}
