<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "daily_works".
 *
 * @property int $daily_works_id
 * @property string $date
 * @property string $nature_of_job
 * @property string $location
 * @property int $mine_location
 * @property string $resources_employed
 * @property string $distance_travelled
 * @property string $vehicles_used
 * @property float $cost_incurred
 * @property string $created_at
 * @property string $updated_at
 * @property int $is_delete
 *
 * @property MineLocation $mineLocation
 */
class DailyWorks extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'daily_works';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['date', 'nature_of_job', 'location', 'mine_location_id', 'resources_employed', 'distance_travelled', 'vehicles_used', 'cost_incurred'], 'required'],
            [['date', 'created_at', 'updated_at','mine_location_id'], 'safe'],
            [['location', 'resources_employed'], 'string'],
            [[ 'is_delete'], 'integer'],
            [['cost_incurred'], 'number'],
            [['nature_of_job'], 'string', 'max' => 90],
            [['distance_travelled', 'vehicles_used'], 'string', 'max' => 80],
            [['mine_location_id'], 'exist', 'skipOnError' => true, 'targetClass' => MineLocation::className(), 'targetAttribute' => ['mine_location_id' => 'mine_location_id']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'daily_works_id' => 'Daily Works ID',
            'date' => 'Date',
            'nature_of_job' => 'Nature Of Job',
            'location' => 'Location',
            'mine_location_id' => 'Mine Location',
            'resources_employed' => 'Resources Employed',
            'distance_travelled' => 'Distance Travelled',
            'vehicles_used' => 'Vehicles Used',
            'cost_incurred' => 'Cost Incurred',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
            'is_delete' => 'Is Delete',
        ];
    }

    /**
     * Gets query for [[MineLocation]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getMineLocation()
    {
        return $this->hasOne(MineLocation::className(), ['mine_location_id' => 'mine_location_id']);
    }
}
