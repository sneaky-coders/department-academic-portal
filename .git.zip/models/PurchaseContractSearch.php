<?php

namespace app\models;

use yii\base\Model;
use yii\data\ActiveDataProvider;
use app\models\PurchaseContract;

/**
 * PurchaseContractSearch represents the model behind the search form of `app\models\PurchaseContract`.
 */
class PurchaseContractSearch extends PurchaseContract
{
    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['purchase_contract_id',  'unit_id', 'mine_location_id', 'currency_id', 'is_deleted'], 'integer'],
            [['date', 'contract_no','supplier_id', 'product_id', 'product_grade_id', 'specification', 'mode_of_payment', 'terms_of_delivery', 'created_at', 'updated_at'], 'safe'],
            [['size', 'price', 'vat'], 'number'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params)
    {
        $query = PurchaseContract::find();

        // add conditions that should always apply here

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
        ]);

        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }
        $query->joinWith(['supplier','product','productGrade']);
        // grid filtering conditions
        $query->andFilterWhere([
            'purchase_contract_id' => $this->purchase_contract_id,
            'date' => $this->date,
           // 'supplier_id' => $this->supplier_id,
           // 'product_id' => $this->product_id,
            //'product_grade_id' => $this->product_grade_id,
            'size' => $this->size,
            'unit_id' => $this->unit_id,
            'mine_location_id' => $this->mine_location_id,
            'price' => $this->price,
            'currency_id' => $this->currency_id,
            'vat' => $this->vat,
            'created_at' => $this->created_at,
            'updated_at' => $this->updated_at,
            'is_deleted' => $this->is_deleted,
        ]);

        $query->andFilterWhere(['like', 'contract_no', $this->contract_no])
            ->andFilterWhere(['like', 'specification', $this->specification])
            ->andFilterWhere(['like', 'mode_of_payment', $this->mode_of_payment])
            ->andFilterWhere(['like', 'supplier.name', $this->supplier_id])
            ->andFilterWhere(['like', 'product.product_name', $this->product_id])
            ->andFilterWhere(['like', 'product_grade.name', $this->product_grade_id])
            ->andFilterWhere(['like', 'terms_of_delivery', $this->terms_of_delivery]);

        return $dataProvider;
    }
}
