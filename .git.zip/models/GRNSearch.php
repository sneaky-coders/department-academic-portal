<?php

namespace app\models;

use yii\base\Model;
use yii\data\ActiveDataProvider;
use app\models\GRN;

/**
 * GRNSearch represents the model behind the search form of `app\models\GRN`.
 */
class GRNSearch extends GRN
{
    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['grn_id', 'purchase_contract_id', 'supplier_id', 'raw_material_id', 'is_delete'], 'integer'],
            [['date', 'po_no', 'truck_no', 'driver_name', 'remark', 'created_at', 'updated_at'], 'safe'],
            [['quantity_received'], 'number'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params)
    {
        $query = GRN::find();

        // add conditions that should always apply here

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
        ]);

        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }

        // grid filtering conditions
        $query->andFilterWhere([
            'grn_id' => $this->grn_id,
            'purchase_contract_id' => $this->purchase_contract_id,
            'date' => $this->date,
            'supplier_id' => $this->supplier_id,
            'raw_material_id' => $this->raw_material_id,
            'quantity_received' => $this->quantity_received,
            'created_at' => $this->created_at,
            'updated_at' => $this->updated_at,
            'is_delete' => 0,
        ]);

        $query->andFilterWhere(['like', 'po_no', $this->po_no])
            ->andFilterWhere(['like', 'truck_no', $this->truck_no])
            ->andFilterWhere(['like', 'driver_name', $this->driver_name])
            ->andFilterWhere(['like', 'remark', $this->remark]);

        return $dataProvider;
    }
}
