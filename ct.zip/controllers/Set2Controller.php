<?php

namespace app\controllers;

use app\models\Questions;
use Yii;
use app\models\Set2;
use app\models\Users;
use app\models\SearchSet2;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use yii\data\ActiveDataProvider;


/**
 * Set2Controller implements the CRUD actions for Set2 model.
 */
class Set2Controller extends Controller
{
    /**
     * {@inheritdoc}
     */
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['POST'],
                ],
            ],
        ];
    }

    /**
     * Lists all Set2 models.
     * @return mixed
     */
    public function actionIndex()
    {
        if(!Yii::$app->user->isGuest)
        {
             if(Yii::$app->user->identity->level!=3)
            {
        $searchModel = new SearchSet2();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
        }
        else
        {
            return $this->redirect(['/site/login']);
        }
        }
    }


    public function actionRedder()
    {
        if(!Yii::$app->user->isGuest)
        {
            

            return $this->render('redder');
        }
        else
        {
            return $this->redirect(['/site/login']);
        }
        
    }

    /**
     * Displays a single Set2 model.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionView($id)
    {
        return $this->render('view', [
            'model' => $this->findModel($id),
        ]);
    }

    /**
     * Creates a new Set2 model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate()
    {
          if(!Yii::$app->user->isGuest)
        {
        $model = new Set2();
        $data = Questions::find()
        ->select(['title'])
        ->asArray()
        ->all();
          
        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['view', 'id' => $model->id]);
        }

        return $this->render('create', [
            'model' => $model,
            'data' => $data,
        ]);
        }
        else
        {
            return $this->redirect(['/site/login']);
        }
    }

    /**
     * Updates an existing Set2 model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionUpdate($id)
    {
         if(!Yii::$app->user->isGuest)
        {
        $model = $this->findModel($id);

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['view', 'id' => $model->id]);
        }

        return $this->render('update', [
            'model' => $model,
        ]);
        }
         else
        {
            return $this->redirect(['/site/login']);
        }
    }

    /**
     * Deletes an existing Set2 model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionDelete($id)
    {
          if(!Yii::$app->user->isGuest)
        {
        $this->findModel($id)->delete();

        return $this->redirect(['index']);
        }
         else
        {
            return $this->redirect(['/site/login']);
        }
    }

    public function actionReport()
    {
        if(!Yii::$app->user->isGuest){
            $usn = null;
            $searchModel = new SearchSet2();
            $query = Set2::find();
            $dataProvider = new ActiveDataProvider([
                'query' => $query,
                'pagination' => [
                    'pageSize' => 120, // Number of items per page
               
                ],
                'sort' => [
                    'defaultOrder' => ['total' => SORT_ASC], // Set the default sorting by 'total' column in ascending order.
                ],
                
            ]);
            $start_date = date('Y-m-1');
            $end_date = date('Y-m-t');
            if(Yii::$app->request->get('start_date') && Yii::$app->request->get('end_date')){
                $start_date = Yii::$app->request->get('start_date');
                $end_date = Yii::$app->request->get('end_date');
               
            }
            $query->andFilterWhere(['between', 'test_date', $start_date, $end_date]);
            $query->andFilterWhere(['usn' => $usn]);
            return $this->render('report', [
                'searchModel' => $searchModel,
                'dataProvider' => $dataProvider,
                'start_date' => $start_date,
                'end_date' => $end_date,
                'usn' => $usn
            ]);
        }else{
            return $this->redirect(['/site/login']);
        } 
    }

    public function actionStudent()
    {
        if(!Yii::$app->user->isGuest){
            $usn = Yii::$app->user->identity->usn;
            $searchModel = new SearchSet2();
            $query = Set2::find();
            $dataProvider = new ActiveDataProvider([
                'query' => $query,
                'sort' => [
                    'defaultOrder' => [
                        'test_date' => SORT_ASC,
                        
                        
                        
                    ]
                ],
            ]);
            $start_date = date('Y-m-1');
            $end_date = date('Y-m-t');
            if(Yii::$app->request->get('start_date') && Yii::$app->request->get('end_date')){
                $start_date = Yii::$app->request->get('start_date');
                $end_date = Yii::$app->request->get('end_date');
               
            }
            $query->andFilterWhere(['between', 'test_date', $start_date, $end_date]);
            $query->andFilterWhere(['usn' => $usn]);
            return $this->render('student', [
                'searchModel' => $searchModel,
                'dataProvider' => $dataProvider,
                'start_date' => $start_date,
                'end_date' => $end_date,
                'usn' => $usn
            ]);
        }else{
            return $this->redirect(['/site/login']);
        } 
    }





    

    /**
     * Finds the Set2 model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return Set2 the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = Set2::findOne($id)) !== null) {
            return $model;
        }

        throw new NotFoundHttpException('The requested page does not exist.');
    }
}
