<?php

namespace app\controllers;

use Yii;
use app\models\Jobconversion;
use app\models\SearchJobconversion;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use yii\web\UploadedFile;

/**
 * JobconversionController implements the CRUD actions for Jobconversion model.
 */
class JobconversionController extends Controller
{
    /**
     * {@inheritdoc}
     */
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['POST'],
                ],
            ],
        ];
    }

    /**
     * Lists all Jobconversion models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new SearchJobconversion();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Displays a single Jobconversion model.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionView($id)
    {
        return $this->render('view', [
            'model' => $this->findModel($id),
        ]);
    }

    /**
     * Creates a new Jobconversion model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate()
    {
        if (!Yii::$app->user->isGuest) {
           

            $model = new Jobconversion();

        if ($model->load(Yii::$app->request->post())) {

            $usn = Yii::$app->user->identity->username;

            $model->intershipoffer = UploadedFile::getInstance($model, 'intershipoffer');
            $model->offerletter = UploadedFile::getInstance($model, 'offerletter');
            $filename = 'Internship'.$usn . '.' . $model->intershipoffer->extension;
            $filename1 = 'Offerletter'.$usn . '.' . $model->offerletter->extension;
            $model->intershipoffer->saveAs('uploads/' . $filename);
            $model->offerletter->saveAs('uploads/' . $filename1);
            $model->intershipoffer = $filename;
            $model->offerletter = $filename1;
            $model->save();
            return $this->redirect(['view', 'id' => $model->id]);
        }

        return $this->render('create', [
            'model' => $model,
        ]);
     }else {
        return $this->redirect(['/site/login']);
    }
    }

    /**
     * Updates an existing Jobconversion model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionUpdate($id)
    {
        $model = $this->findModel($id);

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['view', 'id' => $model->id]);
        }

        return $this->render('update', [
            'model' => $model,
        ]);
    }

    /**
     * Deletes an existing Jobconversion model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionDelete($id)
    {
        $this->findModel($id)->delete();

        return $this->redirect(['index']);
    }

    /**
     * Finds the Jobconversion model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return Jobconversion the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = Jobconversion::findOne($id)) !== null) {
            return $model;
        }

        throw new NotFoundHttpException('The requested page does not exist.');
    }
}
