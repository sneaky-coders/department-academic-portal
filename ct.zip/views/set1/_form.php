<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\helpers\ArrayHelper;
use app\models\Questions;

/* @var $this yii\web\View */
/* @var $model app\models\Set1 */
/* @var $form yii\widgets\ActiveForm */
?>

<style>
.control-label
{
  user-select: none;
}

/* Remove default radio button styles */
input[type="radio"] {
  -webkit-appearance: none;
  -moz-appearance: none;
  appearance: none;
  margin: 0;
  padding: 0;
  width: 16px;
  height: 16px;
  border: 2px solid #ccc;
  border-radius: 50%;
  outline: none;
  cursor: pointer;
  position: relative;
}

/* Custom radio button styles */
input[type="radio"]:checked {
  border-color: #007bff; /* Change the color for the checked state */
  background-color: #007bff;
}

/* Optional: Radio button label styles */
.radio-label {
  margin-left: 5px;
  font-size: 16px;
}

/* Optional: Radio button container styles */
.radio-container {
  display: flex;
  align-items: center;
}

  </style>

<div class="Set1-form">

    <?php $form = ActiveForm::begin(); ?>







<p id="demo" style="float:right;font-size:15px">Ends In</p>

    <?php
  

$id= yii::$app->user->identity->user_id;


echo $form->field($model, 'user_id')

  ->hiddenInput(['value' => $id])

  ->label(false);
  


?>








    <div class="col-md-6">

    <?php
  

$usn= yii::$app->user->identity->usn;


echo $form->field($model, 'usn')

  ->hiddenInput(['value' => $usn])

  ->label(false);
  


?>


    <?= $form->field($model, 'total')->hiddenInput()->label(false) ?>

<?= $form->field($model, 'q1')->textInput(['maxlength' => true,'class' => 'q1'])->label('Q1. What will be the output of the following code snippet? <br>
void solve() {<br>
    deque<int> dq;<br>
    for(int i = 1; i <= 5; i++) {<br>
        if(i % 2 == 0) {<br>
            dq.push_back(i);<br>
        }<br>
        else {<br>
            dq.push_front(i);<br>
        }<br>
    }<br>
    for(auto x: dq) {<br>
        cout << x << " ";<br>
    }<br>
    cout << endl;<br>
 }')->radioList([
  'a' => '1 2 3 4 5',
  'b' => '5 4 3 2 1',
  'c' => '1 3 5 2 4',
  'd' => '5 3 1 2 4',
],['onClick' => 'getValue($(this).val());'])?> 

<?= $form->field($model, 'q2')->textInput(['maxlength' => true])->label("Q2. Which of the following algorithms are used for string and pattern matching problems?")->radioList([
   'a' => 'Z Algorithm ',
   'b' => 'Rabin Karp Algorithm',
   'c' => 'KMP Algorithm',
   'd' => 'All the above',
],['onClick' => 'getValue($(this).val());'])?> 

<?= $form->field($model, 'q3')->textInput(['maxlength' => true])->label("Q3. What is the information, which a LinkedList’s Node must store?")->radioList([
   'a' => 'The address of the next node if it exits ',
   'b' => 'The value of the current node',
   'c' => 'Both (A) and (B)',
   'd' => 'None of the above',
],['onClick' => 'getValue($(this).val());'])?> 

<?= $form->field($model, 'q4')->textInput(['maxlength' => true])->label("Q4. Which of the following statements is true about AVL Trees?")->radioList([
  'a' => 'The difference between the heights of left and right nodes cannot be more than 1',
  'b' => 'The height of an AVL always remains of the order of 0(logn)',
  'c' => 'AVL Trees are a type of self-balancing Binary Search Trees',
  'd' => 'All of the above',
],['onClick' => 'getValue($(this).val());'])?> 

<?= $form->field($model, 'q5')->textInput(['maxlength' => true])->label("Q5. void solve(vector<vector<int>> edges) {<br>
   int count = 0;<br>
   for(auto x: edges) {<br>
       for(auto y: x) {<br>
           count += 1;<br>
       }
   }<br>
   cout << count / 2 << endl;
}")->radioList([
   'a' => 'Calculates the number of edges in an undirected graph',
   'b' => 'Calculates the number of nodes in a given graph',
   'c' => 'Calculates the sum of degrees of all odes in a given graph',
   'd' => 'None of the above',
],['onClick' => 'getValue($(this).val());'])?> 

<?= $form->field($model, 'q6')->textInput(['maxlength' => true])->label("Q6. What function is used to append a character at the back of a string in C++?")->radioList([
   'a' => 'push_back()',
   'b' => 'append()',
   'c' => ' push()',
   'd' => 'insert()',
],['onClick' => 'getValue($(this).val());'])?> 


<?= $form->field($model, 'q7')->textInput(['maxlength' => true])->label("Q7. 	When a pop() operation is called on an empty queue, what is the condition called?")->radioList([
   'a' => 'Overflow',
   'b' => 'Underflow',
   'c' => 'Syntax Error',
   'd' => 'Garbage Value',
],['onClick' => 'getValue($(this).val());'])?> 

<?= $form->field($model, 'q8')->textInput(['maxlength' => true])->label("Q8. 	Which of the following data structures finds its use in recursion?
")->radioList([
   'a' => 'Stack',
   'b' => 'Arrays',
   'c' => 'Linkedlist',
   'd' => 'Queues',
],['onClick' => 'getValue($(this).val());'])?> 

<?= $form->field($model, 'q9')->textInput(['maxlength' => true])->label("Q9. 	Which of the following concepts is not a part of Python?")->radioList([
   'a' => 'Pointers',
   'b' => 'Loops',
   'c' => 'Dynamic Typing',
   'd' => 'All the above',
],['onClick' => 'getValue($(this).val());'])?> 

<?= $form->field($model, 'q10')->textInput(['maxlength' => true])->label('Q10. 	Which of the following statements are used in Exception Handling in Python?')->radioList([
    'a' => 'try',
    'b' => 'except',
    'c' => 'finally',
    'd' => 'All the above',
],['onClick' => 'getValue($(this).val());'])?> 

<?= $form->field($model, 'q11')->textInput(['maxlength' => true])->label("Q11.Which of the following is the proper syntax to check if a particular element is present in a list?")->radioList([
   'a' => 'if ele in list',
   'b' => 'if not ele not in list',
   'c' => 'Both A & B',
   'd' => 'None of the above',
],['onClick' => 'getValue($(this).val());'])?> 


<?= $form->field($model, 'q12')->textInput(['maxlength' => true])->label("Q12. 	What will be the output of the following code snippet?
<br>
example = ['Sunday', 'Monday', 'Tuesday', 'Wednesday'];<br>
print(example[-3:-1])")->radioList([
  'a' => '["Monday","Tuesday"]',
  'b' => '["Sunday","Monday"]',
  'c' => '["Tuesday","Wednesday"]',
  'd' => '["Wednesday","Monday"]',

],['onClick' => 'getValue($(this).val());'])?> 

<?= $form->field($model, 'q13')->textInput(['maxlength' => true])->label("Q13.What will be the output of the following code snippet?
<br>
a = [1, 2]<br>
print(a * 3)")->radioList([
  'a' => 'Error',
  'b' => '(1,2)',
  'c' => '[1,2,1,2]',
  'd' => '[1,2,1,2,1,2]',
],['onClick' => 'getValue($(this).val());'])?> 



    </div>

<br>
<br>
<br>
<br>
<br>

    <div class="col-md-6">


    <?= $form->field($model, 'q14')->textInput(['maxlength' => true])->label("Q14. 	Which is defined by its characteristics attributes and procedures?")->radioList([
 'a' => 'File',
 'b' => 'Object',
 'c' => 'Record',
 'd' => 'Form',

],['onClick' => 'getValue($(this).val());'])?> 



<?= $form->field($model, 'q15')->textInput(['maxlength' => true])->label("Q15. 	SQL is an acronym for")->radioList([
 'a' => 'Sorted Query Language',
 'b' => 'Structured Quick Launch',
 'c' => 'Structured Quick Language',
 'd' => 'Structured Query Language',
],['onClick' => 'getValue($(this).val());'])?> 


<?= $form->field($model, 'q16')->textInput(['maxlength' => true])->label("16. Which of the following data types can be integer, float,double precision, data etc?")->radioList([
  'a' => 'Numeric',
  'b' => 'Primitive',
  'c' => 'Enumerated',
  'd' => 'User Defined',
],['onClick' => 'getValue($(this).val());'])?> 


<?= $form->field($model, 'q17')->textInput(['maxlength' => true])->label("Q17. What is the range of integers that can be held in the MEDIUMINT datatype of SQL?")->radioList([
  'a' => 'Signed numbers in the range of -8388608 to 8388607',
  'b' => 'Unsigned numbers in yhe range of 0 to 16777215',
  'c' => 'Both A and B',
  'd' => 'None of the above',
],['onClick' => 'getValue($(this).val());'])?> 


<?= $form->field($model, 'q18')->textInput(['maxlength' => true])->label("Q18. Which of the following functions do we use to get a specified day of the month for a given date?")->radioList([
   'a' => 'DAY',
   'b' => 'DAYPART',
   'c' => 'GETDATE',
   'd' => 'CURRENT_TIMESTAMP',
],['onClick' => 'getValue($(this).val());'])?> 


<?= $form->field($model, 'q19')->textInput(['maxlength' => true])->label("Q19. What is a table joined with itself called?")->radioList([
   'a' => 'Join',
   'b' => 'Self-Join',
   'c' => 'Outer Join',
   'd' => 'Natural Join',
],['onClick' => 'getValue($(this).val());'])?> 


<?= $form->field($model, 'q20')->textInput(['maxlength' => true])->label("Q20. Which of this keyword must be used to inherit a class?")->radioList([
   'a' => 'Super',
   'b' => 'this',
   'c' => 'extend',
   'd' => 'extends',
],['onClick' => 'getValue($(this).val());'])?> 


<?= $form->field($model, 'q21')->textInput(['maxlength' => true])->label("Q21. Which of these is correct way of inheriting class A by class B?")->radioList([
'a' => 'class B + class A {}',
'b' => 'class B inherits class A {}',
'c' => 'class B extends A {}',
'd' => 'class B extends class A {}',
],['onClick' => 'getValue($(this).val());'])?> 


<?= $form->field($model, 'q22')->textInput(['maxlength' => true])->label("Q22. How can we describe an array in the best possible way?")->radioList([
 'a' => 'The Array shows a hierarchical structure.',
 'b' => 'Arrays are immutable.',
 'c' => 'Container that stores the elements of similar types',
 'd' => 'The Array is not a data structure',
],['onClick' => 'getValue($(this).val());'])?> 


<?= $form->field($model, 'q23')->textInput(['maxlength' => true])->label("Q23. What is the output of the below code?
<br>
#include <stdio.h>  <br>
int main()  <br>
{  <br>
   int arr[5]={10,20,30,40,50};<br>  
   printf('%d', arr[5]);<br>  
  
    return 0;  <br>
}  ")->radioList([
 'a' => 'Garbage Value',
 'b' => '10',
 'c' => '50',
 'd' => 'None of the above',
],['onClick' => 'getValue($(this).val());'])?> 

<?= $form->field($model, 'q24')->textInput(['maxlength' => true])->label("Q24. Which one of the following is not the application of the stack data structure")
->radioList([
'a' => 'String reversal',
'b' => 'Recursion',
'c' => 'Backtracking',
'd' => 'Asynchronous data transfer',
],['onClick' => 'getValue($(this).val());'])?> 


<?= $form->field($model, 'q25')->textInput(['maxlength' => true])->label("Q25. What will be the output of the following code snippet?
<br>
void solve() {<br>
   string s = '00000001111111';<br>
   int l = 0, r = s.size() - 1, ans = -1;<br>
   while(l <= r) {<br>
       int mid = (l + r) / 2;<br>
       if(s[mid] == '1') {<br>
           ans = mid;<br>
           r = mid - 1;<br>
       }<br>
       else {<br>
           l = mid + 1;<br>
       }<br>
   }<br>
   cout << ans << endl;<br>
}<br>
")->radioList([
  'a' => '6',
  'b' => '7',
  'c' => '0',
  'd' => '1',
],['onClick' => 'getValue($(this).val());'])?> 

    </div>





   

 



    <div class="form-group">
  
        <?= Html::submitButton('Save', [  'class' => 'btn btn-danger',
            'data' => [
                'confirm' => 'Are you sure you want to Submit?',
                'method' => 'post',
            ],]) ?>
            
    </div>

    <?php ActiveForm::end(); ?>

</div>



 

<script>

function getValue($value) {
  qt1 = $("input:radio[name='Set1[q1]']:checked").val();
   var q1,q2,q3,q4,q5,q6,q7,q8,q9,q10,q11,q12,q13,q14,q15,q16,q17,q18,q19,q20,q21,q22,q23,q24,q25;
   var total;
   if(qt1 == 'd')
   {
     q1 = 1;
  
   }
   else
   {
      q1 = 0;
     
   }
   
   qt2 = $("input:radio[name='Set1[q2]']:checked").val();
   if(qt2 == 'd')
   {
     q2 = 1;
  
   }
   else
   {
      q2 = 0;
     
   }
   qt3 = $("input:radio[name='Set1[q3]']:checked").val();
   if(qt3 == 'c')
   {
     q3 = 1;
  
   }
   else
   {
      q3 = 0;
     
   }
   qt4 = $("input:radio[name='Set1[q4]']:checked").val();
   if(qt4 == 'd')
   {
     q4 = 1;
  
   }
   else
   {
      q4 = 0;
     
   }
   qt5 = $("input:radio[name='Set1[q5]']:checked").val();
   if(qt5 == 'a')
   {
     q5 = 1;
  
   }
   else
   {
      q5 = 0;
     
   }
   qt6 = $("input:radio[name='Set1[q6]']:checked").val();
   if(qt6 == 'a')
   {
     q6 = 1;
  
   }
   else
   {
      q6 = 0;
     
   }
   qt7 = $("input:radio[name='Set1[q7]']:checked").val();
   if(qt7 == 'b')
   {
     q7 = 1;
  
   }
   else
   {
      q7 = 0;
     
   }
   qt8 = $("input:radio[name='Set1[q8]']:checked").val();
   if(qt8 == 'a')
   {
     q8 = 1;
  
   }
   else
   {
      q8 = 0;
     
   }
   qt9 = $("input:radio[name='Set1[q9]']:checked").val();
   if(qt9 == 'a')
   {
     q9 = 1;
  
   }
   else
   {
      q9 = 0;
     
   }
   qt10 = $("input:radio[name='Set1[q10]']:checked").val();
   if(qt10 == 'd')
   {
     q10 = 1;
  
   }
   else
   {
      q10 = 0;
     
   }
   qt11 = $("input:radio[name='Set1[q11]']:checked").val();
   if(qt11 == 'c')
   {
     q11 = 1;
  
   }
   else
   {
      q11 = 0;
     
   }
   qt12 = $("input:radio[name='Set1[q12]']:checked").val();
   if(qt12 == 'a')
   {
     q12 = 1;
  
   }
   else
   {
      q12 = 0;
     
   }
   qt13 = $("input:radio[name='Set1[q13]']:checked").val();
   if(qt13 == 'd')
   {
     q13 = 1;
  
   }
   else
   {
      q13 = 0;
     
   }
   qt14 = $("input:radio[name='Set1[q14]']:checked").val();
   if(qt14 == 'b')
   {
     q14 = 1;
  
   }
   else
   {
      q14 = 0;
     
   }
   qt15 = $("input:radio[name='Set1[q15]']:checked").val();
   if(qt15 == 'd')
   {
     q15 = 1;
  
   }
   else
   {
      q15 = 0;
     
   }
   qt16 = $("input:radio[name='Set1[q16]']:checked").val();
   if(qt16 == 'a')
   {
     q16 = 1;
  
   }
   else
   {
      q16 = 0;
     
   }
   qt17 = $("input:radio[name='Set1[q17]']:checked").val();
   if(qt17 == 'c')
   {
     q17 = 1;
  
   }
   else
   {
      q17 = 0;
     
   }
   qt18 = $("input:radio[name='Set1[q18]']:checked").val();
   if(qt18 == 'a')
   {
     q18 = 1;
  
   }
   else
   {
      q18 = 0;
     
   }
   qt19 = $("input:radio[name='Set1[q19]']:checked").val();
   if(qt19 == 'b')
   {
     q19 = 1;
  
   }
   else
   {
      q19 = 0;
     
   }
   qt20 = $("input:radio[name='Set1[q20]']:checked").val();
   if(qt20 == 'd')
   {
     q20 = 1;
  
   }
   else
   {
      q20 = 0;
     
   }
   qt21 = $("input:radio[name='Set1[q21]']:checked").val();
   if(qt21 == 'c')
   {
     q21 = 1;
  
   }
   else
   {
      q21 = 0;
     
   }
   qt22 = $("input:radio[name='Set1[q22]']:checked").val();
   if(qt22 == 'c')
   {
     q22 = 1;
  
   }
   else
   {
      q22 = 0;
     
   }
   qt23 = $("input:radio[name='Set1[q23]']:checked").val();
   if(qt23 == 'a')
   {
     q23 = 1;
  
   }
   else
   {
      q23 = 0;
     
   }
   qt24 = $("input:radio[name='Set1[q24]']:checked").val();
   if(qt24 == 'd')
   {
     q24 = 1;
  
   }
   else
   {
      q24 = 0;
     
   }
   qt25 = $("input:radio[name='Set1[q25]']:checked").val();
   if(qt25 == 'b')
   {
     q25 = 1;
  
   }
   else
   {
      q25 = 0;
     
   }
   total =  q1+q2+q3+q4+q5+q6+q7+q8+q9+q10+q11+q12+q13+q14+q15+q16+q17+q18+q19+q20+q21+q22+q23+q24+q25;
  
        
   $('#set1-total').val(total)
   console.log(total)
}




</script>

<script>
// Set the date we're counting down to
var countDownDate = new Date("July 31, 2023 19:30:00").getTime();

// Update the count down every 1 second
var x = setInterval(function() {

  // Get today's date and time
  var now = new Date().getTime();

  // Find the distance between now and the count down date
  var distance = countDownDate - now;

  // Time calculations for days, hours, minutes and seconds
  var days = Math.floor(distance / (1000 * 60 * 60 * 24));
  var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
  var seconds = Math.floor((distance % (1000 * 60)) / 1000);

  // Display the result in the element with id="demo"
  document.getElementById("demo").innerHTML = " Ends In: "+days + "d " + hours + "h "
  + minutes + "m " + seconds + "s ";
   var redirecct;
  // If the count down is finished, write some text
  if (distance < 0) {
    clearInterval(x);
      redirecct == -1;
    //document.getElementById("w0").submit();
  }

  if (redirecct < 0) {
    

      window.location.replace('../site');
  }


 
}, 1000);
</script>