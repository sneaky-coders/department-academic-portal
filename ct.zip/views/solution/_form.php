<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use app\models\Questions;
use yii\helpers\ArrayHelper;
use kartik\select2\Select2;

/* @var $this yii\web\View */
/* @var $model app\models\Solution */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="solution-form">

    <?php $form = ActiveForm::begin(); ?>

    <div class="col-md-12">
<?php $client = Questions::find()->all();
 
 $data = ArrayHelper::map($client, 'id','title');
 
?>
<?= $form->field($model, 'q_id')->widget(Select2::classname(), [
'data' => $data,
'language' => 'en',
'options' => ['placeholder' => 'Search CQuestion'],
'pluginOptions' => [
'allowClear' => true
],
]); ?>


</div>

    <?= $form->field($model, 'sol')->textInput(['maxlength' => true]) ?>


    <div class="form-group">
        <?= Html::submitButton('Save', ['class' => 'btn btn-success']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
