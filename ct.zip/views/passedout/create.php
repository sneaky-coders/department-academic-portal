<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model app\models\Passedout */

$this->title = 'Create Passedout';
$this->params['breadcrumbs'][] = ['label' => 'Passedouts', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="passedout-create">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
