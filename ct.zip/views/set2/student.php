<?php

use kartik\date\DatePicker;
use yii\helpers\Html;
use yii\helpers\ArrayHelper;
use yii\widgets\ActiveForm;
use kartik\select2\Select2;
use yii\data\ActiveDataProvider;
use yii\helpers\Url;

$this->title = "Mark Responses";
?>

<?php 



?>
<?php $form = ActiveForm::begin([
                'method' => 'get',
            ]); ?>
<input type="hidden" name="_csrf" value="<?=Yii::$app->request->getCsrfToken()?>" />
<div class="row">
    <div class="col-md-3">
        <?php 
            echo DatePicker::widget([
                'name' => 'start_date',
                'value' => $start_date,
                'options' => ['placeholder' => 'Start Date'],
                'type' => DatePicker::TYPE_COMPONENT_APPEND,
                'pluginOptions' => [
                    'autoclose'=>true,
                    'format' => 'yyyy-mm-dd'
                ]
            ]);
        ?>
    </div>
    
    <div class="col-md-3">
        <?php 
            echo DatePicker::widget([
                'name' => 'end_date',
                'value' => $end_date,
                'options' => ['placeholder' => 'End Date'],
                'type' => DatePicker::TYPE_COMPONENT_APPEND,
                'pluginOptions' => [
                    'autoclose'=>true,
                    'format' => 'yyyy-mm-dd'
                ]
            ]);
        ?>
    </div>


    

    
    <div class="col-md-2">
        <div class="form-group">
            <?= Html::submitButton('Filter', ['class' => 'btn btn-default']) ?>
        </div>

        <div>
       
        </div>
    </div>
    <?php ActiveForm::end(); ?>
</div>
<table class="table table-hover">
    <tr class="table table-info">
        <th>Sr. No</th>
        <th>USN</th>
        <th>Q1</th>
        <th>Q2</th>
        <th>Q3</th>
        <th>Q4</th>
        <th>Q5</th>
        <th>Q6</th>
        <th>Q7</th>
        <th>Q8</th>
        <th>Q9</th>
        <th>Q10</th>
        <th>Q11</th>
        <th>Q12</th>
        <th>Q13</th>
        <th>Q14</th>
        <th>Q15</th>
        <th>Q16</th>
        <th>Q17</th>
        <th>Q18</th>
        <th>Q19</th>
        <th>Q20</th>
        <th>Q21</th>
        <th>Q22</th>
        <th>Q23</th>
        <th>Q24</th>
        <th>Q25</th>
       <th>TOTAL Score</th>
    
    </tr>

    <tr>
    <?php 
  
        $models = $dataProvider->getModels();
        foreach ($models as $key => $model) {
           
            
            if ($model->q1 == 'd') {
                $scoreq1 = 1;
            } else {
                $scoreq1 = 0;
            }

            if ($model->q2 == 'a') {
                $scoreq2 = 1;
            } else {
                $scoreq2 = 0;
            }

            if ($model->q3 == 'a') {
                $scoreq3 = 1;
            } else {
                $scoreq3 = 0;
            }

            if ($model->q4 == 'a') {
                $scoreq4 = 1;
            } else {
                $scoreq4 = 0;
            }

            if ($model->q5 == 'b') {
                $scoreq5 = 1;
            } else {
                $scoreq5 = 0;
            }

            if ($model->q6 == 'a') {
                $scoreq6 = 1;
            } else {
                $scoreq6 = 0;
            }

            if ($model->q7 == 'd') {
                $scoreq7 = 1;
            } else {
                $scoreq7 = 0;
            }

            if ($model->q8 == 'd') {
                $scoreq8 = 1;
            } else {
                $scoreq8 = 0;
            }

            if ($model->q9 == 'c') {
                $scoreq9 = 1;
            } else {
                $scoreq9 = 0;
            }

            if ($model->q10 == 'a') {
                $scoreq10 = 1;
            } else {
                $scoreq10 = 0;
            }

            if ($model->q11 == 'a') {
                $scoreq11 = 1;
            } else {
                $scoreq11 = 0;
            }

            if ($model->q12 == 'c') {
                $scoreq12 = 1;
            } else {
                $scoreq12 = 0;
            }

            if ($model->q13 == 'e') {
                $scoreq13 = 1;
            } else {
                $scoreq13 = 0;
            }

            if ($model->q14 == 'b') {
                $scoreq14 = 1;
            } else {
                $scoreq14 = 0;
            }

            if ($model->q15 == 'a') {
                $scoreq15 = 1;
            } else {
                $scoreq15 = 0;
            }

            if ($model->q16 == 'c') {
                $scoreq16 = 1;
            } else {
                $scoreq16 = 0;
            }

            if ($model->q17 == 'b') {
                $scoreq17 = 1;
            } else {
                $scoreq17 = 0;
            }

            if ($model->q18 == 'c') {
                $scoreq18 = 1;
            } else {
                $scoreq18 = 0;
            }

            if ($model->q19 == 'b') {
                $scoreq19 = 1;
            } else {
                $scoreq19 = 0;
            }

            if ($model->q20 == 'd') {
                $scoreq20 = 1;
            } else {
                $scoreq20 = 0;
            }

            if ($model->q21 == 'a') {
                $scoreq21 = 1;
            } else {
                $scoreq21 = 0;
            }

            if ($model->q22 == 'd') {
                $scoreq22 = 1;
            } else {
                $scoreq22 = 0;
            }

            if ($model->q23 == 'c') {
                $scoreq23 = 1;
            } else {
                $scoreq23 = 0;
            }

            if ($model->q24 == 'd') {
                $scoreq24 = 1;
            } else {
                $scoreq24 = 0;
            }

            if ($model->q25 == 'a') {
                $scoreq25 = 1;
            } else {
                $scoreq25 = 0;
            }


            
            
            $class = $model->total > 20 ? 'success' : 'warning';
     
            echo '<tr class="'. $class .'">
                <td>'. ($key + 1) .'</td>
                <td>'. $model->usn .'</td>
                <td>'. $scoreq1. '</td>
                <td>'. $scoreq2. '</td>
                <td>'. $scoreq3. '</td>
                <td>'. $scoreq4. '</td>
                <td>'. $scoreq5. '</td>
                <td>'. $scoreq6. '</td>
                <td>'. $scoreq7. '</td>
                <td>'. $scoreq8. '</td>
                <td>'. $scoreq9. '</td>
                <td>'. $scoreq10. '</td>
                <td>'. $scoreq11. '</td>
                <td>'. $scoreq12. '</td>
                <td>'. $scoreq13. '</td>
                <td>'. $scoreq14. '</td>
                <td>'. $scoreq15. '</td>
                <td>'. $scoreq16. '</td>
                <td>'. $scoreq17. '</td>
                <td>'. $scoreq18. '</td>
                <td>'. $scoreq19. '</td>
                <td>'. $scoreq20. '</td>
                <td>'. $scoreq21. '</td>
                <td>'. $scoreq22. '</td>
                <td>'. $scoreq23. '</td>
                <td>'. $scoreq24. '</td>
                <td>'. $scoreq25. '</td>
                <td>'. $model->total. '</td>
       
       
            </tr>';
        }
  
    ?>
    </tr>
    
    
</table>

<div class="chart-container" style="position: relative; height:40vh; width:80vw">
    <canvas id="scores"></canvas>
</div>
