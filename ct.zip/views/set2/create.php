<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model app\models\Set2 */

$this->title = 'MOCK TEST Set 2';
?>
<div class="set2-create">

   <center> <h3 style="align:center;"><?= Html::encode($this->title) ?></h3></center>

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
