<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\helpers\ArrayHelper;
use app\models\Questions;

/* @var $this yii\web\View */
/* @var $model app\models\Set2 */
/* @var $form yii\widgets\ActiveForm */
?>

<style>
  .control-label {
    user-select: none;
  }

  /* Remove default radio button styles */
  input[type="radio"] {
    -webkit-appearance: none;
    -moz-appearance: none;
    appearance: none;
    margin: 0;
    padding: 0;
    width: 16px;
    height: 16px;
    border: 2px solid #ccc;
    border-radius: 50%;
    outline: none;
    cursor: pointer;
    position: relative;
  }

  /* Custom radio button styles */
  input[type="radio"]:checked {
    border-color: #007bff;
    /* Change the color for the checked state */
    background-color: #007bff;
  }

  /* Optional: Radio button label styles */
  .radio-label {
    margin-left: 5px;
    font-size: 16px;
  }

  /* Optional: Radio button container styles */
  .radio-container {
    display: flex;
    align-items: center;
  }
</style>

<div class="set2-form">

  <?php $form = ActiveForm::begin(); ?>







  <p id="demo" style="float:right;font-size:15px">Ends In</p>

  <?php


  $id = yii::$app->user->identity->user_id;


  echo $form->field($model, 'user_id')

    ->hiddenInput(['value' => $id])

    ->label(false);



  ?>








  <div class="col-md-6">

    <?php


    $usn = yii::$app->user->identity->usn;


    echo $form->field($model, 'usn')

      ->hiddenInput(['value' => $usn])

      ->label(false);



    ?>


    <?= $form->field($model, 'total')->hiddenInput()->label(false) ?>

    <?= $form->field($model, 'q1')->textInput(['maxlength' => true, 'class' => 'q1'])->label("Q1. A, B and C can do a piece of work in 15, 10 and 30 days respectively. In how many days can A do the work if he is assisted by B and C on every 3rd day?")->radioList([
      'a' => '15 Days',
      'b' => '3 Days',
      'c' => '6 Days',
      'd' => '9 Days',
    ], ['onClick' => 'getValue($(this).val());']) ?>

    <?= $form->field($model, 'q2')->textInput(['maxlength' => true])->label("Q2. Complete the series 1,6,13,22,33,..")->radioList([
      'a' => '46',
      'b' => '48',
      'c' => '49',
      'd' => '51',
    ], ['onClick' => 'getValue($(this).val());']) ?>

    <?= $form->field($model, 'q3')->textInput(['maxlength' => true])->label("Q3. How is an array initialized in C language?")->radioList([
      'a' => 'int a[3] = {1,2,3};',
      'b' => 'int a = {1,2,3};',
      'c' => 'int a[] = new int[3]',
      'd' => 'int a(3) = [1,2,3];',
    ], ['onClick' => 'getValue($(this).val());']) ?>

    <?= $form->field($model, 'q4')->textInput(['maxlength' => true])->label("Q4. A garden is in the form a rectangle having its side (length and breadth) in the ratio 7:5 and the area of the garden is 3500² Then find the perimeter of the garden.")->radioList([
      'a' => '240m',
      'b' => '140m',
      'c' => '180m',
      'd' => '290m',
      'd' => '320m',
    ], ['onClick' => 'getValue($(this).val());']) ?>

    <?= $form->field($model, 'q5')->textInput(['maxlength' => true])->label("Q5. 	Find the least number which when divided by 6, 7, 8, 9, and 12, leaves remainder 4 in each case?")->radioList([
      'a' => '504',
      'b' => '508',
      'c' => '606',
      'd' => '656',
      'e' => 'None',
    ], ['onClick' => 'getValue($(this).val());']) ?>

    <?= $form->field($model, 'q6')->textInput(['maxlength' => true])->label("Q6. A man and his wife appear in an interview for two vacancies in the same post. The probability of husband’s selection is (1/7) and the probability of wife’s selection is (1/5). What is the probability that only one of them is selected?")->radioList([
      'a' => '2/7',
      'b' => '1/7',
      'c' => '3/4',
      'd' => '4/5',
      'e' => 'None',
    ], ['onClick' => 'getValue($(this).val());']) ?>


    <?= $form->field($model, 'q7')->textInput(['maxlength' => true])->label("Q7. 	What will the output of the following code snippet?<br> void solve() {
   int a[] = {1, 2, 3, 4, 5};<br>
   int sum = 0;<br>
   for(int i = 0; i < 5; i++) {<br>
       if(i % 2 == 0) {<br>
           sum += *(a + i);<br>
       }<br>
       else {<br>
           sum -= *(a + i);
       }
   }<br>
   cout << sum << endl;<br>
} ")->radioList([
      'a' => '2',
      'b' => '15',
      'c' => 'Syntax Error',
      'd' => '3',
    ], ['onClick' => 'getValue($(this).val());']) ?>

    <?= $form->field($model, 'q8')->textInput(['maxlength' => true])->label("Q8. 	Average expenditure of Manoj & Nawaz is Rs 4500 which is 10% less than that of Sanjay & Irfan. If Sanjay spends Rs 500 more than Nawaz & average expenditure of Nawaz & Sanjay is Rs 4250. Find average expenditure of Manoj & Irfan. (in Rs)
")->radioList([
      'a' => '4250',
      'b' => '5000',
      'c' => '4750',
      'd' => '5250',
      'e' => '4500',
    ], ['onClick' => 'getValue($(this).val());']) ?>

    <?= $form->field($model, 'q9')->textInput(['maxlength' => true])->label("Q9. 	Let m be the least number divisible by 12,18,24,36,45, and m is also a perfect cube. What is the sum of digit of remainder when m is divided by 89?")->radioList([
      'a' => ' 17',
      'b' => '9',
      'c' => '6',
      'd' => '4',
      'e' => 'None',
    ], ['onClick' => 'getValue($(this).val());']) ?>

    <?= $form->field($model, 'q10')->textInput(['maxlength' => true])->label('Q10. 	A and B working alone can do a work in 40 days and 30 days respectively. They started the work together but B left after sometime and A finished remaining work in 5 days. Find after how many days from start B left the work?')->radioList([
      'a' => '15 Days',
      'b' => '14 Days',
      'c' => '16 Days',
      'd' => '12 Days',
      'e' => '18 Days',
    ], ['onClick' => 'getValue($(this).val());']) ?>

    <?= $form->field($model, 'q11')->textInput(['maxlength' => true])->label("Q11.What is the output of the following code snippet?<br>

void solve() {<br>
   stack<int> s;<br>
   s.push(1);<br>
   s.push(2);<br>
   s.push(3);<br>
   for(int i = 1; i <= 3; i++) {<br>
       cout << s.top() << “ “;<br>
       s.pop();<br>
   }
}")->radioList([
      'a' => '3 2 1',
      'b' => '1 2 3',
      'c' => '3',
      'd' => '1',
    ], ['onClick' => 'getValue($(this).val());']) ?>


    <?= $form->field($model, 'q12')->textInput(['maxlength' => true])->label("Q12. 	Find the largest number which divides 62, 132 and 237 to leave the same remainder in each case.")->radioList([
      'a' => '15',
      'b' => '25',
      'c' => '35',
      'd' => '55',
      'e' => 'None',
    ], ['onClick' => 'getValue($(this).val());']) ?>

<?= $form->field($model, 'q13')->textInput(['maxlength' => true])->label("Q13. 	A box contains 4 white, 6 green, 2 red and 5 yellow pens.
If 4 pens are picked at random, what is the probability that one of them is green, 2 are white and 1 is yellow?")->radioList([
      'a' => '3/169',
      'b' => '1/13',
      'c' => '9/13',
      'd' => '9/169',
      'd' => 'None',

    ], ['onClick' => 'getValue($(this).val());']) ?>



  </div>
  <br>
  <br>
  <br>
  <br>
  <br>
  <br>
  <br>
  <br>

  <div class="col-md-6">




  <?= $form->field($model, 'q14')->textInput(['maxlength' => true])->label("Q14. 	M scores more run than N but less than P. Q scores more than N but less than M. Who is the lowest scorer?")->radioList([
      'a' => 'M',
      'b' => 'N',
      'c' => 'P',
      'd' => 'Q',

    ], ['onClick' => 'getValue($(this).val());']) ?>


    <?= $form->field($model, 'q15')->textInput(['maxlength' => true])->label("Q15. 	One card is drawn at random from a pack of 52 cards. What is the probability that the card drawn is a face card (Jack, Queen and King only)?")->radioList([
      'a' => '3/13',
      'b' => '1/13',
      'c' => '3/52',
      'd' => '9/52',
      'e' => 'None',
    ], ['onClick' => 'getValue($(this).val());']) ?>


    <?= $form->field($model, 'q16')->textInput(['maxlength' => true])->label("16. Complete the series 9, 17, 33, 65, ?")->radioList([
      'a' => '22',
      'b' => '67',
      'c' => '129',
      'd' => '99',
    ], ['onClick' => 'getValue($(this).val());']) ?>


    <?= $form->field($model, 'q17')->textInput(['maxlength' => true])->label("Q17. The length of a rectangular field is increased by 20% and breadth is decreased by 20%. What is the per cent increase or decrease in its area?")->radioList([
      'a' => '20% Increase',
      'b' => '4% Increase',
      'c' => '1% Increase',
      'd' => 'No Change',
      'e' => 'None',
    ], ['onClick' => 'getValue($(this).val());']) ?>


    <?= $form->field($model, 'q18')->textInput(['maxlength' => true])->label("Q18. A statement is given below followed by two assumptions numbered I and II. You have to decide which of the assumption is implicit in the statement.
Statement:<br>
 A warning in a train compartment 'To stop train, pull the chain'. Penalty for improper use 1000.'
<br>
Assumptions.<br>
 I. Some people misuse the stop chain.<br>
 II. On certain occasions, people may want to stop a running train.'")->radioList([
      'a' => 'If only assumption I is implicit.',
      'b' => 'If only assumption II is implicit.',
      'c' => 'If both I and II are implicit.',
      'd' => 'If neither I nor II is implicit',
    ], ['onClick' => 'getValue($(this).val());']) ?>


    <?= $form->field($model, 'q19')->textInput(['maxlength' => true])->label("Q19. A invested Rs. X at 10% p.a. simple interest for 3 year and B invested (Rs. X + 500) at 15% p.a. simple interest for 2 years. If the sum of the interest earned by A and B after their investment period is Rs. 420, then what is the value of X?")->radioList([
      'a' => 'Rs. 500',
      'b' => 'Rs. 450',
      'c' => 'Rs. 360',
      'd' => 'Rs. 400',
      'e' => 'None',
    ], ['onClick' => 'getValue($(this).val());']) ?>


    <?= $form->field($model, 'q20')->textInput(['maxlength' => true])->label("Q20. Which is the smallest six-digits number, which when divided by 4, 8, 12, 15,18 and 20, leaves 7 as the remainder.")->radioList([
      'a' => '100082',
      'b' => '100092',
      'c' => '100057',
      'd' => '100087',
      'e' => 'None',
    ], ['onClick' => 'getValue($(this).val());']) ?>


    <?= $form->field($model, 'q21')->textInput(['maxlength' => true])->label("Q21. In this question, a statement is followed by two courses of action, numbered I and II. You must assume everything in the statement to be true and on the basis of the information given in the statement, decide which course of action/s logically follows for pursuing.
 Statement:<br>
 A large number of the people of the city are diagnosed to be suffering from Malaria disease.
<br>
Course of Action:<br>
 I. The city municipal authorities should take immediate steps to carry out extensive fumigation in the city.<br>
 II. The people in the area should be advised to take steps to avoid mosquito bites.")->radioList([
      'a' => 'Both I and II follow.',
      'b' => 'Only II follows',
      'c' => 'Only I follows',
      'd' => 'Neither I nor II follows ',
    ], ['onClick' => 'getValue($(this).val());']) ?>


    <?= $form->field($model, 'q22')->textInput(['maxlength' => true])->label("Q22. Rs, 2400 was invested for 3 years, partly in scheme A at the rate 15% S.I per annum and partly at the rate of 10% S.I per annum. Total interest received at the end was Rs.930. How much sum of money was invested in scheme A?")->radioList([
      'a' => 'Rs.1500',
      'b' => 'Rs.1000',
      'c' => 'Rs.1200',
      'd' => 'Rs.1400',
      'e' => 'Rs.1900',
    ], ['onClick' => 'getValue($(this).val());']) ?>


    <?= $form->field($model, 'q23')->textInput(['maxlength' => true])->label("Q23. In a row of trees, a tree is 7th from left end and 14th from right end. How many trees are there in the row ?")->radioList([
      'a' => '18',
      'b' => '19',
      'c' => '20',
      'd' => '21',
    ], ['onClick' => 'getValue($(this).val());']) ?>

    <?= $form->field($model, 'q24')->textInput(['maxlength' => true])->label("Q24. 20 boys go for dinner. 16 of them spent Rs. 64 each on their dinner and rest spent Rs 4 more than the average expenditure of all 20. What was the total money spent by them?")
      ->radioList([
        'a' => '1200',
        'b' => '1500',
        'c' => '1800',
        'd' => '1300',
        'e' => 'None Of These',
      ], ['onClick' => 'getValue($(this).val());']) ?>


    <?= $form->field($model, 'q25')->textInput(['maxlength' => true])->label("Q25. B is twice as old as A but twice younger than F. C is half the age of A but is twice older than d. Who is the second oldest ?
")->radioList([
      'a' => 'B',
      'b' => 'F',
      'c' => 'C',
      'd' => 'D',
    ], ['onClick' => 'getValue($(this).val());']) ?>
<br>
<br>
  </div>











  <div class="form-group">

    <?= Html::submitButton('Save', [
      'class' => 'btn btn-danger',
      'data' => [
        'confirm' => 'Are you sure you want to Submit?',
        'method' => 'post',
      ],
    ]) ?>

  </div>

  <?php ActiveForm::end(); ?>

</div>





<script>
  function getValue($value) {
    qt1 = $("input:radio[name='Set2[q1]']:checked").val();
    var q1, q2, q3, q4, q5, q6, q7, q8, q9, q10, q11, q12, q13, q14, q15, q16, q17, q18, q19, q20, q21, q22, q23, q24, q25;
    var total;
    if (qt1 == 'd') {
      q1 = 1;

    } else {
      q1 = 0;

    }

    qt2 = $("input:radio[name='Set2[q2]']:checked").val();
    if (qt2 == 'a') {
      q2 = 1;

    } else {
      q2 = 0;

    }
    qt3 = $("input:radio[name='Set2[q3]']:checked").val();
    if (qt3 == 'a') {
      q3 = 1;

    } else {
      q3 = 0;

    }
    qt4 = $("input:radio[name='Set2[q4]']:checked").val();
    if (qt4 == 'a') {
      q4 = 1;

    } else {
      q4 = 0;

    }
    qt5 = $("input:radio[name='Set2[q5]']:checked").val();
    if (qt5 == 'b') {
      q5 = 1;

    } else {
      q5 = 0;

    }
    qt6 = $("input:radio[name='Set2[q6]']:checked").val();
    if (qt6 == 'a') {
      q6 = 1;

    } else {
      q6 = 0;

    }
    qt7 = $("input:radio[name='Set2[q7]']:checked").val();
    if (qt7 == 'd') {
      q7 = 1;

    } else {
      q7 = 0;

    }
    qt8 = $("input:radio[name='Set2[q8]']:checked").val();
    if (qt8 == 'd') {
      q8 = 1;

    } else {
      q8 = 0;

    }
    qt9 = $("input:radio[name='Set2[q9]']:checked").val();
    if (qt9 == 'c') {
      q9 = 1;

    } else {
      q9 = 0;

    }
    qt10 = $("input:radio[name='Set2[q10]']:checked").val();
    if (qt10 == 'a') {
      q10 = 1;

    } else {
      q10 = 0;

    }
    qt11 = $("input:radio[name='Set2[q11]']:checked").val();
    if (qt11 == 'a') {
      q11 = 1;

    } else {
      q11 = 0;

    }
    qt12 = $("input:radio[name='Set2[q12]']:checked").val();
    if (qt12 == 'c') {
      q12 = 1;

    } else {
      q12 = 0;

    }
    qt13 = $("input:radio[name='Set2[q13]']:checked").val();
    if (qt13 == 'e') {
      q13 = 1;

    } else {
      q13 = 0;

    }
    qt14 = $("input:radio[name='Set2[q14]']:checked").val();
    if (qt14 == 'b') {
      q14 = 1;

    } else {
      q14 = 0;

    }
    qt15 = $("input:radio[name='Set2[q15]']:checked").val();
    if (qt15 == 'a') {
      q15 = 1;

    } else {
      q15 = 0;

    }
    qt16 = $("input:radio[name='Set2[q16]']:checked").val();
    if (qt16 == 'c') {
      q16 = 1;

    } else {
      q16 = 0;

    }
    qt17 = $("input:radio[name='Set2[q17]']:checked").val();
    if (qt17 == 'b') {
      q17 = 1;

    } else {
      q17 = 0;

    }
    qt18 = $("input:radio[name='Set2[q18]']:checked").val();
    if (qt18 == 'c') {
      q18 = 1;

    } else {
      q18 = 0;

    }
    qt19 = $("input:radio[name='Set2[q19]']:checked").val();
    if (qt19 == 'b') {
      q19 = 1;

    } else {
      q19 = 0;

    }
    qt20 = $("input:radio[name='Set2[q20]']:checked").val();
    if (qt20 == 'd') {
      q20 = 1;

    } else {
      q20 = 0;

    }
    qt21 = $("input:radio[name='Set2[q21]']:checked").val();
    if (qt21 == 'a') {
      q21 = 1;

    } else {
      q21 = 0;

    }
    qt22 = $("input:radio[name='Set2[q22]']:checked").val();
    if (qt22 == 'd') {
      q22 = 1;

    } else {
      q22 = 0;

    }
    qt23 = $("input:radio[name='Set2[q23]']:checked").val();
    if (qt23 == 'c') {
      q23 = 1;

    } else {
      q23 = 0;

    }
    qt24 = $("input:radio[name='Set2[q24]']:checked").val();
    if (qt24 == 'd') {
      q24 = 1;

    } else {
      q24 = 0;

    }
    qt25 = $("input:radio[name='Set2[q25]']:checked").val();
    if (qt25 == 'a') {
      q25 = 1;

    } else {
      q25 = 0;

    }
    total = q1 + q2 + q3 + q4 + q5 + q6 + q7 + q8 + q9 + q10 + q11 + q12 + q13 + q14 + q15 + q16 + q17 + q18 + q19 + q20 + q21 + q22 + q23 + q24 + q25;


    $('#set2-total').val(total)
    console.log(total)
  }
</script>

<script>
  // Set the date we're counting down to
  var countDownDate = new Date("August 9, 2023 15:50:00").getTime();

  // Update the count down every 1 second
  var x = setInterval(function() {

    // Get today's date and time
    var now = new Date().getTime();

    // Find the distance between now and the count down date
    var distance = countDownDate - now;

    // Time calculations for days, hours, minutes and seconds
    var days = Math.floor(distance / (1000 * 60 * 60 * 24));
    var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
    var seconds = Math.floor((distance % (1000 * 60)) / 1000);

    // Display the result in the element with id="demo"
    document.getElementById("demo").innerHTML = " Ends In: " + days + "d " + hours + "h " +
      minutes + "m " + seconds + "s ";
    var redirecct;
    // If the count down is finished, write some text
    if (distance < 0) {
      clearInterval(x);
      redirecct == -1;
      document.getElementById("w0").submit();
    }

    if (redirecct == -1) {


      window.location.replace('../site');
    }



  }, 1000);
</script>