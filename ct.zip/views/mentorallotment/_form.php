<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use app\models\Mentor;
use app\models\Users;
use yii\helpers\ArrayHelper;
use kartik\select2\Select2;

/* @var $this yii\web\View */
/* @var $model app\models\Mentorallotment */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="mentorallotment-form">

    <div style="width:40%;align:center;">

    <?php $form = ActiveForm::begin(); ?>

    <?php $client = Users::find()->all();
 
 $data = ArrayHelper::map($client, 'user_id','username');
 
?>
<?= $form->field($model, 'user_id')->label("STudent")->widget(Select2::classname(), [
'data' => $data,
'language' => 'en',
'options' => ['placeholder' => 'Search Student'],
'pluginOptions' => [
'allowClear' => true
],
]); ?>



<?php $client = Mentor::find()->all();
 
 $data = ArrayHelper::map($client, 'id','name');
 
?>
<?= $form->field($model, 'mentor_id')->label("Mentor")->widget(Select2::classname(), [
'data' => $data,
'language' => 'en',
'options' => ['placeholder' => 'Search Mentor'],
'pluginOptions' => [
'allowClear' => true
],
]); ?>



    <div class="form-group">
        <?= Html::submitButton('Save', ['class' => 'btn btn-success']) ?>
    </div>

    <?php ActiveForm::end(); ?>

    </div>

    

</div>
