<?php

use yii\helpers\Html;
use yii\grid\GridView;

/* @var $this yii\web\View */
/* @var $searchModel app\models\SearchSet3 */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Set 3s';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="set3-index">

    <h1><?= Html::encode($this->title) ?></h1>

    <p>
        <?= Html::a('Create Set 3', ['create'], ['class' => 'btn btn-success']) ?>
    </p>

    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            'id',
            'usn',
            'q1',
            'q2',
            'q3',
            //'q4',
            //'q5',
            //'q7',
            //'q8',
            //'q9',
            //'q10',
            //'q11',
            //'q12',
            //'q13',
            //'q14',
            //'q15',
            //'q16',
            //'q17',
            //'q18',
            //'q19',
            //'q20',
            //'q21',
            //'q22',
            //'q23',
            //'q24',
            //'q25',
            //'test_date',
            //'created_at',
            //'updated_at',

            ['class' => 'yii\grid\ActionColumn'],
        ],
    ]); ?>


</div>
