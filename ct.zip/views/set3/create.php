<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model app\models\Set3 */

$this->title = 'Create Set 3';
$this->params['breadcrumbs'][] = ['label' => 'Set 3s', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="set3-create">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
