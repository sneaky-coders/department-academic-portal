<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use aneeshikmat\yii2\Yii2TimerCountDown\Yii2TimerCountDown;

/* @var $this yii\web\View */
/* @var $model app\models\Test */
/* @var $form yii\widgets\ActiveForm */
?>

<style>
.test-create h1
{
    display:none;
}
    </style>
<div class="test-form">

    <?php $form = ActiveForm::begin(); ?>


<br><br>
        <div id="time-down-counter-2" style="float:right; font-size:20px;"></div>
        <?= Yii2TimerCountDown::widget([
            'countDownIdSelector' => 'time-down-counter-2',
            'countDownDate' => strtotime('+30 minutes') * 1000,// You most * 1000 to convert time to milisecond
            'countDownResSperator' => ':',
            'addSpanForResult' => false,
            'addSpanForEachNum' => false,
            'countDownOver' => 'Expired',
            'countDownReturnData' => 'from-days',
            'templateStyle' => 0,
            'getTemplateResult' => 0,
            'addServerTime' => false,
            'callBack' => 'Expired'
        ]) ?>
    

    <div class="col-md-8">
    
    <?= $form->field($model, 'usn')->textInput(['maxlength' => 10,'style'=>'width:200px']) ?>

    <?= $form->field($model, 'q1')->textInput(['maxlength' => true])->label("Q1. Who developed Python Programming Language?")->radioList([
        'Wick van Rossum' => 'Wick van Rossum',
        'Rasmus Lerdorf' => 'Rasmus Lerdorf',
        'Guido van Rossum' => 'Guido van Rossum',
        'Niene Stom' => 'Niene Stom',
    ])?> 

    <?= $form->field($model, 'q2')->textInput(['maxlength' => true])->label("Q2. Which type of Programming does Python support?")->radioList([
        'OOp' => 'object-oriented programming',
        'structured programming' => 'structured programming',
        'functional programming' => 'functional programming',
        'all of the mentioned' => 'all of the mentioned',
        ]) ?>

    <?= $form->field($model, 'q3')->textInput(['maxlength' => true])->label("Q3. Is Python case sensitive when dealing with identifiers?")->radioList([
        'no' => 'no',
        'yes' => 'yes',
        'machine dependent' => 'machine dependent',
        ' none' => ' none of the mentioned',
        ])  ?>

    <?= $form->field($model, 'q4')->textInput(['maxlength' => true])->label("Q4. Which of the following is the correct extension of the Python file?")->radioList([
        '.python' => '.python',
        '.pl' => '.pl',
        '.py' => '.py',
        '.p' => '.p',
        ])  ?>

    <?= $form->field($model, 'q5')->textInput(['maxlength' => true])->label("Q5. Is Python code compiled or interpreted?")->radioList([
        'both' => 'both compiled and interpreted',
        'neither compiled nor interpreted' => 'neither compiled nor interpreted',
        'only compiled' => 'only compiled',
        'only interpreted' => 'only interpreted',
        ])  ?>

    <?= $form->field($model, 'q6')->textInput(['maxlength' => true])->label("Q6. All keywords in Python are in _________")->radioList([
        'Capitalized' => 'Capitalized',
        'Lowercase' => 'Lowercase',
        'Uppercase' => 'Uppercase',
        'None' => 'None of the mentioned',
        ])  ?>

    <?= $form->field($model, 'q7')->textInput(['maxlength' => true])->label("Q7. What will be the value of the following Python expression?   4 + 3 % 5")->radioList([
        '7' => '7',
        '2' => '2',
        '1' => '1',
        '5' => '5',
        ])  ?>

    <?= $form->field($model, 'q8')->textInput(['maxlength' => true])->label("Q8. Which of the following is used to define a block of code in Python language?")->radioList([
        'Indentation' => 'Indentation',
        'Key' => 'Key',
        'Brackets' => 'Brackets',
        'All of the mentioned' => 'All of the mentioned',
        ])  ?>

    <?= $form->field($model, 'q9')->textInput(['maxlength' => true])->label("Q9. Which keyword is used for function in Python language?")->radioList([
        'Function' => 'Function',
        'def' => 'def',
        'Fun' => 'Fun',
        'Define' => 'Define',
        ])  ?>

<?= $form->field($model, 'q10')->textInput(['maxlength' => true])->label("Q10. Which of the following character is used to give single-line comments in Python?")->radioList([
        '//' => '//',
        '#' => '#',
        '!' => '!',
        '/*' => '/*',
        ])  ?>
    
    <div class="form-group">
        <?= Html::submitButton('Save', ['class' => 'btn btn-success']) ?>
    </div>


</div>

    

    

 

 

    <?php ActiveForm::end(); ?>

</div>
