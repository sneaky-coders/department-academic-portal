<?php

use kartik\date\DatePicker;
use yii\helpers\Html;
use yii\helpers\ArrayHelper;
use yii\widgets\ActiveForm;
use kartik\select2\Select2;
use yii\data\ActiveDataProvider;

$this->title = "Bill Report";
?>
<?php $form = ActiveForm::begin([
                'method' => 'get',
            ]); ?>
<input type="hidden" name="_csrf" value="<?=Yii::$app->request->getCsrfToken()?>" />
<div class="row">
    <div class="col-md-3">
        <?php 
            echo DatePicker::widget([
                'name' => 'start_date',
                'value' => $start_date,
                'options' => ['placeholder' => 'Start Date'],
                'type' => DatePicker::TYPE_COMPONENT_APPEND,
                'pluginOptions' => [
                    'autoclose'=>true,
                    'format' => 'yyyy-mm-dd'
                ]
            ]);
        ?>
    </div>
    <div class="col-md-3">
        <?php 
            echo DatePicker::widget([
                'name' => 'end_date',
                'value' => $end_date,
                'options' => ['placeholder' => 'End Date'],
                'type' => DatePicker::TYPE_COMPONENT_APPEND,
                'pluginOptions' => [
                    'autoclose'=>true,
                    'format' => 'yyyy-mm-dd'
                ]
            ]);
        ?>
    </div>
    <div class="col-md-2">
    <?= 
            Select2::widget([
                'name' => 'usn',
                'value' => $usn,
                'data' => ['2GI22MC001' =>'2GI22MC001', '2GI22MC002' => '2GI22MC002', '2GI22MC003' => '2GI22MC003','2GI22MC004' => '2GI22MC004','2GI22MC005' => '2GI22MC005',
                           '2GI22MC006' => '2GI22MC006','2GI22MC007' => '2GI22MC007','2GI22MC008' => '2GI22MC008','2GI22MC009' => '2GI22MC009','2GI22MC010' => '2GI22MC010',
                           '2GI22MC011' => '2GI22MC011','2GI22MC012' => '2GI22MC012','2GI22MC013' => '2GI22MC013','2GI22MC014' => '2GI22MC014','2GI22MC015' => '2GI22MC015',
                           '2GI22MC016' => '2GI22MC016','2GI22MC017' => '2GI22MC017','2GI22MC018' => '2GI22MC018','2GI22MC019' => '2GI22MC019','2GI22MC020' => '2GI22MC020',
                           '2GI22MC021' => '2GI22MC021','2GI22MC022' => '2GI22MC022','2GI22MC023' => '2GI22MC023','2GI22MC024' => '2GI22MC024','2GI22MC025' => '2GI22MC025',
                           '2GI22MC026' => '2GI22MC026','2GI22MC027' => '2GI22MC027','2GI22MC028' => '2GI22MC028','2GI22MC029' => '2GI22MC029','2GI22MC030' => '2GI22MC030',
                           '2GI22MC031' => '2GI22MC031','2GI22MC032' => '2GI22MC032','2GI22MC033' => '2GI22MC033','2GI22MC034' => '2GI22MC034','2GI22MC035' => '2GI22MC035',
                           '2GI22MC036' => '2GI22MC036','2GI22MC037' => '2GI22MC037','2GI22MC038' => '2GI22MC038','2GI22MC039' => '2GI22MC039','2GI22MC040' => '2GI22MC040',
                           '2GI22MC041' => '2GI22MC041','2GI22MC042' => '2GI22MC042','2GI22MC043' => '2GI22MC043','2GI22MC044' => '2GI22MC044','2GI22MC045' => '2GI22MC045',
                           '2GI22MC046' => '2GI22MC047','2GI22MC047' => '2GI22MC047','2GI22MC048' => '2GI22MC048','2GI22MC049' => '2GI22MC049','2GI22MC050' => '2GI22MC050',
                           '2GI22MC051' => '2GI22MC051','2GI22MC052' => '2GI22MC052','2GI22MC053' => '2GI22MC053','2GI22MC054' => '2GI22MC054','2GI22MC055' => '2GI22MC055',
                           '2GI22MC056' => '2GI22MC056','2GI22MC057' => '2GI22MC057','2GI22MC058' => '2GI22MC058','2GI22MC059' => '2GI22MC059','2GI22MC060' => '2GI22MC060',
                           '2GI22MC061' => '2GI22MC061','2GI22MC062' => '2GI22MC062','2GI22MC063' => '2GI22MC063','2GI22MC064' => '2GI22MC064','2GI22MC065' => '2GI22MC065',
                           '2GI22MC066' => '2GI22MC066','2GI22MC067' => '2GI22MC067','2GI22MC068' => '2GI22MC068','2GI22MC069' => '2GI22MC069','2GI22MC070' => '2GI22MC070',
                           '2GI22MC071' => '2GI22MC071','2GI22MC072' => '2GI22MC072','2GI22MC073' => '2GI22MC073','2GI22MC074' => '2GI22MC074','2GI22MC075' => '2GI22MC075',
                           '2GI22MC076' => '2GI22MC076','2GI22MC077' => '2GI22MC077','2GI22MC078' => '2GI22MC078','2GI22MC079' => '2GI22MC079','2GI22MC080' => '2GI22MC080',
                           '2GI22MC081' => '2GI22MC081','2GI22MC082' => '2GI22MC082','2GI22MC083' => '2GI22MC083','2GI22MC084' => '2GI22MC084','2GI22MC085' => '2GI22MC085',
                           '2GI22MC086' => '2GI22MC086','2GI22MC087' => '2GI22MC087','2GI22MC088' => '2GI22MC088','2GI22MC089' => '2GI22MC089','2GI22MC090' => '2GI22MC090',
                           '2GI22MC091' => '2GI22MC091','2GI22MC092' => '2GI22MC092','2GI22MC093' => '2GI22MC093','2GI22MC094' => '2GI22MC094','2GI22MC095' => '2GI22MC095',
                           '2GI22MC096' => '2GI22MC096','2GI22MC097' => '2GI22MC097','2GI22MC098' => '2GI22MC098','2GI22MC099' => '2GI22MC099','2GI22MC100' => '2GI22MC100',
                           '2GI22MC101' => '2GI22MC101','2GI22MC102' => '2GI22MC102','2GI22MC103' => '2GI22MC103','2GI22MC104' => '2GI22MC104','2GI22MC105' => '2GI22MC105',
                           '2GI22MC106' => '2GI22MC106','2GI22MC107' => '2GI22MC107','2GI22MC108' => '2GI22MC108','2GI22MC109' => '2GI22MC109','2GI22MC110' => '2GI22MC110',
                           '2GI22MC111' => '2GI22MC111','2GI22MC112' => '2GI22MC112','2GI22MC113' => '2GI22MC113','2GI22MC114' => '2GI22MC114','2GI22MC115' => '2GI22MC115',
                           '2GI22MC116' => '2GI22MC116','2GI22MC117' => '2GI22MC117','2GI22MC118' => '2GI22MC118','2GI22MC119' => '2GI22MC119','2GI22MC120' => '2GI22MC120',
                        ],
                'options' => [ 'placeholder' => 'Select USN']
            ]);
        ?>
    </div>

    

    
    <div class="col-md-2">
        <div class="form-group">
            <?= Html::submitButton('Filter', ['class' => 'btn btn-default']) ?>
        </div>
    </div>
    <?php ActiveForm::end(); ?>
</div>
<table class="table table-bordered">
    <tr>
        <th>Sr. No</th>
        <th>Test Date</th>
        <th>USN</th>
        <th>Q1</th>
        <th>Q2</th>
        <th>Q3</th>
        <th>Q4</th>
        <th>Q5</th>
        <th>Q6</th>
        <th>Q7</th>
        <th>Q8</th>
        <th>Q9</th>
        <th>Q10</th>
        <th>TOTAL Score</th>
        <th colspan="2" style="text-align:center;">Action</th>
    </tr>

    <tr>
    <?php 
  
        $models = $dataProvider->getModels();
        foreach ($models as $key => $model) {
           
            
            if ($model->q1 == 'Guido van Rossum') 
            {
                $scoreq1=1;
            }

            else
            {
                $scoreq1=0;
            }

            if ($model->q2 == 'all of the mentioned') 
            {
                $scoreq2=1;
            }

            else
            {
                $scoreq2=0;
            }

            if ($model->q3 == 'yes') 
            {
                $scoreq3=1;
            }

            else
            {
                $scoreq3=0;
            }

            if ($model->q4 == '.py') 
            {
                $scoreq4=1;
            }

            else
            {
                $scoreq4=0;
            }

            if ($model->q5 == 'both') 
            {
                $scoreq5=1;
            }

            else
            {
                $scoreq5=0;
            }

            if ($model->q6 == 'None') 
            {
                $scoreq6=1;
            }

            else
            {
                $scoreq6=0;
            }

            if ($model->q7 == 7) 
            {
                $scoreq7=1;
            }

            else
            {
                $scoreq7=0;
            }

            if ($model->q8 == 'Indentation') 
            {
                $scoreq8=1;
            }

            else
            {
                $scoreq8=0;
            }

            if ($model->q9 == 'def') 
            {
                $scoreq9=1;
            }

            else
            {
                $scoreq9=0;
            }

            if ($model->q10 == '#') 
            {
                $scoreq10=1;
            }

            else
            {
                $scoreq10=0;
            }

            if ($model->usn == $usn) {
                $total2 = $scoreq1+$scoreq2+$scoreq3+$scoreq4+$scoreq4+$scoreq5+$scoreq6+$scoreq7+$scoreq8+$scoreq9+$scoreq10;
                $neg =1;
                $total = 0;
                $class = $total > 5 ? 'success' : 'warning';
                $total = $total2 - $neg;
                   echo '<tr class="'. $class .'">
                       <td>'. ($key + 1) .'</td>
                       <td>'. $model->test_date .'</td>
                       <td>'. $model->usn .'</td>
                       <td>'. $scoreq1. '</td>
                       <td>'. $scoreq2. '</td>
                       <td>'. $scoreq3. '</td>
                       <td>'. $scoreq4. '</td>
                       <td>'. $scoreq5. '</td>
                       <td>'. $scoreq6. '</td>
                       <td>'. $scoreq7. '</td>
                       <td>'. $scoreq8. '</td>
                       <td>'. $scoreq9. '</td>
                       <td>'. $scoreq10. '</td>
                       <td>'. $total. '</td>
              
                       <td><a href="view?id='. $model->id .'"><span class="glyphicon glyphicon-eye-open"></span></a></td>
                       <td><a href="update?id='. $model->id .'"><span class="glyphicon glyphicon-pencil"></span></a></td> 
                   </tr>';
            }
            
       
        }
    ?>
    </tr>
    
    
</table>
